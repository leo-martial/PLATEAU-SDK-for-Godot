# PLATEAU SDK for Godot (4.2+)

A turnkey, **pure-GDScript** toolkit to bring MLIT Project PLATEAU data
into Godot: browse the official dataset catalog, fine-select categories
and mesh tiles from a local zip, import PLATEAU-Ortho aerial imagery, and
import CityGML buildings (LOD0-4, textured) - all from a single dock, all
sharing one project origin so everything lines up automatically.

No GDExtension, no native build, no third-party binary. This merges and
supersedes three addons that were developed separately earlier in this
project (PLATEAU Dataset Browser, PLATEAU Ortho Importer, PLATEAU
Converter) into one SDK with a single dock and a shared setup step.

## Why pure GDScript, no godot-plateau

This SDK was originally meant to build on
[shiena/godot-plateau](https://github.com/shiena/godot-plateau), a
community GDExtension wrapping `libplateau`. After that couldn't be gotten
to run, everything here was written from scratch in plain `.gd` scripts:
no C++ toolchain, no compiled binary to keep working across Godot
versions or platforms - just scripts you can read, modify, and drop into
any project. The trade-off is a more modest feature set than a mature C++
pipeline would offer (see "Known limitations" below and per-module notes).

## Installation

1. Copy `addons/plateau_sdk/` into your project's `addons/` folder.
2. Project Settings > Plugins > enable "PLATEAU SDK".
3. A single "PLATEAU SDK" dock appears in the editor, with a **Project
   Setup** section at the top and three tabs below it: **3D (PLATEAU)**,
   **2D (PLATEAU Ortho)**, and **Exploration**.
4. Enabling the plugin also registers a few things needed for the
   Exploration tab to work at Play time: an `Audio` autoload singleton and
   several Input Map actions (movement, jump, camera look, zoom, mouse
   capture). See "Exploration tab" below for exactly what and why - this
   never overwrites an action your project already defines under the same
   name.

## Quick start (few-click workflow)

1. **Project Setup** (top of the dock): pick a JGD2011 zone (1-19) and an
   origin (lat/lon) - or leave it, and let step 3 below fill it in
   automatically. This single origin is shared by both geographic tabs, so
   a downloaded aerial photo and imported buildings always line up,
   instead of every import re-centering independently. It updates itself
   automatically if auto-detected from inside the 3D tab, too.
2. **3D (PLATEAU) tab, section A**: load the catalog, pick a
   prefecture/municipality, open its zip URL in your browser (downloading
   multi-GB files inside the editor has no pause/resume, so this stays a
   browser job).
3. **Section B**: point at the downloaded local zip, analyze it, pick the
   categories and mesh tiles you want on the map, and extract. This
   auto-fills section C's input path below, and - if you skipped step 1 -
   auto-detects a project origin and zone from the extracted data.
4. **Section C**: pick a LOD (defaults to "maximum available, auto") and
   hit Import. Buildings appear in the open scene.
5. **2D (PLATEAU Ortho) tab**: pan the minimap to the same area, draw a
   selection, download. Optionally generate a textured ground plane
   aligned to the same shared project origin.
6. **Exploration tab**: pick a character, click a spot on the schematic
   map of what you just imported, hit Place. Press Play (F6) to actually
   walk or look around - placing only sets a position, it doesn't move
   anything in the editor viewport itself.

## Module layout

```
addons/plateau_sdk/
  plugin.gd, plugin.cfg          entry point + Audio autoload/Input Map setup
  main_panel.gd                  dock root: Project Setup + tabs
  core/                          shared, addon-agnostic utilities
    jgd2011_projection.gd        JGD2011 (Gauss-Krüger) lat/lon -> meters
    tile_math.gd                 Web Mercator XYZ tile math
    mesh_code_math.gd            JIS X0410 mesh code -> lat/lon bounds
    xml_tree.gd                  generic XML/GML tree via XMLParser
    zip_central_directory.gd     ZIP metadata reader (no decompression)
    gml_file_finder.gd           recursive .gml file lookup
    origin_finder.gd             origin/zone auto-detection from a .gml
    project_origin.gd            shared origin/zone state + signal
    scene_geometry_utils.gd      reads buildings/ground plane already in
                                  the edited scene (height matching, the
                                  Exploration tab's schematic map)
  dataset/                       "3D (PLATEAU)" tab: catalog, zip
                                  selection/extraction, AND CityGML import
                                  (sections A/B/C of the same panel - these
                                  were two separate tabs at first, merged
                                  since acquiring and importing CityGML
                                  data is really one continuous task)
  ortho/                         "2D (PLATEAU Ortho)" tab: aerial imagery
  converter/                     CityGML -> scene import engine (used by
                                  dataset/dataset_panel.gd's section C; no
                                  UI of its own anymore)
  exploration/                   "Exploration" tab: place a playable
                                  character (third- or first-person) into
                                  the imported scene
    exploration_panel.gd         tab UI
    scene_top_view.gd            top-down schematic placement widget
    characters/                  runtime character scenes/scripts (NOT
                                  @tool - only active during Play), adapted
                                  from Kenney's MIT-licensed starter kits,
                                  see characters/LICENSE-THIRD-PARTY.md
```

## Sources and technical notes (carried over from the original addons)

### JGD2011 projection (`core/jgd2011_projection.gd`)

CityGML coordinates are raw latitude/longitude/height, not meters. This
SDK implements the official GSI (Geospatial Information Authority of
Japan) formula for the Japanese Plane Rectangular Coordinate System
(平面直角座標系, 19 zones) directly - simplified Gauss-Krüger method by
Kazushige Kawase:
https://vldb.gsi.go.jp/sokuchi/surveycalc/surveycalc/algorithm/bl2xy/bl2xy.htm
(full reference: doi 10.57499/JOURNAL_121_12). The 19-zone origin table is
taken verbatim from MLIT Notice No. 9 of 2002:
https://www.gsi.go.jp/LAW/heimencho.html

Self-checked during development with an external Python port of the same
formula (origin round-trips to (0,0), 1° of latitude gives ~111km, a real
point's meridian convergence angle matches an independent source) - but
**not verified against the official calculator in a live Godot editor**.
Before relying on this for serious work, check at least one known point
against
https://vldb.gsi.go.jp/sokuchi/surveycalc/surveycalc/bl2xyf.html

This same projection is now used by BOTH the 2D (PLATEAU Ortho) tab's ground-plane
placement and the 3D (PLATEAU) tab's geometry placement (previously, the
Ortho addon had a separate, cruder "local tangent plane" approximation and
an optional, never-verified dependency on godot-plateau's
`PLATEAUGeoReference` class - both removed now that this SDK has its own
correct, dependency-free projection).

### CityGML structure (`converter/citygml_parser.gd`, `converter/appearance_parser.gd`)

LOD1-4 geometry structure and the `app:appearance`/texture-coordinate
linkage were both confirmed against real/official CityGML 2.0 examples
during development (not just the abstract spec) - see the source comments
in those files for the exact references. LOD0 (a flat footprint, no
volume) uses a different element (`bldg:lod0FootPrint` /
`bldg:lod0RoofEdge`) and is handled separately.

### PLATEAU catalog API (`dataset/catalog_client.gd`)

`GET https://api.plateauview.mlit.go.jp/datacatalog/plateau-datasets`,
confirmed via independent sources - MLIT labels this service
**experimental**: no uptime or response-schema guarantee. The client
parses defensively and reports a schema mismatch clearly instead of
failing silently.

### ZIP handling (`core/zip_central_directory.gd`)

Godot's native `ZIPReader` doesn't appear to expose an entry's size
without fully decompressing it. This SDK reads the raw ZIP central
directory directly (a decades-stable binary format) to get every entry's
size instantly, the same principle as `unzip -l`. Handles ZIP64 for the
global fields (needed for zips over 4GB, e.g. Tokyo's 23 wards) but not
per-entry ZIP64 (a single file over 4GB - never seen in practice in a
PLATEAU dataset).

### Mesh codes (`core/mesh_code_math.gd`)

The JIS X0410 regional mesh code algorithm (8-digit "base mesh", ~1km per
side) used to place mesh tiles on the 3D (PLATEAU) tab's selection map -
checked against a reference implementation published with source code.

### Basemap tiles

The 3D (PLATEAU) tab's mesh-selection map uses GSI "pale" basemap tiles
(`https://cyberjapandata.gsi.go.jp/xyz/pale/{z}/{x}/{y}.png`), attribution
required ("国土地理院" / GSI, shown in the tab). The 2D (PLATEAU Ortho) tab's minimap
uses PLATEAU-Ortho tiles directly as its own background, and can also
overlay the SAME meshes from the 3D tab once a zip has been analyzed there
(`dataset_panel.gd`'s `meshes_analyzed` signal -> `ortho_panel.gd`'s
`set_mesh_overlay()`) - pick "Select 3D (PLATEAU) meshes" in the map's mode
selector to set the Ortho download area from an exact mesh (or several,
Shift+drag) instead of a hand-drawn rectangle. Disabled until a zip has
been analyzed in the 3D tab, since there's nothing to show or select
before that.

### Scene layout and collision (`converter/citygml_importer.gd`)

Each import creates one `Node3D` per mesh code found, named
`"<meshcode> PLATEAU 3D Data"` (e.g. `"53391532 PLATEAU 3D Data"`), holding
one `Node3D` per feature category under it (e.g. `"bldg"`, `"brid"`),
holding the `MeshInstance3D` nodes themselves. Mesh code and category are
both read from each `.gml` file's own path (PLATEAU's naming convention,
`(meshcode)_(category)_(crs)_(option).gml` under `udx/(category)/`), not
guessed from geometry.

Collision is opt-in (off by default, "Generate collision" checkbox in
section C): when on, every imported building also gets an exact trimesh
static collision body via `MeshInstance3D.create_trimesh_collision()` -
correct but slower to generate and heavier to simulate than a simplified
shape, so it's worth leaving off for a first look at a large import. The
same option, and the same method, is available for the Ortho tab's ground
plane.

Each building's mesh vertices are stored relative to the building's own
AABB center rather than the shared project origin, with that offset
carried by the `MeshInstance3D`'s own `.position` - otherwise Godot's
selection gizmo/AABB for every single building would span all the way out
to the project origin (which can be kilometers away) instead of hugging
the building itself, making individual buildings painfully unwieldy to
select and move.

### Exploration tab (`exploration/`)

Places a playable character - third-person (orbit camera) or first-person
(mouse look) - into the open scene, so you can walk or fly around whatever
was just imported, without leaving the editor to set one up yourself.

**Source of the characters**: adapted from Kenney's official Godot starter
kits, [Starter Kit 3D Platformer](https://github.com/Kenney-NL/Starter-Kit-3D-Platformer)
and [Starter Kit FPS](https://github.com/Kenney-NL/Starter-Kit-FPS), both
MIT-licensed. Full attribution, license text, and an exact list of what
was changed (the entire weapon system removed from the first-person
character; no other logic changes) is in
`exploration/characters/LICENSE-THIRD-PARTY.md`.

**Runtime requirements registered automatically by `plugin.gd`** when the
plugin is enabled, since the character scripts depend on them and a bare
addon folder copy wouldn't provide either on its own:
- An `Audio` autoload singleton (`exploration/characters/shared/audio.gd`,
  itself adapted from the FPS kit's own audio helper) - a small pooled
  `AudioStreamPlayer` manager the characters use for jump/land/footstep
  sounds.
- Input Map actions: `move_left/right/forward/back`, `jump`,
  `camera_left/right/up/down`, `zoom_in/out`, `mouse_capture`,
  `mouse_capture_exit` - bound to WASD/arrows/Space/click/Escape,
  matching Kenney's original kits. Deliberately does **not** register
  `shoot` or `weapon_toggle`, since the first-person character here has
  no weapon. Registration never overwrites an action your project already
  defines under the same name (checked via `InputMap.has_action()`), and
  is not undone if you later disable the plugin (see the comment in
  `plugin.gd` for why).

**Placement**: `scene_top_view.gd` draws a top-down schematic of the
current scene - NOT a rendered camera view, just flat rectangles for each
imported building's footprint (from its mesh AABB) and the Ortho ground
plane's extent, read via `core/scene_geometry_utils.gd`. Click sets an
(X, Z); "Snap to floor height" (on by default) sets Y from the Ortho
ground plane if one exists, else the lowest point among imported
buildings, else 0 - a single flat height, not per-spot terrain following,
so it won't account for a slope or for clicking on top of a building.
Placing again removes any previously-placed exploration character first
(by node name) rather than stacking duplicates.

**Placing only sets a position.** The characters' movement, camera, and
input handling all live in ordinary runtime scripts (not `@tool`), so
nothing happens in the editor viewport itself - press Play (F6, "run
current scene") to actually move around.

## Known limitations

Carried over from the original addons, still true here:

- **Exploration tab placement is geometric, not physics-based**: there's
  no raycast-against-collision "drop to floor" - editor-time physics
  queries against the edited scene aren't reliably available outside Play
  mode, so height comes from the ground plane / lowest-building data
  described above instead. Good enough to start walking around, not a
  substitute for real ground-following.
- **Exploration tab's schematic map is not a rendered view**: flat
  rectangles from mesh AABBs, no textures, no elevation shading, no
  rotation (buildings are drawn axis-aligned even if their actual geometry
  isn't) - an orientation aid, not a preview.

- **Extraction defaults changed to avoid a real accumulation bug**: meshes
  on the selection map and categories other than `bldg` are now unchecked
  by default, and "Clear target folder before extracting" (on by default)
  wipes the target folder's contents right before writing a new
  selection. Without this, a second, DIFFERENT selection extracted into
  the same folder without re-analyzing (the target folder name only
  depends on the zip's filename, not on the current selection) would sit
  alongside the first extraction's files rather than replacing them - and
  importing from that folder in section C would then silently pick up
  both old and new data together. Turn the checkbox off only if you
  deliberately want to combine several extractions into one folder.

- **"Maximum available LOD" silently imported nothing** in an earlier
  version: Godot's `OptionButton.add_item(label, id)` treats an id of
  exactly `-1` as "auto-assign the id to this item's insertion index"
  rather than as a literal custom id, so the menu entry meant to signal
  "auto" carried a meaningless LOD number (5) instead. Fixed by using a
  sentinel value that isn't reserved by Godot (`PlateauCityGmlParser.AUTO_LOD`,
  now `-99`) - flagged here since it's a non-obvious Godot behavior worth
  knowing about if you add more OptionButton items elsewhere in this addon.
- **Ground plane has no elevation data of its own**: PLATEAU-Ortho is a
  flat aerial photo, so the generated plane is placed at a configurable
  but otherwise arbitrary height (0 by default) - it won't automatically
  land at the same level as imported buildings' real ground elevation. Use
  the "Match height to imported buildings" button (2D tab, once buildings
  exist in the scene) or nudge the height field by hand.
- **No hole support**: interior rings (e.g. a courtyard) are ignored, a
  polygon with a hole is filled as if it had none.
- **Triangle winding/normal direction unverified** in a live editor:
  materials disable `cull_mode` by default so a face can't simply vanish
  from a wrong winding, at a small rendering cost.
- **No TIFF texture support**: images load via `Image.load()`, which
  covers PNG/JPG/BMP/TGA/WebP but not TIFF (not confirmed whether PLATEAU
  ever uses TIFF for building textures).
- **Texture V-axis flip is a guess** (`appearance_parser.gd`, `FLIP_V`):
  CityGML/X3D UVs traditionally originate at the bottom, Godot generally
  expects the top - flipped by default, flag to flip back if textures
  come out upside down.
- **Texture images must be re-extracted with the current
  `file_index.gd`**: an earlier version of this SDK classified appearance
  images (which don't carry a mesh code in their own filename, e.g.
  `yk100939.jpg`, only in their enclosing `<meshcode>_..._appearance/`
  folder) as "unresolved", and a later change unchecked "include
  unresolved files" by default - the combination silently excluded every
  texture image from extraction. Fixed by having the mesh-code detection
  fall back to the enclosing folder name, but a folder extracted with the
  older code won't retroactively gain the missing files: re-run "Analyze
  zip" + "Extract selection" in the 3D tab if textures are still reported
  as missing after updating.
- **Import zoom 19 has been unreliable in practice** on the Ortho tab -
  zoom 18 is noticeably more reliable and still very high resolution
  (warning shown next to the zoom field).
- **Blocking operations, no threads**: zip extraction and CityGML import
  both run synchronously; large selections can freeze the editor
  temporarily with no progress reporting during the operation itself
  (only before/after).
- **One MeshInstance3D per building** (grouped under mesh/category nodes,
  see above): simple, and lets metadata (`gml_id`, `lod_used`,
  `measured_height`) attach per building, but can mean a lot of nodes for
  a large import. No mesh merging in this version. Re-importing into the
  same scene creates new mesh/category nodes rather than reusing existing
  ones by name, so importing the same data twice duplicates the hierarchy.
- **Attributes are minimal**: `gml:id` and `measuredHeight` only, no
  access to extended i-UR attributes (land use, construction year, hazard
  data, etc.) or their codelists.
- **Nothing in this SDK has been run in a live Godot editor by the person
  who wrote it** (an AI assistant without editor access) - it was built
  and debugged entirely from source review, static-type-checking
  reasoning, and the error messages reported back after each real test.
  Treat it accordingly: read the code before trusting it with anything
  that matters, and expect to find and fix at least a few more issues on
  first real use, the same way several rounds of real Godot errors were
  needed to get this far.

## Troubleshooting: GDScript errors on first load

Two classes of error came up repeatedly while building this SDK, both
worth knowing about if you extend it:

1. **`Nonexistent function 'X' in base 'GDScript'`** when calling a static
   method on another script via its bare `class_name` - this is why every
   cross-file static call in this codebase goes through an explicit
   `const X = preload("res://addons/plateau_sdk/.../file.gd")` instead of
   the bare class name. `ClassName.new()` and type annotations
   (`var x: ClassName`) were empirically fine without preloading; plain
   static utility calls were not.
2. **`Cannot infer the type of "x" variable because the value doesn't have
   a set type`** when using `:=` on an expression that touches an untyped
   `Array`/`Dictionary` (e.g. iterating an untyped `Array` gives `Variant`
   elements, and calling a method on a `Variant` has no statically-known
   return type). Fixed throughout by either declaring collections with a
   concrete element type (`Array[String]`, `Array[PlateauXmlNode]`, ...)
   or using an explicit type annotation (`var x: Foo = ...`) instead of
   `:=` wherever a Variant-typed value is involved. Also watch out for
   ternaries between array literals (`[a] if cond else []`) assigned to a
   typed variable - Godot doesn't propagate the target type into a
   ternary's branches, so this fails even though a direct literal
   assignment to the same typed variable works fine.

If you hit either error again while modifying this addon, these are the
first two things to check.
