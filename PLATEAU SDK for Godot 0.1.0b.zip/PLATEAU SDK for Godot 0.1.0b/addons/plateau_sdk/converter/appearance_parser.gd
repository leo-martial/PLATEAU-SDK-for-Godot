## appearance_parser.gd
## Builds a "ring id -> texture" lookup table from a building's
## app:appearance elements.
##
## Structure confirmed against a complete official CityGML 2.0 example
## (a test file from TU Delft's schema validation repo):
## https://github.com/tudelft3d/CityGML-schema-validation/blob/master/schemas/v2.0/Examples/Appearance/Appearance_TexCoord-Example.gml
##
##   bldg:Building
##     app:appearance > app:Appearance > app:surfaceDataMember
##       > app:ParameterizedTexture > app:imageURI (path relative to the .gml)
##       > app:target > app:TexCoordList
##         > app:textureCoordinates ring="#<ring's gml:id>" (u v pairs)
##
## The link that matters is the ring's gml:id (gml:LinearRing), not the
## app:target/uri hierarchy that wraps it: this module does NOT model that
## full hierarchy, it just records, for each app:textureCoordinates[ring],
## the targeted ring id and its UV coordinates, together with the enclosing
## app:ParameterizedTexture's imageURI. That's enough to apply the right
## texture to the right ring.
##
## app:appearance is normally nested INSIDE the building (next to its
## geometry), but CityGML also allows declaring it once at the document
## root (core:CityModel) and referencing rings by id from there:
## build_ring_texture_map() checks both locations, prioritizing whatever is
## found inside the building itself.
##
## UNVERIFIED UNCERTAINTY: CityGML/X3D texture coordinates traditionally
## have their V (vertical) origin at the bottom (an OpenGL/X3D convention),
## while Godot generally expects a top origin for its UVs. This module
## therefore flips V by default (v_godot = 1.0 - v_citygml) - if textures
## appear vertically flipped after import, this is the first setting to
## try flipping (FLIP_V below).
@tool
extends RefCounted
class_name PlateauAppearanceParser

const FLIP_V := true

## Returns Dictionary { ring_id: String -> { image_uri: String, uv: Array[Vector2] } }
static func build_ring_texture_map(building_node: PlateauXmlNode, document_root: PlateauXmlNode) -> Dictionary:
	var map := {}
	_scan_appearances(building_node, map)
	if map.is_empty() and document_root != null:
		_scan_appearances(document_root, map)
	return map

static func _scan_appearances(scope_node: PlateauXmlNode, out_map: Dictionary) -> void:
	if scope_node == null:
		return
	for appearance_node: PlateauXmlNode in scope_node.find_descendants("app:Appearance"):
		for texture_node: PlateauXmlNode in appearance_node.find_descendants("app:ParameterizedTexture"):
			var image_uri_node: PlateauXmlNode = texture_node.find_child("app:imageURI")
			if image_uri_node == null:
				continue
			var image_uri := image_uri_node.text_content()
			for tex_coord_node: PlateauXmlNode in texture_node.find_descendants("app:textureCoordinates"):
				var ring_ref: String = str(tex_coord_node.attributes.get("ring", ""))
				if not ring_ref.begins_with("#"):
					continue
				var ring_id := ring_ref.substr(1)
				var uv := _parse_uv_pairs(tex_coord_node.text_content())
				if not uv.is_empty():
					out_map[ring_id] = {"image_uri": image_uri, "uv": uv}

static func _parse_uv_pairs(text: String) -> Array:
	var normalized := text.replace("\n", " ").replace("\t", " ").replace("\r", " ")
	var numbers: Array = []
	for token in normalized.split(" ", false):
		numbers.append(token.to_float())
	var pairs: Array = []
	var i := 0
	while i + 1 < numbers.size():
		var u: float = numbers[i]
		var v: float = numbers[i + 1]
		pairs.append(Vector2(u, 1.0 - v if FLIP_V else v))
		i += 2
	return pairs
