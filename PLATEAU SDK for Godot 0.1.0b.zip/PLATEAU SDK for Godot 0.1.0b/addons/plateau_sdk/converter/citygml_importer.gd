## citygml_importer.gd
## Orchestration: finds .gml files, parses them, projects their
## coordinates, builds a mesh per building, and places everything in the
## scene currently open in the editor.
##
## Only recognizes bldg:Building / bldg:BuildingPart (see
## citygml_parser.gd): other categories (tran, brid, urf, ...) aren't
## errors, they just silently contribute 0 buildings if a non-building
## .gml sits in the scanned folder - no need to filter the input folder for
## this reason, but this is one category at a time for now (see README.md,
## current scope).
##
## Synchronous (blocking) processing, no threads in this version: for a few
## hundred buildings (a handful of meshes), expect a few seconds; beyond
## that, the editor may appear frozen during the import, with no
## intermediate progress reporting during processing itself (the same
## limitation already noted for extraction in the Datasets tab).
@tool
extends RefCounted
class_name PlateauCityGmlImporter

# Explicit references rather than bare class_name calls: avoids depending
# on whether Godot's global class list has refreshed yet after files were
# added outside the editor (the likely cause of a
# "Nonexistent function ... in base 'GDScript'" error on first use).
const XmlTree = preload("res://addons/plateau_sdk/core/xml_tree.gd")
const GmlFileFinder = preload("res://addons/plateau_sdk/core/gml_file_finder.gd")
const JGD2011Projection = preload("res://addons/plateau_sdk/core/jgd2011_projection.gd")
const CityGmlParser = preload("res://addons/plateau_sdk/converter/citygml_parser.gd")
const MeshBuilder = preload("res://addons/plateau_sdk/converter/mesh_builder.gd")
const TextureCache = preload("res://addons/plateau_sdk/converter/texture_cache.gd")

## input_path: a single .gml file OR a folder (recursively searched for
## every .gml it contains).
## target_lod: 0 to 4, or PlateauCityGmlParser.AUTO_LOD for the maximum
## available LOD (auto, detected
## per building, see citygml_parser.gd).
## zone_number: 1 to 19 (Japanese Plane Rectangular CS zone, see
## core/jgd2011_projection.gd).
## origin_lat / origin_lon: the point (degrees) placed at (0,0,0) in the
## Godot scene. This is meant to come from the shared project origin (see
## core/project_origin.gd) so it stays the same across imports, including
## the Ortho tab's ground plane, so everything lines up instead of each
## import re-centering independently.
## load_textures: if true, looks for app:appearance and applies any
## textures found (see appearance_parser.gd, texture_cache.gd); if false,
## textures are skipped entirely (flat color per surface type only, faster).
## generate_collision: if true, each building also gets a trimesh static
## collision body (MeshInstance3D.create_trimesh_collision()) - exact but
## can be slow/heavy to generate and to simulate for a large import; off
## by default.
##
## Scene layout: one Node3D per mesh code found ("<meshcode> PLATEAU 3D
## Data", e.g. "53391532 PLATEAU 3D Data"), each holding one Node3D per
## feature category found under it (e.g. "bldg", "brid"), each holding the
## MeshInstance3D nodes themselves. Mesh code and category are both read
## from each .gml file's own path (PLATEAU's own naming convention -
## "(meshcode)_(category)_(crs)_(option).gml" under "udx/(category)/" -
## confirmed in file_index.gd), not guessed from geometry.
##
## Returns { success, building_count, file_count, failed_files, message,
##           missing_textures: Array[String] }
static func import_to_scene(input_path: String, target_lod: int, zone_number: int,
		origin_lat: float, origin_lon: float, scene_root: Node3D, load_textures: bool = true,
		generate_collision: bool = false) -> Dictionary:
	var gml_files := GmlFileFinder.find(input_path)
	if gml_files.is_empty():
		return {
			"success": false, "building_count": 0, "file_count": 0, "failed_files": [],
			"missing_textures": [],
			"message": "No .gml file found under %s." % input_path,
		}

	var origin_xy := JGD2011Projection.get_xy(origin_lat, origin_lon, zone_number)
	# One shared cache for the whole import: a texture reused by several
	# buildings (common, large atlases) is only decoded once.
	var texture_cache := TextureCache.new()
	var mesh_code_regex := RegEx.new()
	mesh_code_regex.compile("(\\d{8})")

	# meshcode -> Node3D ("<meshcode> PLATEAU 3D Data")
	var mesh_root_nodes: Dictionary = {}
	# "<meshcode>|<category>" -> Node3D (category group under the mesh root)
	var category_nodes: Dictionary = {}

	var building_count := 0
	var failed_files: Array = []

	for gml_path: String in gml_files:
		var error_out: Array = [""]
		var xml_root := XmlTree.parse_file(gml_path, error_out)
		if xml_root == null:
			failed_files.append("%s (%s)" % [gml_path, str(error_out[0])])
			continue

		var gml_dir: String = gml_path.get_base_dir()
		var mesh_code := _mesh_code_from_filename(gml_path, mesh_code_regex)
		var category := _category_from_path(gml_path)
		var category_node := _get_or_create_category_node(mesh_code, category, scene_root, mesh_root_nodes, category_nodes)

		var buildings := CityGmlParser.parse_buildings(xml_root, target_lod, load_textures)
		for building in buildings:
			_project_building_in_place(building, zone_number, origin_xy)
			var local_origin_out: Array = [Vector3.ZERO]
			var mesh := MeshBuilder.build_mesh(building, texture_cache, gml_dir, local_origin_out)
			if mesh == null:
				continue
			var instance := MeshInstance3D.new()
			var gml_id: String = building["gml_id"]
			var lod_used: int = building.get("lod_used", target_lod)
			instance.name = "bldg_%s_lod%d" % [(gml_id if gml_id != "" else str(building_count)), lod_used]
			instance.mesh = mesh
			# Mesh vertices are stored relative to the building's own AABB
			# center (see mesh_builder.gd), not the project origin - so the
			# node's own position must carry that offset, or the building
			# would render in the wrong place. This also keeps the
			# selection gizmo/AABB centered on the building itself instead
			# of spanning out to the (possibly kilometers-away) project origin.
			instance.position = local_origin_out[0]
			instance.set_meta("gml_id", gml_id)
			instance.set_meta("lod_used", lod_used)
			if building["measured_height"] > 0.0:
				instance.set_meta("measured_height", building["measured_height"])
			category_node.add_child(instance)
			instance.owner = scene_root
			if generate_collision:
				# create_trimesh_collision() adds a StaticBody3D +
				# CollisionShape3D as children of instance, matching the
				# mesh exactly (as opposed to a box/convex approximation) -
				# exact but can be slow to generate and simulate for a
				# large number of detailed buildings.
				instance.create_trimesh_collision()
				_set_owner_recursive(instance, scene_root)
			building_count += 1

	var message := "%d building(s) imported from %d file(s) (%d failed)." % [
		building_count, gml_files.size() - failed_files.size(), failed_files.size()
	]
	var missing_textures := texture_cache.get_failed_paths()
	if not missing_textures.is_empty():
		message += " %d texture image(s) not found or unreadable (flat color used instead)." % missing_textures.size()

	return {
		"success": building_count > 0, "building_count": building_count,
		"file_count": gml_files.size(), "failed_files": failed_files, "message": message,
		"missing_textures": missing_textures,
	}

## Finds or creates the "<meshcode> PLATEAU 3D Data" > "<category>" node
## pair for a given .gml file, creating either or both as needed and
## registering them in mesh_root_nodes/category_nodes (both passed by
## reference and mutated) so later files reuse the same nodes instead of
## duplicating them.
static func _get_or_create_category_node(mesh_code: String, category: String, scene_root: Node3D,
		mesh_root_nodes: Dictionary, category_nodes: Dictionary) -> Node3D:
	var mesh_root: Node3D = mesh_root_nodes.get(mesh_code, null)
	if mesh_root == null:
		mesh_root = Node3D.new()
		mesh_root.name = "%s PLATEAU 3D Data" % mesh_code
		scene_root.add_child(mesh_root)
		mesh_root.owner = scene_root
		mesh_root_nodes[mesh_code] = mesh_root

	var cat_key := "%s|%s" % [mesh_code, category]
	var category_node: Node3D = category_nodes.get(cat_key, null)
	if category_node == null:
		category_node = Node3D.new()
		category_node.name = category
		mesh_root.add_child(category_node)
		category_node.owner = scene_root
		category_nodes[cat_key] = category_node

	return category_node

## Mesh code from the .gml file's OWN name (PLATEAU convention:
## "(meshcode)_(category)_(crs)_(option).gml"). "unknown" if the filename
## doesn't match (shouldn't normally happen for a real PLATEAU export, but
## degrades gracefully rather than crashing if it doesn't).
static func _mesh_code_from_filename(gml_path: String, mesh_code_regex: RegEx) -> String:
	var m := mesh_code_regex.search(gml_path.get_file())
	if m:
		return m.get_string(1)
	return "unknown"

## Category from the path segment directly under "udx/" (e.g. "bldg" in
## ".../udx/bldg/53391532_bldg_6697_op.gml"), matching the same convention
## file_index.gd uses to categorize zip entries. "misc" if "udx/" isn't
## found in the path at all (e.g. a .gml picked from some other location).
static func _category_from_path(gml_path: String) -> String:
	var idx := gml_path.find("/udx/")
	var after_udx: String
	if idx != -1:
		after_udx = gml_path.substr(idx + 5)
	elif gml_path.begins_with("udx/"):
		after_udx = gml_path.substr(4)
	else:
		return "misc"
	var slash_idx := after_udx.find("/")
	if slash_idx == -1:
		return "misc"
	return after_udx.substr(0, slash_idx)

static func _set_owner_recursive(node: Node, owner: Node) -> void:
	for child in node.get_children():
		child.owner = owner
		_set_owner_recursive(child, owner)

## Converts a building's lat/lon/height points (as returned by
## PlateauCityGmlParser) into local Godot coordinates, IN PLACE.
## Convention (shared with the Ortho tab): X = east, Y = height, Z = -north.
## An arbitrary choice made early on in this SDK: keeping the SAME
## convention here lets the Ortho and Buildings tabs line up without any
## flipping between them.
static func _project_building_in_place(building: Dictionary, zone_number: int, origin_xy: Vector2) -> void:
	for surface in building["surfaces"]:
		var rings: Array = surface["rings"]
		for ring_index in rings.size():
			var ring: Dictionary = rings[ring_index]
			var points: Array = ring["points"]
			var projected: Array = []
			for point in points:
				var p: Vector3 = point # (lat, lon, height) degrees/degrees/meters
				var xy := JGD2011Projection.get_xy(p.x, p.y, zone_number)
				var north := xy.x - origin_xy.x
				var east := xy.y - origin_xy.y
				projected.append(Vector3(east, p.z, -north))
			ring["points"] = projected
