## citygml_parser.gd
## Extracts buildings (bldg:Building and bldg:BuildingPart, possibly nested
## via bldg:consistsOfBuildingPart) and their geometry from an already-parsed
## CityGML XML tree (PlateauXmlNode, see core/xml_tree.gd).
##
## CityGML 2.0 structure confirmed against several independent real-world
## file examples during research for this SDK (see README.md for sources):
##   bldg:boundedBy > bldg:WallSurface|RoofSurface|GroundSurface|...
##     > bldg:lod{N}MultiSurface > gml:MultiSurface > gml:surfaceMember
##     > gml:Polygon > gml:exterior > gml:LinearRing > gml:posList
## and, for LOD1 (or as a fallback if a file doesn't classify its surfaces):
##   bldg:lod{N}Solid > gml:Solid > gml:exterior > gml:CompositeSurface
##     > gml:surfaceMember > gml:Polygon > ...
##
## For each building, looks FIRST for surfaces classified via boundedBy
## (gives both the geometry AND the type, useful for wall/roof/ground
## coloring in mesh_builder.gd). If no classified surface is found for the
## requested LOD, falls back to the raw Solid (a pattern seen in real
## CityGML datasets that sometimes place geometry directly in the Solid
## without going through boundedBy - "against the standard" but seen in
## practice - see
## https://en.wiki.quality.sig3d.org/index.php/Modeling_Guide_for_3D_Objects_-_Part_2:_Modeling_of_Buildings_(LoD1,_LoD2,_LoD3)).
@tool
extends RefCounted
class_name PlateauCityGmlParser

# Explicit reference rather than a bare class_name call: avoids depending
# on whether Godot's global class list has refreshed yet (see the more
# detailed comment in citygml_importer.gd).
const AppearanceParser = preload("res://addons/plateau_sdk/converter/appearance_parser.gd")

const BOUNDARY_SURFACE_TAGS := {
	"bldg:WallSurface": "wall",
	"bldg:RoofSurface": "roof",
	"bldg:GroundSurface": "ground",
	"bldg:OuterFloorSurface": "wall",
	"bldg:OuterCeilingSurface": "roof",
	"bldg:ClosureSurface": "wall",
}

## Returns Array[Dictionary] { gml_id: String, measured_height: float
## (-1.0 if absent), lod_used: int, surfaces: Array[Dictionary] { type:
## String, rings: Array[Dictionary{points:Array[Vector3], id:String}],
## texture: Dictionary{image_uri:String, uv:Array[Vector2]} or null } }.
## rings[0] = exterior ring, rings[1..] = interior rings (holes) - holes are
## collected but NOT subtracted by mesh_builder.gd in this version (see
## limitations, README.md). "texture" (if not null) applies to the exterior
## ring (rings[0]): see appearance_parser.gd. Point Vector3s are (latitude,
## longitude, height) in degrees/degrees/meters, NOT yet projected: the
## conversion to local meters happens in citygml_importer.gd, once every
## point is known (to pick a consistent scene origin).
##
## target_lod: 0 to 4, or AUTO_LOD (-99) to use, PER BUILDING, the most
## detailed LOD actually present (some notable buildings may be modeled at
## a higher LOD than the rest of the dataset - detection is therefore done
## building by building, not once for the whole file).
## Sentinel for "use the highest LOD available, per building" (see below).
## NOT -1: Godot's OptionButton.add_item(label, id) treats an id of
## exactly -1 as "auto-assign this item's id to its insertion index"
## (matching PopupMenu's own convention) rather than as a real custom id -
## an explicit id=-1 for the "maximum available" menu entry in
## dataset_panel.gd silently became a real (and meaningless) LOD number
## instead, which is why "maximum available LOD" imported nothing at all
## rather than falling back through LOD4/3/2/1/0 as intended. Any value
## that isn't -1 and isn't a real LOD number (0-4) works; -99 is arbitrary.
const AUTO_LOD := -99
const LOD_TRY_ORDER_FOR_AUTO := [4, 3, 2, 1, 0]

static func parse_buildings(root: PlateauXmlNode, target_lod: int, load_textures: bool = true) -> Array:
	var buildings: Array = []
	_collect_buildings(root, root, target_lod, load_textures, buildings)
	return buildings

static func _collect_buildings(node: PlateauXmlNode, document_root: PlateauXmlNode, target_lod: int, load_textures: bool, out_buildings: Array) -> void:
	for child: PlateauXmlNode in node.children:
		if child.tag == "bldg:Building" or child.tag == "bldg:BuildingPart":
			var b = _parse_one_building_with_lod(child, document_root, target_lod, load_textures)
			if b != null:
				out_buildings.append(b)
		# Keep descending in every case: bldg:BuildingPart is nested under
		# bldg:consistsOfBuildingPart inside a bldg:Building, so a Building
		# can contain other buildings (parts) to collect separately.
		_collect_buildings(child, document_root, target_lod, load_textures, out_buildings)

static func _parse_one_building_with_lod(building_node: PlateauXmlNode, document_root: PlateauXmlNode, target_lod: int, load_textures: bool) -> Variant:
	if target_lod == AUTO_LOD:
		for lod in LOD_TRY_ORDER_FOR_AUTO:
			var b = _parse_one_building(building_node, document_root, lod, load_textures)
			if b != null:
				b["lod_used"] = lod
				return b
		return null

	var b = _parse_one_building(building_node, document_root, target_lod, load_textures)
	if b != null:
		b["lod_used"] = target_lod
	return b

static func _parse_one_building(building_node: PlateauXmlNode, document_root: PlateauXmlNode, target_lod: int, load_textures: bool) -> Variant:
	var gml_id := str(building_node.attributes.get("gml:id", ""))
	var measured_height := -1.0
	var height_node := building_node.find_child("bldg:measuredHeight")
	if height_node != null:
		var h := height_node.text_content().to_float()
		if h > 0.0:
			measured_height = h

	var ring_texture_map := {}
	if load_textures:
		ring_texture_map = AppearanceParser.build_ring_texture_map(building_node, document_root)

	var surfaces: Array = []

	if target_lod == 0:
		# LOD0 has no volume: a completely different structure (a ground
		# footprint or roof outline, no boundedBy/Solid).
		surfaces = _extract_lod0_surfaces(building_node, ring_texture_map)
	else:
		surfaces = _extract_lod1plus_surfaces(building_node, target_lod, ring_texture_map)

	if surfaces.is_empty():
		return null

	return {"gml_id": gml_id, "measured_height": measured_height, "surfaces": surfaces}

## LOD0: bldg:lod0FootPrint (ground footprint) first, falling back to
## bldg:lod0RoofEdge (roof outline seen from above) if absent. Both are
## plain gml:MultiSurface elements with no wall/roof/ground classification
## (there's no volume at LOD0). Handled as a dedicated "footprint" surface
## type (see mesh_builder.gd) rather than "unclassified", so it stays
## visually distinct.
static func _extract_lod0_surfaces(building_node: PlateauXmlNode, ring_texture_map: Dictionary) -> Array:
	var surfaces: Array = []
	var source_node: PlateauXmlNode = building_node.find_child("bldg:lod0FootPrint")
	if source_node == null:
		source_node = building_node.find_child("bldg:lod0RoofEdge")
	if source_node != null:
		for polygon in _extract_polygons(source_node):
			surfaces.append(_build_surface_entry("footprint", polygon, ring_texture_map))
	return surfaces

## LOD1 to LOD4: looks FIRST for surfaces classified via boundedBy (gives
## both the geometry AND the type, useful for wall/roof/ground coloring in
## mesh_builder.gd). If no classified surface is found for the requested
## LOD, falls back to the raw Solid, then to a MultiSurface directly under
## the building (a pattern seen in real CityGML datasets that sometimes
## place geometry directly in the Solid, skipping boundedBy - "against the
## standard" but seen in practice - see
## https://en.wiki.quality.sig3d.org/index.php/Modeling_Guide_for_3D_Objects_-_Part_2:_Modeling_of_Buildings_(LoD1,_LoD2,_LoD3)).
## Generic regardless of LOD (1/2/3/4): the tag names always follow the
## same bldg:lod{N}MultiSurface / bldg:lod{N}Solid pattern. LOD4 (interior)
## is rarely populated in real PLATEAU datasets; if it's empty, this simply
## returns an empty array like any other absent LOD, not an error.
static func _extract_lod1plus_surfaces(building_node: PlateauXmlNode, target_lod: int, ring_texture_map: Dictionary) -> Array:
	var surfaces: Array = []

	for bounded_by: PlateauXmlNode in building_node.children:
		if bounded_by.tag != "bldg:boundedBy":
			continue
		for surface_node: PlateauXmlNode in bounded_by.children:
			var surface_type: String = BOUNDARY_SURFACE_TAGS.get(surface_node.tag, "")
			if surface_type == "":
				continue
			var multi_surface_node: PlateauXmlNode = surface_node.find_child("bldg:lod%dMultiSurface" % target_lod)
			if multi_surface_node == null:
				continue
			for polygon in _extract_polygons(multi_surface_node):
				surfaces.append(_build_surface_entry(surface_type, polygon, ring_texture_map))

	if surfaces.is_empty():
		var solid_node: PlateauXmlNode = building_node.find_child("bldg:lod%dSolid" % target_lod)
		if solid_node != null:
			for polygon in _extract_polygons(solid_node):
				surfaces.append(_build_surface_entry("unclassified", polygon, ring_texture_map))
		else:
			var direct_ms: PlateauXmlNode = building_node.find_child("bldg:lod%dMultiSurface" % target_lod)
			if direct_ms != null:
				for polygon in _extract_polygons(direct_ms):
					surfaces.append(_build_surface_entry("unclassified", polygon, ring_texture_map))

	return surfaces

## polygon: Dictionary { rings: Array[Dictionary{points, id}] } as returned
## by _extract_polygons(). Attaches the exterior ring's (rings[0]) texture
## if its id is present in ring_texture_map.
static func _build_surface_entry(surface_type: String, polygon: Dictionary, ring_texture_map: Dictionary) -> Dictionary:
	var rings: Array = polygon["rings"]
	var texture = null
	if not rings.is_empty():
		var outer_id: String = rings[0]["id"]
		if outer_id != "" and ring_texture_map.has(outer_id):
			texture = ring_texture_map[outer_id]
	return {"type": surface_type, "rings": rings, "texture": texture}

## Finds every gml:Polygon under this node, at any nesting depth, and
## returns { rings: Array[Dictionary{points,id}] } for each.
static func _extract_polygons(node: PlateauXmlNode) -> Array:
	var result: Array = []
	for polygon_node: PlateauXmlNode in node.find_descendants("gml:Polygon"):
		var rings: Array = []
		var exterior: PlateauXmlNode = polygon_node.find_child("gml:exterior")
		if exterior != null:
			var ring := _extract_ring(exterior)
			if (ring["points"] as Array).size() >= 3:
				rings.append(ring)
		for child: PlateauXmlNode in polygon_node.children:
			if child.tag == "gml:interior":
				var hole := _extract_ring(child)
				if (hole["points"] as Array).size() >= 3:
					rings.append(hole)
		if not rings.is_empty():
			result.append({"rings": rings})
	return result

## Returns { points: Array[Vector3], id: String }. id = the gml:LinearRing's
## gml:id (needed to attach a texture via appearance_parser.gd), an empty
## string if absent.
static func _extract_ring(exterior_or_interior_node: PlateauXmlNode) -> Dictionary:
	var linear_ring := exterior_or_interior_node.find_child("gml:LinearRing")
	if linear_ring == null:
		return {"points": [], "id": ""}

	var ring_id := str(linear_ring.attributes.get("gml:id", ""))

	var pos_list_node := linear_ring.find_child("gml:posList")
	if pos_list_node != null:
		var dimension := 3
		if pos_list_node.attributes.has("srsDimension"):
			dimension = int(pos_list_node.attributes["srsDimension"])
		return {"points": _parse_pos_list(pos_list_node.text_content(), dimension), "id": ring_id}

	# Fallback: individual gml:pos points rather than a single gml:posList
	# (seen in some generic CityGML examples, not necessarily PLATEAU,
	# handled defensively rather than assumed absent).
	var points: Array = []
	for pos_node: PlateauXmlNode in linear_ring.children:
		if pos_node.tag == "gml:pos":
			var coords := _parse_numbers(pos_node.text_content())
			if coords.size() >= 3:
				points.append(Vector3(coords[0], coords[1], coords[2]))
			elif coords.size() == 2:
				points.append(Vector3(coords[0], coords[1], 0.0))
	return {"points": points, "id": ring_id}

static func _parse_pos_list(text: String, dimension: int) -> Array:
	var numbers := _parse_numbers(text)
	var points: Array = []
	var stride: int = 3 if dimension != 2 else 2
	var i := 0
	while i + stride - 1 < numbers.size():
		if stride == 3:
			points.append(Vector3(numbers[i], numbers[i + 1], numbers[i + 2]))
		else:
			points.append(Vector3(numbers[i], numbers[i + 1], 0.0))
		i += stride
	return points

static func _parse_numbers(text: String) -> Array:
	var normalized := text.replace("\n", " ").replace("\t", " ").replace("\r", " ")
	var result: Array = []
	for token in normalized.split(" ", false):
		result.append(token.to_float())
	return result
