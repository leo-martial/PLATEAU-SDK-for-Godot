## mesh_builder.gd
## Triangulates a building's polygons (exterior rings only, see limitations
## below) and builds an ArrayMesh. One Godot surface is created per unique
## TEXTURE IMAGE used (for textured polygons), and one per TYPE
## (wall/roof/ground/unclassified) for polygons with no texture found,
## rendered as a flat color.
##
## Triangulation: each 3D polygon (assumed planar) is projected onto its own
## 2D plane via its normal (Newell's method, robust even for a slightly
## non-planar polygon due to floating-point rounding), then triangulated in
## 2D with Geometry2D.triangulate_polygon() (ear clipping, a native Godot
## class, no hole support). The resulting triangle indices are reapplied to
## the original 3D points AND, if present, to the same ring's UV
## coordinates (same order, same point count - see appearance_parser.gd).
##
## KNOWN LIMITATIONS:
## - Interior rings (holes, e.g. a courtyard) are ignored: a polygon with a
##   hole is filled as if it had none.
## - The per-triangle normal direction (via edge cross product) hasn't been
##   verified in a real Godot editor: if lighting looks inverted on some
##   faces, try negating the sign (-normal) in _triangulate_ring(). To keep
##   a face from simply disappearing due to a wrong winding, the material
##   disables cull_mode by default (both sides rendered, a bit more
##   expensive but safer until this is verified).
## - One texture per polygon, no atlas recomputation: if PLATEAU already
##   provides one large shared atlas (the common case), it's reused as-is
##   with its original UVs, no image reprocessing on our side.
@tool
extends RefCounted
class_name PlateauMeshBuilder

const SURFACE_COLORS := {
	"wall": Color(0.82, 0.80, 0.75),
	"roof": Color(0.65, 0.35, 0.30),
	"ground": Color(0.55, 0.55, 0.50),
	"footprint": Color(0.80, 0.75, 0.45), # LOD0: no volume, just the ground footprint - distinct color so it isn't mistaken for a broken LOD1+ import
	"unclassified": Color(0.75, 0.75, 0.75),
}

## building: { gml_id, measured_height, surfaces: Array[{ type, rings,
## texture }] } with Vector3s ALREADY in local Godot coordinates (meters,
## see citygml_importer.gd for the projection). texture_cache: shared
## across buildings so each image is only decoded once (see
## texture_cache.gd). gml_dir: the current .gml file's folder (image URIs
## are relative to it). local_origin_out: optional 1+-element Array passed
## by reference - if provided, local_origin_out[0] receives the building's
## AABB center in the SAME coordinate space the input vertices were given
## in, and every vertex actually stored in the returned mesh is shifted by
## -that offset (see below for why). Returns an ArrayMesh, or null if no
## triangle could be generated (empty or degenerate geometry).
static func build_mesh(building: Dictionary, texture_cache: PlateauTextureCache, gml_dir: String, local_origin_out: Array = []) -> ArrayMesh:
	# bucket_key -> { verts: PackedVector3Array, normals: PackedVector3Array,
	#                 uvs: PackedVector2Array, textured: bool, ref: String
	#                 (surface type for flat color, image_uri if textured) }
	var buckets: Dictionary = {}

	for surface in building["surfaces"]:
		var surface_type: String = surface["type"]
		var rings: Array = surface["rings"]
		if rings.is_empty():
			continue
		var outer_ring: Dictionary = rings[0]
		var points: Array = outer_ring["points"]

		var texture = surface.get("texture", null)
		var uv_source: Array = []
		var bucket_key: String
		var textured: bool
		var bucket_ref: String
		if texture != null and (texture["uv"] as Array).size() == points.size():
			uv_source = texture["uv"]
			bucket_key = "tex:%s" % str(texture["image_uri"])
			textured = true
			bucket_ref = str(texture["image_uri"])
		else:
			bucket_key = "flat:%s" % surface_type
			textured = false
			bucket_ref = surface_type

		var triangulated := _triangulate_ring(points, uv_source)
		var tri_positions: Array = triangulated["positions"]
		if tri_positions.is_empty():
			continue
		var tri_uvs: Array = triangulated["uvs"]

		if not buckets.has(bucket_key):
			buckets[bucket_key] = {
				"verts": PackedVector3Array(), "normals": PackedVector3Array(),
				"uvs": PackedVector2Array(), "textured": textured, "ref": bucket_ref,
			}
		var bucket: Dictionary = buckets[bucket_key]
		var verts: PackedVector3Array = bucket["verts"]
		var normals: PackedVector3Array = bucket["normals"]
		var uvs: PackedVector2Array = bucket["uvs"]

		var i := 0
		while i + 2 < tri_positions.size():
			var a: Vector3 = tri_positions[i]
			var b: Vector3 = tri_positions[i + 1]
			var c: Vector3 = tri_positions[i + 2]
			var normal := (b - a).cross(c - a)
			if normal.length_squared() > 0.0:
				normal = normal.normalized()
			verts.append(a)
			verts.append(b)
			verts.append(c)
			normals.append(normal)
			normals.append(normal)
			normals.append(normal)
			if textured:
				uvs.append(tri_uvs[i])
				uvs.append(tri_uvs[i + 1])
				uvs.append(tri_uvs[i + 2])
			i += 3

	if buckets.is_empty():
		return null

	# The vertices collected above are still expressed relative to the
	# shared PROJECT origin, which can be kilometers away from any given
	# building. Leaving that as the mesh's own local origin means Godot's
	# selection gizmo/AABB for this MeshInstance3D spans all the way from
	# the project origin to the building itself - a huge, unwieldy
	# selection box centered nowhere near the actual building. Recenter
	# every vertex around the building's own AABB center instead, and hand
	# that offset back via local_origin_out so citygml_importer.gd can set
	# it as the MeshInstance3D's own .position, keeping the building in
	# the same world position while its local geometry - and therefore its
	# gizmo - stays centered on itself.
	var aabb_min := Vector3(INF, INF, INF)
	var aabb_max := Vector3(-INF, -INF, -INF)
	for bucket_key in buckets:
		var verts: PackedVector3Array = buckets[bucket_key]["verts"]
		for v in verts:
			aabb_min.x = minf(aabb_min.x, v.x)
			aabb_min.y = minf(aabb_min.y, v.y)
			aabb_min.z = minf(aabb_min.z, v.z)
			aabb_max.x = maxf(aabb_max.x, v.x)
			aabb_max.y = maxf(aabb_max.y, v.y)
			aabb_max.z = maxf(aabb_max.z, v.z)
	var local_origin := (aabb_min + aabb_max) / 2.0
	if local_origin_out.size() > 0:
		local_origin_out[0] = local_origin

	var mesh := ArrayMesh.new()
	var keys := buckets.keys()
	keys.sort() # stable order from one import to the next
	for bucket_key in keys:
		var bucket: Dictionary = buckets[bucket_key]
		var verts: PackedVector3Array = bucket["verts"]
		if verts.is_empty():
			continue
		var recentered_verts := PackedVector3Array()
		for v in verts:
			recentered_verts.append(v - local_origin)
		var arrays := []
		arrays.resize(Mesh.ARRAY_MAX)
		arrays[Mesh.ARRAY_VERTEX] = recentered_verts
		arrays[Mesh.ARRAY_NORMAL] = bucket["normals"]

		var mat := StandardMaterial3D.new()
		mat.roughness = 0.9
		mat.cull_mode = BaseMaterial3D.CULL_DISABLED

		if bucket["textured"]:
			var tex := texture_cache.get_texture(gml_dir, bucket["ref"])
			if tex != null:
				arrays[Mesh.ARRAY_TEX_UV] = bucket["uvs"]
				mat.albedo_texture = tex
				mat.albedo_color = Color.WHITE
			else:
				# Image not found/unreadable (see texture_cache.get_failed_paths()):
				# a neutral color rather than an invisible or black building.
				mat.albedo_color = Color(0.7, 0.7, 0.7)
		else:
			mat.albedo_color = SURFACE_COLORS.get(bucket["ref"], Color(0.7, 0.7, 0.7))

		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
		var surf_idx := mesh.get_surface_count() - 1
		mesh.surface_set_material(surf_idx, mat)

	return mesh

## Triangulates a ring (a list of Vector3, closed or not - a repeated first
## point at the end is tolerated and removed) and, if uv_ring is the same
## size as ring, triangulates the UVs in parallel using the same indices.
## Returns { positions: Array[Vector3], uvs: Array[Vector2] } (flat lists, 3
## entries per triangle) in the original 3D space (not reprojected). uvs is
## empty if uv_ring didn't match.
static func _triangulate_ring(ring: Array, uv_ring: Array) -> Dictionary:
	var empty_result := {"positions": [], "uvs": []}

	var points: Array = ring.duplicate()
	var uvs: Array = uv_ring.duplicate()
	var has_uv := uvs.size() == points.size()

	if points.size() >= 2 and (points[0] as Vector3).is_equal_approx(points[points.size() - 1]):
		points.resize(points.size() - 1)
		if has_uv:
			uvs.resize(uvs.size() - 1)
	if points.size() < 3:
		return empty_result

	var normal := Vector3.ZERO
	for i in points.size():
		var p1: Vector3 = points[i]
		var p2: Vector3 = points[(i + 1) % points.size()]
		normal.x += (p1.y - p2.y) * (p1.z + p2.z)
		normal.y += (p1.z - p2.z) * (p1.x + p2.x)
		normal.z += (p1.x - p2.x) * (p1.y + p2.y)
	if normal.length_squared() < 1e-12:
		return empty_result # collinear or degenerate points: nothing to triangulate
	normal = normal.normalized()

	var arbitrary := Vector3.UP
	if absf(normal.dot(arbitrary)) > 0.99:
		arbitrary = Vector3.RIGHT
	var u := normal.cross(arbitrary).normalized()
	var v := normal.cross(u).normalized()

	var points_2d := PackedVector2Array()
	for p in points:
		points_2d.append(Vector2((p as Vector3).dot(u), (p as Vector3).dot(v)))

	var indices := Geometry2D.triangulate_polygon(points_2d)
	if indices.is_empty():
		return empty_result

	var result_positions: Array = []
	var result_uvs: Array = []
	for idx in indices:
		result_positions.append(points[idx])
		if has_uv:
			result_uvs.append(uvs[idx])
	return {"positions": result_positions, "uvs": result_uvs}
