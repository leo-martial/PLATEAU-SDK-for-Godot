## texture_cache.gd
## Loads and caches textures referenced by CityGML files. The same image
## (often a large atlas) can be referenced by dozens of polygons across
## several buildings: avoids reloading and re-decoding it every time.
##
## Loads raw bytes via Image.load() rather than load()/preload() on a
## res:// path: avoids depending on Godot's import pipeline (which might
## not have re-imported files just extracted by the Datasets tab yet) and
## works the same whether the path is inside res:// or not.
@tool
extends RefCounted
class_name PlateauTextureCache

var _cache: Dictionary = {}   # absolute path -> Texture2D (or null on failure, cached so it isn't retried)
var _failed: Array = []       # failed paths, for the end-of-import message

## gml_dir: the folder containing the .gml file (imageURI values are
## relative to it, the standard XML/GML relative-URI resolution convention).
func get_texture(gml_dir: String, image_uri: String) -> Texture2D:
	var abs_path := gml_dir.path_join(image_uri)
	if _cache.has(abs_path):
		return _cache[abs_path]

	var tex: Texture2D = null
	if FileAccess.file_exists(abs_path):
		var img := Image.new()
		var err := img.load(abs_path)
		if err == OK:
			tex = ImageTexture.create_from_image(img)

	if tex == null:
		_failed.append(abs_path)
	_cache[abs_path] = tex
	return tex

func get_failed_paths() -> Array:
	return _failed
