## gml_file_finder.gd
## Recursively finds .gml files under a folder, or wraps a single .gml file
## path into a one-element list. Shared by the Buildings tab importer and
## the origin/zone auto-detection helper (origin_finder.gd) - previously
## duplicated inside citygml_importer.gd alone.
@tool
extends RefCounted
class_name PlateauGmlFileFinder

static func find(input_path: String) -> Array[String]:
	var result: Array[String] = []
	if input_path.ends_with(".gml"):
		if FileAccess.file_exists(input_path):
			result.append(input_path)
		return result
	_scan_dir(input_path, result)
	result.sort()
	return result

static func _scan_dir(dir_path: String, out_files: Array[String]) -> void:
	var dir := DirAccess.open(dir_path)
	if dir == null:
		return
	dir.list_dir_begin()
	var entry := dir.get_next()
	while entry != "":
		if entry != "." and entry != "..":
			var full_path := dir_path.path_join(entry)
			if dir.current_is_dir():
				_scan_dir(full_path, out_files)
			elif entry.ends_with(".gml"):
				out_files.append(full_path)
		entry = dir.get_next()
	dir.list_dir_end()
