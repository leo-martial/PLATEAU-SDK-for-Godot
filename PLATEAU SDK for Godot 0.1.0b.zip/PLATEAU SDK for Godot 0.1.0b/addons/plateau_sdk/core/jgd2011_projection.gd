## jgd2011_projection.gd
## Projection to the Japanese Plane Rectangular Coordinate System
## (平面直角座標系, JGD2011, GRS80 ellipsoid, 19 zones). Shared by the Ortho
## tab (ground plane placement) and the Buildings tab (CityGML geometry
## placement) - this is the single source of truth for turning
## latitude/longitude into local meters anywhere in this SDK.
##
## Direct implementation of the official formula published by GSI (Geospatial
## Information Authority of Japan) - simplified Gauss-Krüger method by
## Kazushige Kawase:
## https://vldb.gsi.go.jp/sokuchi/surveycalc/surveycalc/algorithm/bl2xy/bl2xy.htm
## Full reference: Kawase, K. (2011), Bulletin of the GSI, 121, 109-124,
## doi: 10.57499/JOURNAL_121_12 - https://www.gsi.go.jp/common/000061216.pdf
##
## The 19-zone origin table is taken verbatim from the official notice
## (MLIT Notice No. 9 of 2002, 平成十四年国土交通省告示第九号):
## https://www.gsi.go.jp/LAW/heimencho.html
##
## Not verified against an external reference calculation in this
## environment (no access to an external calc tool here): before relying on
## this for serious work, check at least one known point against the
## official calculator
## https://vldb.gsi.go.jp/sokuchi/surveycalc/surveycalc/bl2xyf.html (paste a
## known lat/lon and its zone, compare the X/Y it gives to get_xy() below).
@tool
extends RefCounted
class_name PlateauJGD2011Projection

## GRS80 ellipsoid (JGD2011 is defined on it).
const SEMI_MAJOR_AXIS := 6378137.0
const INVERSE_FLATTENING := 298.257222101
const AXIS_SCALE_FACTOR := 0.9999 # m0, scale factor on the central meridian

## Origin of each of the 19 zones (lon, lat in decimal degrees), taken from
## MLIT Notice No. 9. Index 0 = Zone I, ... index 18 = Zone XIX (the usual
## zone number runs 1 to 19, hence origins[zone_number - 1]).
const ZONE_ORIGINS := [
	{"lon": 129.0 + 30.0 / 60.0, "lat": 33.0},                    # I
	{"lon": 131.0, "lat": 33.0},                                   # II
	{"lon": 132.0 + 10.0 / 60.0, "lat": 36.0},                     # III
	{"lon": 133.0 + 30.0 / 60.0, "lat": 33.0},                     # IV
	{"lon": 134.0 + 20.0 / 60.0, "lat": 36.0},                     # V
	{"lon": 136.0, "lat": 36.0},                                   # VI
	{"lon": 137.0 + 10.0 / 60.0, "lat": 36.0},                     # VII
	{"lon": 138.0 + 30.0 / 60.0, "lat": 36.0},                     # VIII
	{"lon": 139.0 + 50.0 / 60.0, "lat": 36.0},                     # IX (Kanto/Tokyo)
	{"lon": 140.0 + 50.0 / 60.0, "lat": 40.0},                     # X
	{"lon": 140.0 + 15.0 / 60.0, "lat": 44.0},                     # XI
	{"lon": 142.0 + 15.0 / 60.0, "lat": 44.0},                     # XII
	{"lon": 144.0 + 15.0 / 60.0, "lat": 44.0},                     # XIII
	{"lon": 142.0, "lat": 26.0},                                   # XIV
	{"lon": 127.0 + 30.0 / 60.0, "lat": 26.0},                     # XV
	{"lon": 124.0, "lat": 26.0},                                   # XVI
	{"lon": 131.0, "lat": 26.0},                                   # XVII
	{"lon": 136.0, "lat": 20.0},                                   # XVIII
	{"lon": 154.0, "lat": 26.0},                                   # XIX
]

## Converts latitude/longitude (WGS84/JGD2011, decimal degrees) into a plane
## position (X = north-positive, Y = east-positive, meters) relative to the
## origin of zone_number (1 to 19).
static func get_xy(lat_deg: float, lon_deg: float, zone_number: int) -> Vector2:
	var origin: Dictionary = ZONE_ORIGINS[clampi(zone_number, 1, 19) - 1]
	var origin_lat: float = origin["lat"]
	var origin_lon: float = origin["lon"]
	return _bl_to_xy(deg_to_rad(lat_deg), deg_to_rad(lon_deg), deg_to_rad(origin_lat), deg_to_rad(origin_lon))

## Suggests the zone number (1-19) whose origin meridian is closest.
## APPROXIMATION: the official assignment follows prefectural/administrative
## boundaries (see MLIT Notice No. 9), not pure geometric distance. Reliable
## in most cases since each zone only covers a narrow band (~130km either
## side of its meridian), but double-check near a boundary between two zones.
static func suggest_zone(lat_deg: float, lon_deg: float) -> int:
	var best_zone := 9
	var best_dist := INF
	for i in ZONE_ORIGINS.size():
		var origin: Dictionary = ZONE_ORIGINS[i]
		var dlat: float = lat_deg - float(origin["lat"])
		var dlon: float = lon_deg - float(origin["lon"])
		var dist: float = dlat * dlat + dlon * dlon
		if dist < best_dist:
			best_dist = dist
			best_zone = i + 1
	return best_zone

## --- Hand-rolled hyperbolic functions ------------------------------------
## `atanh` is not guaranteed to exist as a GDScript global function (unlike
## sinh/cosh/tanh, added in Godot 4, which are more likely present but also
## unverified here): out of caution, everything is reimplemented from
## exp()/log(), base functions guaranteed to exist, so this doesn't depend
## on any unconfirmed hyperbolic built-in.
static func _sinh(x: float) -> float:
	return (exp(x) - exp(-x)) / 2.0

static func _cosh(x: float) -> float:
	return (exp(x) + exp(-x)) / 2.0

static func _atanh(x: float) -> float:
	return 0.5 * log((1.0 + x) / (1.0 - x))

## --- Formula implementation (everything in radians internally) ----------

static func _bl_to_xy(phi: float, lambda: float, phi0: float, lambda0: float) -> Vector2:
	var f := INVERSE_FLATTENING
	var a := SEMI_MAJOR_AXIS
	var m0 := AXIS_SCALE_FACTOR
	var n := 1.0 / (2.0 * f - 1.0)

	var alpha := _alpha_coefficients(n)
	var big_a := (m0 * a) / (1.0 + n) * _a0(n)
	var s_phi0 := big_a * phi0 + (m0 * a) / (1.0 + n) * _sum_aj_sin2j(n, phi0)

	var sqrt_n := sqrt(n)
	var two_sqrt_n_over_1pn := 2.0 * sqrt_n / (1.0 + n)
	var t := _sinh(_atanh(sin(phi)) - two_sqrt_n_over_1pn * _atanh(two_sqrt_n_over_1pn * sin(phi)))
	var t_bar := sqrt(1.0 + t * t)

	var lambda_c := cos(lambda - lambda0)
	var lambda_s := sin(lambda - lambda0)
	var xi := atan(t / lambda_c)
	var eta := _atanh(lambda_s / t_bar)

	var x_sum := 0.0
	var y_sum := 0.0
	for j in range(1, 6):
		x_sum += alpha[j - 1] * sin(2.0 * j * xi) * _cosh(2.0 * j * eta)
		y_sum += alpha[j - 1] * cos(2.0 * j * xi) * _sinh(2.0 * j * eta)

	var x := big_a * (xi + x_sum) - s_phi0
	var y := big_a * (eta + y_sum)
	return Vector2(x, y)

static func _a0(n: float) -> float:
	return 1.0 + n * n / 4.0 + n * n * n * n / 64.0

## Coefficients A_j (j=1..5), used only for S_phi0 (meridian arc length from
## the equator to the zone origin).
static func _sum_aj_sin2j(n: float, phi0: float) -> float:
	var n2 := n * n
	var n3 := n2 * n
	var n4 := n3 * n
	var n5 := n4 * n
	var a1 := -1.5 * (n - n3 / 8.0 - n5 / 64.0)
	var a2 := 15.0 / 16.0 * (n2 - n4 / 4.0)
	var a3 := -35.0 / 48.0 * (n3 - 5.0 / 16.0 * n5)
	var a4 := 315.0 / 512.0 * n4
	var a5 := -693.0 / 1280.0 * n5
	return (a1 * sin(2.0 * phi0) + a2 * sin(4.0 * phi0) + a3 * sin(6.0 * phi0)
		+ a4 * sin(8.0 * phi0) + a5 * sin(10.0 * phi0))

## Coefficients alpha_j (j=1..5), used to project the point itself.
static func _alpha_coefficients(n: float) -> Array[float]:
	var n2 := n * n
	var n3 := n2 * n
	var n4 := n3 * n
	var n5 := n4 * n
	var a1 := 0.5 * n - (2.0 / 3.0) * n2 + (5.0 / 16.0) * n3 + (41.0 / 180.0) * n4 - (127.0 / 288.0) * n5
	var a2 := (13.0 / 48.0) * n2 - (3.0 / 5.0) * n3 + (557.0 / 1440.0) * n4 + (281.0 / 630.0) * n5
	var a3 := (61.0 / 240.0) * n3 - (103.0 / 140.0) * n4 + (15061.0 / 26880.0) * n5
	var a4 := (49561.0 / 161280.0) * n4 - (179.0 / 168.0) * n5
	var a5 := (34729.0 / 80640.0) * n5
	var result: Array[float] = [a1, a2, a3, a4, a5]
	return result
