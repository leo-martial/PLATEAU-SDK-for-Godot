## mesh_code_math.gd
## Converts a Japanese regional mesh code (JIS X0410, "3rd-level mesh" /
## base grid, 8 digits, roughly 1km per side - this is the code used in
## PLATEAU CityGML file names) into its geographic bounds (latitude/
## longitude).
##
## Standard algorithm (successive subdivision of the 1st-level mesh into
## 8x8 then 10x10), checked against a reference implementation published
## with source code: https://nttdocomo-developers.jp/entry/2025/12/18/090000_6
## See also the official definition (Statistics Bureau of Japan):
## https://www.stat.go.jp/data/mesh/m_tuite.html
##
## Only handles 8-digit codes (base mesh), the only ones used in PLATEAU
## CityGML file names (confirmed by multiple sources, see file_index.gd).
## 4- or 6-digit codes (1st/2nd-level meshes, larger) are not needed here.
@tool
extends RefCounted
class_name PlateauMeshCodeMath

## Returns { min_lat, min_lon, max_lat, max_lon } (degrees), or null if
## mesh_code isn't a usable 8-digit string (e.g. "?", an unresolved code
## from a filename with no 8-digit pattern found).
static func bounds_8digit(mesh_code: String) -> Variant:
	if mesh_code.length() != 8 or not mesh_code.is_valid_int():
		return null

	var lat_delta := 2.0 / 3.0
	var lon_delta := 1.0
	var lat := float(mesh_code.substr(0, 2).to_int()) * lat_delta
	var lon := float(mesh_code.substr(2, 2).to_int()) + 100.0

	lat_delta /= 8.0
	lon_delta /= 8.0
	lat += float(mesh_code.substr(4, 1).to_int()) * lat_delta
	lon += float(mesh_code.substr(5, 1).to_int()) * lon_delta

	lat_delta /= 10.0
	lon_delta /= 10.0
	lat += float(mesh_code.substr(6, 1).to_int()) * lat_delta
	lon += float(mesh_code.substr(7, 1).to_int()) * lon_delta

	return {
		"min_lat": lat, "min_lon": lon,
		"max_lat": lat + lat_delta, "max_lon": lon + lon_delta,
	}
