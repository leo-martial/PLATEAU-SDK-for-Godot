## origin_finder.gd
## Scans a .gml file (or the first .gml file under a folder) for coordinate
## data and suggests a scene origin (lat/lon) and JGD2011 zone number from
## it. Backs the "Detect from file..." button in the shared Project Setup
## panel, so the person doesn't have to look up coordinates or zone numbers
## by hand before importing anything.
@tool
extends RefCounted
class_name PlateauOriginFinder

# Explicit preload rather than relying on bare class_name references across
# files: avoids depending on whether Godot's global class list has been
# refreshed yet after files were added outside the editor (a real failure
# mode hit repeatedly while building this SDK - see README.md, Troubleshooting).
const GmlFileFinder = preload("res://addons/plateau_sdk/core/gml_file_finder.gd")
const XmlTree = preload("res://addons/plateau_sdk/core/xml_tree.gd")
const JGD2011Projection = preload("res://addons/plateau_sdk/core/jgd2011_projection.gd")

## Returns { lat: float, lon: float, zone: int }, or null if no coordinate
## could be read from the file(s) under input_path.
static func suggest(input_path: String) -> Variant:
	var gml_files := GmlFileFinder.find(input_path)
	if gml_files.is_empty():
		return null

	var sum_lat := 0.0
	var sum_lon := 0.0
	var count := 0
	# One file is enough for a reasonable estimate: no need to parse
	# everything just for this.
	var error_out: Array = [""]
	var xml_root := XmlTree.parse_file(gml_files[0], error_out)
	if xml_root == null:
		return null

	# Looks at any gml:posList in the file, not just building geometry:
	# simpler, and good enough for an approximate center estimate.
	for pos_list_node: PlateauXmlNode in xml_root.find_descendants("gml:posList"):
		var dimension := 3
		if pos_list_node.attributes.has("srsDimension"):
			dimension = int(pos_list_node.attributes["srsDimension"])
		var numbers: Array = []
		for token in pos_list_node.text_content().replace("\n", " ").split(" ", false):
			numbers.append(token.to_float())
		var stride: int = 3 if dimension != 2 else 2
		var i := 0
		while i + stride - 1 < numbers.size():
			sum_lat += numbers[i]
			sum_lon += numbers[i + 1]
			count += 1
			i += stride
		if count > 500:
			break # sample is big enough, no need to read the whole file

	if count == 0:
		return null

	var lat := sum_lat / count
	var lon := sum_lon / count
	return {"lat": lat, "lon": lon, "zone": JGD2011Projection.suggest_zone(lat, lon)}
