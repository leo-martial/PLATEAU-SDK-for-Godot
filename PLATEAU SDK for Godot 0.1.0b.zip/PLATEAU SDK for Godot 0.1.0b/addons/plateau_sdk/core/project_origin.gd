## project_origin.gd
## Holds the single shared "where is (0,0,0) in the scene, and which JGD2011
## zone" setting used by every tab in this SDK. Previously each of the three
## separate addons had its own origin/zone fields, which was both tedious
## (typing the same numbers three times) and risky (easy to let them drift
## out of sync, causing imports to silently misalign). One instance of this
## class is created by main_panel.gd and handed to every sub-panel.
@tool
extends RefCounted
class_name PlateauProjectOrigin

signal changed()

var zone: int = 9   # defaults to Zone IX (Kanto/Tokyo), overridden by "Detect from file..."
var lat: float = 0.0
var lon: float = 0.0

func set_origin(new_zone: int, new_lat: float, new_lon: float) -> void:
	zone = new_zone
	lat = new_lat
	lon = new_lon
	changed.emit()

## True once the origin has actually been set to something other than the
## (0,0) placeholder. Used by main_panel.gd to decide whether to
## auto-populate the origin after a dataset extraction, without overwriting
## a value the person already set on purpose.
func is_default() -> bool:
	return lat == 0.0 and lon == 0.0
