## scene_geometry_utils.gd
## Reads geometry already present in the currently edited scene - imported
## buildings (from the "3D (PLATEAU)" tab) and the Ortho ground plane
## (from the "2D (PLATEAU Ortho)" tab) - for two purposes: matching a
## ground plane's height to actual building elevations (used by
## ortho_panel.gd), and drawing/placing on the Exploration tab's top-down
## schematic map (used by scene_top_view.gd / exploration_panel.gd).
##
## Deliberately geometric rather than physics-based (no raycasting against
## collision shapes): editor-time physics queries against the edited
## scene are not reliably available outside of Play mode, so this reads
## node positions and mesh AABBs directly instead - correct as long as
## imported nodes keep the plain, unrotated transforms this SDK always
## gives them (true for every node this SDK creates, see
## citygml_importer.gd and ortho_panel.gd).
@tool
extends RefCounted
class_name PlateauSceneGeometryUtils

## World-space Y of the lowest vertex among every imported building
## (MeshInstance3D nodes named "bldg_...", see citygml_importer.gd) found
## under scene_root, or null if none are found.
static func find_lowest_building_y(scene_root: Node) -> Variant:
	return _find_lowest_building_y_recursive(scene_root)

static func _find_lowest_building_y_recursive(node: Node) -> Variant:
	var lowest = null
	if node is MeshInstance3D and node.name.begins_with("bldg_"):
		var mi := node as MeshInstance3D
		if mi.mesh != null:
			# mi.position.y is the building's own local origin in world
			# space (mesh vertices are stored relative to it, see
			# mesh_builder.gd/citygml_importer.gd), and mi.mesh.get_aabb()
			# is that same mesh's bounding box in ITS local space - added
			# together, the lowest vertex in world space.
			lowest = mi.position.y + mi.mesh.get_aabb().position.y
	for child in node.get_children():
		var child_lowest = _find_lowest_building_y_recursive(child)
		if child_lowest != null and (lowest == null or child_lowest < lowest):
			lowest = child_lowest
	return lowest

## Every imported building's world-space XZ footprint (from its mesh AABB)
## and world-space Y range, for drawing a top-down schematic. Returns
## Array[Dictionary] { min_x, max_x, min_z, max_z, min_y, max_y, name }.
static func collect_building_footprints(scene_root: Node) -> Array:
	var result: Array = []
	_collect_footprints_recursive(scene_root, result)
	return result

static func _collect_footprints_recursive(node: Node, out_result: Array) -> void:
	if node is MeshInstance3D and node.name.begins_with("bldg_"):
		var mi := node as MeshInstance3D
		if mi.mesh != null:
			var aabb: AABB = mi.mesh.get_aabb()
			var world_min := mi.position + aabb.position
			var world_max := mi.position + aabb.position + aabb.size
			out_result.append({
				"min_x": minf(world_min.x, world_max.x), "max_x": maxf(world_min.x, world_max.x),
				"min_z": minf(world_min.z, world_max.z), "max_z": maxf(world_min.z, world_max.z),
				"min_y": minf(world_min.y, world_max.y), "max_y": maxf(world_min.y, world_max.y),
				"name": str(node.name),
			})
	for child in node.get_children():
		_collect_footprints_recursive(child, out_result)

## The Ortho ground plane's world extent and height, if one exists in the
## scene (see ortho_panel.gd, node named "PlateauOrthoGround"). Returns
## { min_x, max_x, min_z, max_z, y } or null if not found.
static func find_ground_plane(scene_root: Node) -> Variant:
	var node := scene_root.get_node_or_null("PlateauOrthoGround")
	if node == null or not (node is MeshInstance3D):
		return null
	var mi := node as MeshInstance3D
	if mi.mesh == null or not (mi.mesh is PlaneMesh):
		return null
	var plane := mi.mesh as PlaneMesh
	var half := plane.size / 2.0
	return {
		"min_x": mi.position.x - half.x, "max_x": mi.position.x + half.x,
		"min_z": mi.position.z - half.y, "max_z": mi.position.z + half.y,
		"y": mi.position.y,
	}
