## tile_math.gd
## Conversions between geographic coordinates (WGS84, degrees) and the
## "Web Mercator / Google" XYZ tile scheme (same scheme used by
## OpenStreetMap, PLATEAU-Ortho, and GSI tiles). Shared by the Ortho tab
## (imagery tiles) and the Dataset tab's mesh grid map (basemap tiles) -
## previously duplicated as two separate files when the two addons were
## developed independently; merged here now that they live in one SDK.
## Reference: https://wiki.openstreetmap.org/wiki/Slippy_map_tilenames
@tool
extends RefCounted
class_name PlateauTileMath

const TILE_SIZE := 256

## Longitude/latitude (degrees) -> fractional tile indices (x, y).
## The integer part is the tile index; the fractional part is the
## position inside that tile (useful for panning).
static func lonlat_to_tile_f(lon_deg: float, lat_deg: float, zoom: int) -> Vector2:
	var lat_rad := deg_to_rad(clampf(lat_deg, -85.05112878, 85.05112878))
	var n := pow(2.0, zoom)
	var x := (lon_deg + 180.0) / 360.0 * n
	var y := (1.0 - log(tan(lat_rad) + 1.0 / cos(lat_rad)) / PI) / 2.0 * n
	return Vector2(x, y)

## Tile indices (x, y), possibly fractional -> longitude/latitude (degrees).
static func tile_to_lonlat_f(tx: float, ty: float, zoom: int) -> Vector2:
	var n := pow(2.0, zoom)
	var lon := tx / n * 360.0 - 180.0
	var lat_rad := atan(sinh(PI * (1.0 - 2.0 * ty / n)))
	return Vector2(lon, rad_to_deg(lat_rad))

## Approximate ground resolution (meters per pixel) at a given latitude and
## zoom. Standard Web Mercator tile formula (256 px/tile).
## https://wiki.openstreetmap.org/wiki/Zoom_levels
## Only used for display/estimation purposes (e.g. "~30cm/px at this zoom")
## - NOT used for placing geometry, which goes through the real JGD2011
## projection in jgd2011_projection.gd instead.
static func meters_per_pixel(lat_deg: float, zoom: int) -> float:
	return 156543.03392 * cos(deg_to_rad(lat_deg)) / pow(2.0, zoom)
