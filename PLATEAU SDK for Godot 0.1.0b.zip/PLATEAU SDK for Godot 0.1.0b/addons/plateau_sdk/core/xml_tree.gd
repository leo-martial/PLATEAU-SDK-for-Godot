## xml_tree.gd
## Builds a generic in-memory tree from an XML/GML file, using Godot's
## native XMLParser class. No namespace resolution: tag names are kept as-is
## with their prefix (e.g. "bldg:Building", "gml:posList"), which works fine
## since PLATEAU consistently uses the same standard prefixes across every
## file seen during research for this SDK.
##
## Loads the whole tree into memory (not true streaming/SAX in the sense
## that the rest of the pipeline doesn't bound memory use from it): fine for
## a "per-mesh" CityGML file (a few MB to a few tens of MB, the grain the
## Datasets tab extracts), NOT for a single file covering an entire city.
## Consistent with the rest of this SDK, which is built around importing
## mesh by mesh rather than all at once.
@tool
extends RefCounted
class_name PlateauXmlNode

var tag: String = ""
var attributes: Dictionary = {}
var children: Array[PlateauXmlNode] = []
var text: String = ""

func find_child(tag_name: String) -> PlateauXmlNode:
	for c in children:
		if c.tag == tag_name:
			return c
	return null

## Recursively searches all descendants with this tag (any depth, not just
## direct children). Useful to avoid hard-coding every intermediate nesting
## level (e.g. Solid > exterior > CompositeSurface > surfaceMember > Polygon).
func find_descendants(tag_name: String) -> Array[PlateauXmlNode]:
	var result: Array[PlateauXmlNode] = []
	for c in children:
		if c.tag == tag_name:
			result.append(c)
		result.append_array(c.find_descendants(tag_name))
	return result

func text_content() -> String:
	return text.strip_edges()

static func parse_file(path: String, error_out: Array = []) -> PlateauXmlNode:
	var parser := XMLParser.new()
	var err := parser.open(path)
	if err != OK:
		if error_out.size() > 0:
			error_out[0] = "Could not open %s (error %d)." % [path, err]
		return null

	var root := PlateauXmlNode.new()
	root.tag = "#root"
	var stack: Array = [root]

	while parser.read() == OK:
		match parser.get_node_type():
			XMLParser.NODE_ELEMENT:
				var node := PlateauXmlNode.new()
				node.tag = parser.get_node_name()
				for i in parser.get_attribute_count():
					node.attributes[parser.get_attribute_name(i)] = parser.get_attribute_value(i)
				(stack.back() as PlateauXmlNode).children.append(node)
				if not parser.is_empty():
					stack.append(node)
			XMLParser.NODE_ELEMENT_END:
				if stack.size() > 1:
					stack.pop_back()
			XMLParser.NODE_TEXT:
				(stack.back() as PlateauXmlNode).text += parser.get_node_data()
			_:
				pass

	return root
