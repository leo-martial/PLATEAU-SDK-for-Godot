## zip_central_directory.gd
## Reads the central directory of a ZIP archive (end of file), WITHOUT
## decompressing anything, to get the list of entries and their
## uncompressed size.
##
## Why not use Godot's native ZIPReader class for this: ZIPReader exposes
## open()/get_files()/read_file()/file_exists(), but not (as far as I know,
## unverified in a real Godot editor) a method to know an entry's size
## without fully decompressing it via read_file(). For a multi-GB zip,
## decompressing every entry just to learn its size would be as expensive
## as the full extraction this is meant to avoid. This script instead reads
## the raw ZIP format bytes directly (PKWARE's APPNOTE.TXT spec, stable for
## decades): the central directory holds each entry's size in plain sight,
## no decompression needed. Same principle as `unzip -l` on the command line.
##
## If a future Godot version adds a size accessor to ZIPReader, this file
## becomes unnecessary - check your version's docs before assuming this
## workaround is still needed.
##
## Known limitations:
## - Handles ZIP64 for the global fields (EOCD / central directory), needed
##   for PLATEAU zips of large cities that exceed 4GB total (e.g. Tokyo's
##   23 special wards).
## - Does NOT handle per-entry ZIP64 (a single file over 4GB inside the
##   archive): in practice, an individual .gml file or texture in a PLATEAU
##   dataset never reaches that size, but if it ever did, the size read for
##   that entry would be wrong rather than this script failing explicitly.
##   Flagged here in plain text rather than discovered silently.
## - Assumes a global ZIP comment under 65535 bytes (a format limit anyway,
##   true in practice almost always).
@tool
extends RefCounted
class_name PlateauZipCentralDirectory

const EOCD_SIGNATURE := 0x06054b50
const EOCD64_LOCATOR_SIGNATURE := 0x07064b50
const EOCD64_SIGNATURE := 0x06064b50
const CENTRAL_FILE_HEADER_SIGNATURE := 0x02014b50
const EOCD_FIXED_SIZE := 22
const EOCD_SEARCH_WINDOW := 65557 # 22 + max comment length (65535)

## Returns an Array[Dictionary] { path: String, uncompressed_size: int,
## compressed_size: int }, or null on failure. error_out (a 1-element Array,
## passed by reference) receives a message if a non-null array is supplied.
static func read_entries(absolute_zip_path: String, error_out: Array = []) -> Variant:
	var f := FileAccess.open(absolute_zip_path, FileAccess.READ)
	if f == null:
		if error_out.size() > 0:
			error_out[0] = "Could not open %s (error %d)." % [absolute_zip_path, FileAccess.get_open_error()]
		return null

	var file_len := f.get_length()
	var eocd_offset := _find_eocd(f, file_len)
	if eocd_offset == -1:
		if error_out.size() > 0:
			error_out[0] = "End Of Central Directory (EOCD) signature not found: this may not be a valid zip file, or the download is incomplete."
		f.close()
		return null

	f.seek(eocd_offset)
	f.get_32() # signature, already checked by _find_eocd
	f.get_16() # disk number
	f.get_16() # disk with the central directory
	f.get_16() # entries on this disk
	var total_entries := f.get_16()
	var cd_size := f.get_32()
	var cd_offset := f.get_32()

	if cd_offset == 0xFFFFFFFF or cd_size == 0xFFFFFFFF or total_entries == 0xFFFF:
		var zip64 = _read_zip64_eocd(f, eocd_offset)
		if zip64 == null:
			if error_out.size() > 0:
				error_out[0] = "ZIP64 fields expected (archive likely > 4GB) but the ZIP64 locator is missing or invalid."
			f.close()
			return null
		total_entries = zip64.total_entries
		cd_size = zip64.cd_size
		cd_offset = zip64.cd_offset

	f.seek(cd_offset)
	var entries: Array = []
	for i in total_entries:
		var sig := f.get_32()
		if sig != CENTRAL_FILE_HEADER_SIGNATURE:
			if error_out.size() > 0:
				error_out[0] = "Central directory inconsistent at entry %d/%d (unexpected signature): stopped reading, result may be partial." % [i, total_entries]
			break
		f.get_16() # version made by
		f.get_16() # version needed
		f.get_16() # flags
		f.get_16() # compression method
		f.get_16() # modification time
		f.get_16() # modification date
		f.get_32() # crc32
		var compressed_size := f.get_32()
		var uncompressed_size := f.get_32()
		var filename_len := f.get_16()
		var extra_len := f.get_16()
		var comment_len := f.get_16()
		f.get_16() # starting disk number
		f.get_16() # internal attributes
		f.get_32() # external attributes
		f.get_32() # local header offset

		var filename_bytes := f.get_buffer(filename_len)
		var path := filename_bytes.get_string_from_utf8()

		# The "extra" field may hold real 64-bit sizes if the fields above
		# read 0xFFFFFFFF (a single entry over 4GB): not used here (see
		# limitations above), just skipped to stay aligned with the next entry.
		f.seek(f.get_position() + extra_len + comment_len)

		entries.append({
			"path": path,
			"compressed_size": compressed_size,
			"uncompressed_size": uncompressed_size,
		})

	f.close()
	return entries

static func _find_eocd(f: FileAccess, file_len: int) -> int:
	var window: int = mini(EOCD_SEARCH_WINDOW, file_len)
	f.seek(file_len - window)
	var buf := f.get_buffer(window)
	# The EOCD is always the LAST record of this type in the file: search
	# from the end of the buffer backwards.
	for i in range(buf.size() - EOCD_FIXED_SIZE, -1, -1):
		if buf[i] == 0x50 and buf[i + 1] == 0x4b and buf[i + 2] == 0x05 and buf[i + 3] == 0x06:
			return (file_len - window) + i
	return -1

static func _read_zip64_eocd(f: FileAccess, eocd_offset: int) -> Variant:
	# The ZIP64 locator (fixed 20-byte size) immediately precedes the
	# classic EOCD.
	var locator_offset := eocd_offset - 20
	if locator_offset < 0:
		return null
	f.seek(locator_offset)
	if f.get_32() != EOCD64_LOCATOR_SIGNATURE:
		return null
	f.get_32() # disk with the ZIP64 EOCD
	var zip64_eocd_offset := f.get_64()
	f.get_32() # total number of disks

	f.seek(zip64_eocd_offset)
	if f.get_32() != EOCD64_SIGNATURE:
		return null
	f.get_64() # size of remaining record
	f.get_16() # version made by
	f.get_16() # version needed
	f.get_32() # disk number
	f.get_32() # disk with the central directory
	f.get_64() # entries on this disk
	var total_entries := f.get_64()
	var cd_size := f.get_64()
	var cd_offset := f.get_64()
	return {"total_entries": total_entries, "cd_size": cd_size, "cd_offset": cd_offset}
