## catalog_client.gd
## Queries the official PLATEAU data catalog (PLATEAU distribution service,
## hosted by MLIT) and exposes the list of CityGML datasets per municipality.
##
## Endpoint confirmed by multiple independent sources (see README):
## GET https://api.plateauview.mlit.go.jp/datacatalog/plateau-datasets
##
## MLIT labels this service EXPERIMENTAL: no guaranteed uptime, SLA, or
## response schema stability. This script parses the JSON defensively and
## reports a parsing failure clearly rather than crashing silently, so a
## server-side schema change can be spotted quickly.
##
## Expected response shape (inferred from documentation, NOT verified
## against a live call at the time of writing - confirm on first use): a
## JSON object with at least a "citygml" key holding an array of entries
## { id, pref, pref_code, city, city_code, url, composite_url, file_size,
## feature_types, year, registration_year, spec }, and a "latest_citygml"
## key with the same fields but year = "latest".
## Reference: https://docs.plateauview.mlit.go.jp/datasets/citygml/
@tool
extends Node
class_name PlateauCatalogClient

signal datasets_loaded(citygml_entries: Array, latest_entries: Array)
signal failed(message: String)

const DATASETS_URL := "https://api.plateauview.mlit.go.jp/datacatalog/plateau-datasets"

var _http: HTTPRequest

func _ready() -> void:
	_http = HTTPRequest.new()
	# The full catalog can be a JSON payload of several MB (every
	# municipality in Japan): allow a generous response size.
	_http.body_size_limit = 64 * 1024 * 1024
	add_child(_http)
	_http.request_completed.connect(_on_request_completed)

func fetch_datasets() -> void:
	var err := _http.request(DATASETS_URL)
	if err != OK:
		failed.emit("Could not start the HTTP request (code %d). Check your network connection." % err)

func _on_request_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS:
		failed.emit("HTTP request failed (result=%d). MLIT labels this service experimental, it may be temporarily unavailable." % result)
		return
	if response_code != 200:
		failed.emit("The server replied with code %d instead of 200. Check that %s is still valid (docs.plateauview.mlit.go.jp)." % [response_code, DATASETS_URL])
		return

	var json := JSON.new()
	var parse_err := json.parse(body.get_string_from_utf8())
	if parse_err != OK:
		failed.emit("Response received but not valid JSON (error %d, line %d)." % [parse_err, json.get_error_line()])
		return

	var data = json.get_data()
	if typeof(data) != TYPE_DICTIONARY:
		failed.emit("JSON response received but in an unexpected shape (expected: an object with a 'citygml' key). The API schema may have changed - check https://docs.plateauview.mlit.go.jp/datasets/citygml/ and adjust catalog_client.gd.")
		return

	if not data.has("citygml"):
		var keys := (data as Dictionary).keys()
		failed.emit("The JSON has no 'citygml' key. Keys present: %s. The schema has likely changed since this script was written - adjust _on_request_completed() accordingly." % [keys])
		return

	var citygml_entries: Array = data.get("citygml", [])
	var latest_entries: Array = data.get("latest_citygml", [])
	datasets_loaded.emit(citygml_entries, latest_entries)
