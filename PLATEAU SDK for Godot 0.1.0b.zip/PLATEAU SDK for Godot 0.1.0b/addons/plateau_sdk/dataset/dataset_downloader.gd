## dataset_downloader.gd
## Downloads the CityGML zip for a PLATEAU dataset chosen in the Datasets
## tab, extracts it into the project, and locates the "root" folder to feed
## into the Buildings tab afterwards (the one containing "udx" and
## "codelists" - the same folder convention documented for the Unity SDK:
## https://project-plateau.github.io/PLATEAU-SDK-for-Unity/manual/ImportCityModels.html,
## "select the folder one level above udx").
##
## This script does NOT import CityGML into a scene itself: it stops once
## the .gml files are on disk, ready for the Buildings tab. This is by
## design (this SDK keeps dataset acquisition and CityGML import as
## separate, composable steps).
##
## The zip is downloaded to user:// (outside the project, so Godot doesn't
## needlessly try to import a large temporary file) then deleted after a
## successful extraction. The extracted files themselves go into res://.
@tool
extends Node
class_name PlateauDatasetDownloader

signal download_progress(downloaded_bytes: int, total_bytes: int)
signal extraction_progress(done: int, total: int)
signal finished(dataset_root_res_path: String)
signal failed(message: String)

var _http: HTTPRequest
var _temp_zip_user_path: String
var _target_res_dir: String
var _poll_timer: Timer

func _ready() -> void:
	_http = HTTPRequest.new()
	_http.body_size_limit = -1  # no limit: some PLATEAU zips exceed 1GB
	add_child(_http)
	_http.request_completed.connect(_on_download_completed)

	# HTTPRequest doesn't natively report percentage progress without manual
	# polling; get_downloaded_bytes()/get_body_size() are checked on a timer.
	_poll_timer = Timer.new()
	_poll_timer.wait_time = 0.25
	_poll_timer.timeout.connect(_on_poll_progress)
	add_child(_poll_timer)

## dataset_url: the "url" or "composite_url" field of a catalog entry.
## dataset_id: used to name the temporary file (avoids collisions if
## several downloads are started one after another).
## target_res_dir: res:// folder to extract into, e.g.
## "res://plateau_data/13101_chiyoda-ku"
func start(dataset_url: String, dataset_id: String, target_res_dir: String) -> void:
	if not dataset_url.begins_with("https://"):
		failed.emit("Invalid or empty dataset URL: '%s'." % dataset_url)
		return

	_target_res_dir = target_res_dir
	var safe_id := dataset_id.validate_filename() if dataset_id != "" else "download"
	_temp_zip_user_path = "user://plateau_cache/%s.zip" % safe_id

	DirAccess.make_dir_recursive_absolute("user://plateau_cache")

	_http.download_file = _temp_zip_user_path
	var err := _http.request(dataset_url)
	if err != OK:
		failed.emit("Could not start the download (code %d)." % err)
		return
	_poll_timer.start()

func _on_poll_progress() -> void:
	if _http.get_http_client_status() == HTTPClient.STATUS_BODY:
		download_progress.emit(_http.get_downloaded_bytes(), _http.get_body_size())

func _on_download_completed(result: int, response_code: int, _headers: PackedStringArray, _body: PackedByteArray) -> void:
	_poll_timer.stop()
	if result != HTTPRequest.RESULT_SUCCESS:
		failed.emit("Download failed (result=%d)." % result)
		return
	if response_code != 200:
		failed.emit("The server replied %d instead of 200 while downloading." % response_code)
		return

	_extract()

func _extract() -> void:
	var abs_zip_path := ProjectSettings.globalize_path(_temp_zip_user_path)

	var reader := ZIPReader.new()
	var open_err := reader.open(abs_zip_path)
	if open_err != OK:
		failed.emit("Could not open the downloaded zip (error %d). The file may be incomplete or not a valid zip: check %s manually." % [open_err, abs_zip_path])
		return

	if not DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(_target_res_dir)):
		DirAccess.make_dir_recursive_absolute(_target_res_dir)

	var entries := reader.get_files()
	var udx_parent := ""  # filled in once a "udx" folder is spotted during extraction

	for i in entries.size():
		var entry_path: String = entries[i]
		extraction_progress.emit(i, entries.size())

		# Zip entries ending in "/" are directories, nothing to write.
		if entry_path.ends_with("/"):
			continue

		var dest_path := _target_res_dir.path_join(entry_path)
		var dest_dir := dest_path.get_base_dir()
		DirAccess.make_dir_recursive_absolute(dest_dir)

		var content := reader.read_file(entry_path)
		var f := FileAccess.open(dest_path, FileAccess.WRITE)
		if f == null:
			reader.close()
			failed.emit("Could not write %s (error %d)." % [dest_path, FileAccess.get_open_error()])
			return
		f.store_buffer(content)
		f.close()

		# Locate the folder that directly contains "udx": that's the one to
		# feed into the Buildings tab, one level up. Takes the first match
		# (PLATEAU datasets normally have only one udx folder per zip).
		# entry_path is always relative to the zip root, so it either starts
		# with "udx/" directly (zip root = dataset root), or "udx/" appears
		# further in, preceded by a "/" (one or more wrapping folders before udx).
		if udx_parent == "":
			if entry_path.begins_with("udx/"):
				udx_parent = _target_res_dir
			else:
				var idx: int = entry_path.find("/udx/")
				if idx != -1:
					udx_parent = _target_res_dir.path_join(entry_path.substr(0, idx))

	reader.close()
	extraction_progress.emit(entries.size(), entries.size())

	# Clean up the temporary zip, no longer needed once extracted.
	DirAccess.remove_absolute(abs_zip_path)

	EditorInterface.get_resource_filesystem().scan()

	if udx_parent == "":
		# Not a big deal in itself: the zip did extract, but no "udx" folder
		# was found at the expected root. Some PLATEAU packages have a
		# slightly different structure (a prefecture folder wrapping several
		# municipalities, for example): the target folder is returned as-is
		# and the person can browse into it.
		finished.emit(_target_res_dir)
	else:
		finished.emit(udx_parent)
