## dataset_panel.gd
## "3D (PLATEAU)" tab: three sections, covering the whole path from
## "find a dataset" to "buildings in the scene".
##
## A. PLATEAU catalog (api.plateauview.mlit.go.jp): finds the right dataset
##    by prefecture/municipality and opens its URL, but does NOT download it
##    automatically in the editor (too heavy for large cities - downloading
##    in a browser gets pause/resume support that Godot doesn't offer
##    natively). A direct-download option remains available, collapsed, for
##    anyone who wants it anyway.
##
## B. Fine-grained selection on an already-downloaded zip (in the spirit of
##    PLATEAU GIS Converter,
##    https://github.com/Project-PLATEAU/PLATEAU-GIS-Converter): point at
##    the local zip, pick the categories (bldg, brid, ...) and mesh codes
##    you care about, see the total size BEFORE extracting, then extract
##    only that subset into the project.
##
## C. Import: turns the extracted CityGML into MeshInstance3D nodes in the
##    open scene. A successful extraction in section B auto-fills this
##    section's input path, so B -> C flows without retyping anything.
##    Was a separate "Buildings" tab originally; folded in here since
##    acquiring and importing CityGML data is really one continuous task,
##    not two.
@tool
extends Control
class_name PlateauDatasetPanel

const ZipCentralDirectory = preload("res://addons/plateau_sdk/core/zip_central_directory.gd")
const MeshCodeMath = preload("res://addons/plateau_sdk/core/mesh_code_math.gd")
const OriginFinder = preload("res://addons/plateau_sdk/core/origin_finder.gd")
const FileIndex = preload("res://addons/plateau_sdk/dataset/file_index.gd")
const SelectiveExtractor = preload("res://addons/plateau_sdk/dataset/selective_extractor.gd")
const CityGmlImporter = preload("res://addons/plateau_sdk/converter/citygml_importer.gd")
const CityGmlParser = preload("res://addons/plateau_sdk/converter/citygml_parser.gd")

signal extraction_finished(folder_path: String)
## Emitted whenever the mesh grid is (re)built from an analyzed zip, so the
## "2D (PLATEAU Ortho)" tab can overlay the same meshes on its own map and
## let the person select an Ortho download area by mesh instead of only by
## dragging a rectangle. mesh_bounds: Dictionary { mesh_code:String ->
## {min_lat,min_lon,max_lat,max_lon} }, same shape as
## PlateauMeshGridMap.mesh_bounds.
signal meshes_analyzed(mesh_bounds: Dictionary)

var _project_origin: PlateauProjectOrigin

var reset_button: Button
var reset_confirm_dialog: ConfirmationDialog

## Called by main_panel.gd right after instantiation, before _ready() UI is
## used, to share the single project-wide origin/zone setting.
func setup(project_origin: PlateauProjectOrigin) -> void:
	_project_origin = project_origin
	_project_origin.changed.connect(_on_project_origin_changed)
	_update_origin_display() # in case _ready() already ran (add_child() calls it synchronously) before setup() was called

var catalog_client: PlateauCatalogClient
var downloader: PlateauDatasetDownloader

# --- Catalog --------------------------------------------------------
var _citygml_entries: Array = []
var _latest_entries: Array = []
var _by_pref: Dictionary = {}
var _current_city_entry: Dictionary = {}

var status_label: Label
var load_button: Button
var pref_option: OptionButton
var city_option: OptionButton
var all_years_check: CheckBox
var info_label: RichTextLabel
var open_browser_button: Button
var copy_url_button: Button
var advanced_download_check: CheckBox
var advanced_download_box: VBoxContainer
var output_dir_edit: LineEdit
var download_button: Button
var progress_bar: ProgressBar
var progress_label: Label

# --- Local zip ----------------------------------------------------------
var zip_path_edit: LineEdit
var zip_file_dialog: EditorFileDialog
var analyze_button: Button
var zip_status_label: Label
var _zip_index: Dictionary = {}
var _current_zip_abs_path: String = ""

var category_list_box: VBoxContainer
var _category_checks: Dictionary = {} # code -> CheckBox

var mesh_grid: PlateauMeshGridMap
var select_all_meshes_button: Button
var deselect_all_meshes_button: Button
var unresolved_mesh_check: CheckBox # meshes "?" that can't be placed on the map (see core/mesh_code_math.gd)
var _unresolved_mesh_count := 0

var selection_estimate_label: Label
var zip_output_dir_edit: LineEdit
var clear_before_extract_check: CheckBox
var extract_button: Button
var extract_result_label: RichTextLabel

# --- Section C: import ---------------------------------------------------
var import_path_edit: LineEdit
var import_file_dialog: EditorFileDialog
var lod_option: OptionButton
var load_textures_check: CheckBox
var generate_collision_check: CheckBox
var origin_display_label: Label
var import_button: Button
var import_status_label: Label
var import_result_label: RichTextLabel

func _ready() -> void:
	if not Engine.is_editor_hint():
		return
	_build_ui()

	catalog_client = PlateauCatalogClient.new()
	add_child(catalog_client)
	catalog_client.datasets_loaded.connect(_on_datasets_loaded)
	catalog_client.failed.connect(_on_catalog_failed)

	downloader = PlateauDatasetDownloader.new()
	add_child(downloader)
	downloader.download_progress.connect(_on_download_progress)
	downloader.extraction_progress.connect(_on_extraction_progress)
	downloader.finished.connect(_on_download_finished)
	downloader.failed.connect(_on_download_failed)

## =========================================================================
## Reset
## =========================================================================

func _build_reset_control(root: VBoxContainer) -> void:
	reset_button = Button.new()
	reset_button.text = "Reset this tab (start a new dataset)"
	reset_button.pressed.connect(_on_reset_pressed)
	root.add_child(reset_button)

	var reset_hint := Label.new()
	reset_hint.text = "Clears the loaded catalog, the analyzed zip and its category/mesh selection, and the import path below - useful since none of that clears itself automatically when you want to work with a different dataset. Does NOT remove anything already imported into the scene."
	reset_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	reset_hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(reset_hint)

	reset_confirm_dialog = ConfirmationDialog.new()
	reset_confirm_dialog.dialog_text = "Reset this tab? This clears the loaded catalog, the analyzed zip and its selection, and the import path field, so you can start a different dataset from scratch. It does NOT remove anything already imported into the scene."
	reset_confirm_dialog.confirmed.connect(_on_reset_confirmed)
	add_child(reset_confirm_dialog)

func _on_reset_pressed() -> void:
	reset_confirm_dialog.popup_centered()

func _on_reset_confirmed() -> void:
	# Section A: catalog.
	_citygml_entries = []
	_latest_entries = []
	_by_pref.clear()
	_current_city_entry = {}
	pref_option.clear()
	pref_option.disabled = true
	city_option.clear()
	city_option.disabled = true
	_set_link_buttons_enabled(false)
	info_label.text = "[i]Pick a municipality to see its dataset details.[/i]"
	status_label.text = "Catalog not loaded."
	output_dir_edit.text = "res://plateau_data/"
	advanced_download_check.button_pressed = false
	advanced_download_box.visible = false

	# Section B: local zip.
	zip_path_edit.text = ""
	_zip_index = {}
	_current_zip_abs_path = ""
	_rebuild_category_list()
	mesh_grid.set_mesh_codes([])
	_unresolved_mesh_count = 0
	unresolved_mesh_check.visible = false
	unresolved_mesh_check.button_pressed = false
	var warning_label: Label = unresolved_mesh_check.get_meta("warning_label")
	warning_label.visible = false
	selection_estimate_label.text = "Analyze a zip to see a selection size estimate."
	zip_output_dir_edit.text = "res://plateau_data/"
	clear_before_extract_check.button_pressed = true
	extract_button.disabled = true
	extract_result_label.text = ""
	zip_status_label.text = "No zip analyzed yet."

	# Section C: import.
	import_path_edit.text = ""
	import_status_label.text = ""
	import_result_label.text = ""

## =========================================================================
## UI
## =========================================================================

func _build_ui() -> void:
	var scroll := ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(scroll)

	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_theme_constant_override("separation", 6)
	scroll.add_child(root)

	_build_reset_control(root)
	root.add_child(HSeparator.new())

	_build_catalog_section(root)
	root.add_child(HSeparator.new())
	root.add_child(HSeparator.new())
	_build_zip_section(root)
	root.add_child(HSeparator.new())
	root.add_child(HSeparator.new())
	_build_import_section(root)

## --- Section A: catalog ----------------------------------------------

func _build_catalog_section(root: VBoxContainer) -> void:
	var title := Label.new()
	title.text = "A. Find a dataset (PLATEAU catalog)"
	title.add_theme_font_size_override("font_size", 15)
	root.add_child(title)

	var hint := Label.new()
	hint.text = "Browses the official catalog (api.plateauview.mlit.go.jp, an MLIT experimental service) to find a municipality's zip URL. Does NOT download automatically: opens the URL in your browser for pause/resume support, then move on to section B below with the downloaded file."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(hint)

	load_button = Button.new()
	load_button.text = "Load catalog"
	load_button.pressed.connect(_on_load_pressed)
	root.add_child(load_button)

	status_label = Label.new()
	status_label.text = "Catalog not loaded."
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	root.add_child(status_label)

	all_years_check = CheckBox.new()
	all_years_check.text = "Show every year (default: latest version only)"
	all_years_check.toggled.connect(_on_all_years_toggled)
	root.add_child(all_years_check)

	var pref_row := HBoxContainer.new()
	root.add_child(pref_row)
	var pref_label := Label.new()
	pref_label.text = "Prefecture:"
	pref_label.custom_minimum_size.x = 90
	pref_row.add_child(pref_label)
	pref_option = OptionButton.new()
	pref_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pref_option.disabled = true
	pref_option.item_selected.connect(_on_pref_selected)
	pref_row.add_child(pref_option)

	var city_row := HBoxContainer.new()
	root.add_child(city_row)
	var city_label := Label.new()
	city_label.text = "Municipality:"
	city_label.custom_minimum_size.x = 90
	city_row.add_child(city_label)
	city_option = OptionButton.new()
	city_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	city_option.disabled = true
	city_option.item_selected.connect(_on_city_selected)
	city_row.add_child(city_option)

	info_label = RichTextLabel.new()
	info_label.bbcode_enabled = true
	info_label.fit_content = true
	info_label.custom_minimum_size.y = 110
	info_label.text = "[i]Pick a municipality to see its dataset details.[/i]"
	root.add_child(info_label)

	var link_row := HBoxContainer.new()
	root.add_child(link_row)
	open_browser_button = Button.new()
	open_browser_button.text = "Open URL in browser"
	open_browser_button.disabled = true
	open_browser_button.pressed.connect(_on_open_browser_pressed)
	link_row.add_child(open_browser_button)
	copy_url_button = Button.new()
	copy_url_button.text = "Copy URL"
	copy_url_button.disabled = true
	copy_url_button.pressed.connect(_on_copy_url_pressed)
	link_row.add_child(copy_url_button)

	advanced_download_check = CheckBox.new()
	advanced_download_check.text = "Advanced: download directly in the editor (heavy, no pause/resume, not recommended for large cities)"
	advanced_download_check.toggled.connect(_on_advanced_toggled)
	root.add_child(advanced_download_check)

	advanced_download_box = VBoxContainer.new()
	advanced_download_box.visible = false
	root.add_child(advanced_download_box)

	var out_row := HBoxContainer.new()
	advanced_download_box.add_child(out_row)
	var out_label := Label.new()
	out_label.text = "Target folder:"
	out_row.add_child(out_label)
	output_dir_edit = LineEdit.new()
	output_dir_edit.text = "res://plateau_data/"
	output_dir_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	out_row.add_child(output_dir_edit)

	download_button = Button.new()
	download_button.text = "Download and extract (whole zip)"
	download_button.disabled = true
	download_button.pressed.connect(_on_download_pressed)
	advanced_download_box.add_child(download_button)

	progress_bar = ProgressBar.new()
	progress_bar.min_value = 0
	progress_bar.max_value = 100
	progress_bar.visible = false
	advanced_download_box.add_child(progress_bar)

	progress_label = Label.new()
	progress_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	advanced_download_box.add_child(progress_label)

	var attribution_label := Label.new()
	attribution_label.text = "3D City Model data (Project PLATEAU), MLIT. CC BY 4.0, commercial use allowed, attribution required. https://www.mlit.go.jp/plateau/site-policy/"
	attribution_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	attribution_label.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	root.add_child(attribution_label)

## --- Section B: local zip -----------------------------------------------

func _build_zip_section(root: VBoxContainer) -> void:
	var title := Label.new()
	title.text = "B. Fine-grained selection on an already-downloaded zip"
	title.add_theme_font_size_override("font_size", 15)
	root.add_child(title)

	var hint := Label.new()
	hint.text = "Point at the CityGML zip downloaded from G-Spatial Information Center (or via section A above). Pick the categories and meshes you care about, check the total size, then extract only that subset into the project (not the whole zip)."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(hint)

	var zip_row := HBoxContainer.new()
	root.add_child(zip_row)
	zip_path_edit = LineEdit.new()
	zip_path_edit.placeholder_text = "Path to the .zip file (e.g. C:/Users/you/Desktop/14100_yokohama-shi_city_2024_citygml_2_op.zip)"
	zip_path_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	zip_row.add_child(zip_path_edit)
	var browse_button := Button.new()
	browse_button.text = "Browse..."
	browse_button.pressed.connect(_on_browse_pressed)
	zip_row.add_child(browse_button)

	zip_file_dialog = EditorFileDialog.new()
	zip_file_dialog.access = EditorFileDialog.ACCESS_FILESYSTEM
	zip_file_dialog.file_mode = EditorFileDialog.FILE_MODE_OPEN_FILE
	zip_file_dialog.add_filter("*.zip", "PLATEAU ZIP archive")
	zip_file_dialog.file_selected.connect(_on_zip_file_selected)
	add_child(zip_file_dialog)

	analyze_button = Button.new()
	analyze_button.text = "Analyze zip"
	analyze_button.pressed.connect(_on_analyze_pressed)
	root.add_child(analyze_button)

	zip_status_label = Label.new()
	zip_status_label.text = "No zip analyzed yet."
	zip_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	root.add_child(zip_status_label)

	root.add_child(HSeparator.new())

	var cat_title := Label.new()
	cat_title.text = "Categories (feature types)"
	root.add_child(cat_title)
	category_list_box = VBoxContainer.new()
	root.add_child(category_list_box)

	root.add_child(HSeparator.new())

	var mesh_title := Label.new()
	mesh_title.text = "Meshes (mesh codes) - blue = unselected, orange = selected"
	root.add_child(mesh_title)

	var mesh_hint := Label.new()
	mesh_hint.text = "Click: toggle a mesh. Shift + drag: select every mesh inside the rectangle. Drag alone: pan the map. Wheel: zoom (or use the +/- buttons below if scrolling over the map fights with scrolling this panel)."
	mesh_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	mesh_hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(mesh_hint)

	var mesh_buttons_row := HBoxContainer.new()
	root.add_child(mesh_buttons_row)
	select_all_meshes_button = Button.new()
	select_all_meshes_button.text = "Select all"
	select_all_meshes_button.pressed.connect(func(): mesh_grid.select_all())
	mesh_buttons_row.add_child(select_all_meshes_button)
	deselect_all_meshes_button = Button.new()
	deselect_all_meshes_button.text = "Deselect all"
	deselect_all_meshes_button.pressed.connect(func(): mesh_grid.deselect_all())
	mesh_buttons_row.add_child(deselect_all_meshes_button)

	mesh_grid = PlateauMeshGridMap.new()
	mesh_grid.custom_minimum_size = Vector2(0, 360)
	mesh_grid.selection_changed.connect(_update_selection_estimate)
	root.add_child(mesh_grid)

	var map_zoom_row := HBoxContainer.new()
	root.add_child(map_zoom_row)
	var map_zoom_out_button := Button.new()
	map_zoom_out_button.text = "- Zoom out"
	map_zoom_out_button.pressed.connect(func(): mesh_grid.zoom_out())
	map_zoom_row.add_child(map_zoom_out_button)
	var map_zoom_in_button := Button.new()
	map_zoom_in_button.text = "+ Zoom in"
	map_zoom_in_button.pressed.connect(func(): mesh_grid.zoom_in())
	map_zoom_row.add_child(map_zoom_in_button)

	var gsi_attribution := Label.new()
	gsi_attribution.text = "Basemap: GSI tiles (Geospatial Information Authority of Japan) - https://maps.gsi.go.jp/development/ichiran.html"
	gsi_attribution.autowrap_mode = TextServer.AUTOWRAP_WORD
	gsi_attribution.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	root.add_child(gsi_attribution)

	unresolved_mesh_check = CheckBox.new()
	unresolved_mesh_check.text = "Include files with no identifiable mesh code (0 so far)"
	unresolved_mesh_check.button_pressed = false
	unresolved_mesh_check.visible = false
	unresolved_mesh_check.toggled.connect(func(_p): _update_selection_estimate())
	root.add_child(unresolved_mesh_check)

	var unresolved_warning := Label.new()
	unresolved_warning.text = "Off by default: these files aren't split per mesh (e.g. flood-risk data covering a whole river basin), so they're often large - including them can significantly increase the extraction size and time."
	unresolved_warning.autowrap_mode = TextServer.AUTOWRAP_WORD
	unresolved_warning.add_theme_color_override("font_color", Color(0.85, 0.6, 0.3))
	unresolved_warning.visible = false
	unresolved_mesh_check.set_meta("warning_label", unresolved_warning)
	root.add_child(unresolved_warning)

	root.add_child(HSeparator.new())

	selection_estimate_label = Label.new()
	selection_estimate_label.text = "Analyze a zip to see a selection size estimate."
	selection_estimate_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	root.add_child(selection_estimate_label)

	var zip_out_row := HBoxContainer.new()
	root.add_child(zip_out_row)
	var zip_out_label := Label.new()
	zip_out_label.text = "Target folder:"
	zip_out_row.add_child(zip_out_label)
	zip_output_dir_edit = LineEdit.new()
	zip_output_dir_edit.text = "res://plateau_data/"
	zip_output_dir_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	zip_out_row.add_child(zip_output_dir_edit)

	clear_before_extract_check = CheckBox.new()
	clear_before_extract_check.text = "Clear target folder before extracting"
	clear_before_extract_check.button_pressed = true
	root.add_child(clear_before_extract_check)

	var clear_warning := Label.new()
	clear_warning.text = "On by default: the target folder above only depends on the zip's filename, not on which categories/meshes are checked, so extracting a DIFFERENT selection into the same folder without re-analyzing would otherwise leave the previous selection's files sitting there too - and importing from that folder in section C would then pick up both. This deletes the target folder's current CONTENTS (not the original zip) right before writing the new selection. Turn off only if you deliberately want to combine several extractions (e.g. bldg, then brid) into the same folder."
	clear_warning.autowrap_mode = TextServer.AUTOWRAP_WORD
	clear_warning.add_theme_color_override("font_color", Color(0.85, 0.6, 0.3))
	root.add_child(clear_warning)

	extract_button = Button.new()
	extract_button.text = "Extract selection"
	extract_button.disabled = true
	extract_button.pressed.connect(_on_extract_pressed)
	root.add_child(extract_button)

	extract_result_label = RichTextLabel.new()
	extract_result_label.bbcode_enabled = true
	extract_result_label.fit_content = true
	extract_result_label.custom_minimum_size.y = 60
	root.add_child(extract_result_label)

## --- Section C: import ----------------------------------------------------

func _build_import_section(root: VBoxContainer) -> void:
	var title := Label.new()
	title.text = "C. Import into the scene"
	title.add_theme_font_size_override("font_size", 15)
	root.add_child(title)

	var hint := Label.new()
	hint.text = "Turns extracted CityGML into 3D buildings in the open scene, in pure GDScript. Auto-filled after a successful extraction above, or point it at any other folder/.gml file (e.g. from a previous session)."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(hint)

	var path_row := HBoxContainer.new()
	root.add_child(path_row)
	import_path_edit = LineEdit.new()
	import_path_edit.placeholder_text = ".gml file or folder (auto-filled after extraction above)"
	import_path_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	path_row.add_child(import_path_edit)
	var browse_button := Button.new()
	browse_button.text = "Browse..."
	browse_button.pressed.connect(_on_import_browse_pressed)
	path_row.add_child(browse_button)

	import_file_dialog = EditorFileDialog.new()
	import_file_dialog.access = EditorFileDialog.ACCESS_RESOURCES
	import_file_dialog.file_mode = EditorFileDialog.FILE_MODE_OPEN_ANY
	import_file_dialog.add_filter("*.gml", "CityGML")
	import_file_dialog.file_selected.connect(_on_import_path_selected)
	import_file_dialog.dir_selected.connect(_on_import_path_selected)
	add_child(import_file_dialog)

	var lod_row := HBoxContainer.new()
	root.add_child(lod_row)
	var lod_label := Label.new()
	lod_label.text = "LOD:"
	lod_label.custom_minimum_size.x = 90
	lod_row.add_child(lod_label)
	lod_option = OptionButton.new()
	lod_option.add_item("LOD0 (ground footprint)", 0)
	lod_option.add_item("LOD1 (simple block)", 1)
	lod_option.add_item("LOD2 (detailed roof)", 2)
	lod_option.add_item("LOD3 (detailed facades)", 3)
	lod_option.add_item("LOD4 (interior, almost never present in PLATEAU)", 4)
	lod_option.add_item("Maximum available LOD (auto, per building)", CityGmlParser.AUTO_LOD)
	lod_option.selected = 5 # "Maximum available LOD" by default
	lod_row.add_child(lod_option)

	var lod_hint := Label.new()
	lod_hint.text = "\"Maximum available LOD\" is detected building by building (not once for the whole file): a notable building modeled at LOD3 in a dataset that's otherwise LOD2 will be imported at LOD3. The LOD actually used for each building is stored in its \"lod_used\" metadata and in its node name."
	lod_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	lod_hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(lod_hint)

	load_textures_check = CheckBox.new()
	load_textures_check.text = "Load textures (app:appearance)"
	load_textures_check.button_pressed = true
	root.add_child(load_textures_check)

	var texture_hint := Label.new()
	texture_hint.text = "Looks for the images referenced by each building (path relative to the .gml, e.g. \"appearance/xxx.jpg\") and applies them by UV. If an image is missing or unreadable, that polygon falls back to a flat color (wall/roof/ground) instead of failing the import. Uncheck to skip textures entirely (faster, flat color everywhere)."
	texture_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	texture_hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(texture_hint)

	var texture_warning := Label.new()
	texture_warning.text = "Warning: decoding hundreds of texture images (often large shared atlases) noticeably slows the import and uses more memory. Uncheck above if you just need geometry, or for a first quick look at a large area."
	texture_warning.autowrap_mode = TextServer.AUTOWRAP_WORD
	texture_warning.add_theme_color_override("font_color", Color(0.85, 0.6, 0.3))
	root.add_child(texture_warning)

	root.add_child(HSeparator.new())

	generate_collision_check = CheckBox.new()
	generate_collision_check.text = "Generate collision (StaticBody3D + trimesh, per building)"
	generate_collision_check.button_pressed = false
	root.add_child(generate_collision_check)

	var collision_hint := Label.new()
	collision_hint.text = "Adds an exact trimesh collision shape to every imported building (MeshInstance3D.create_trimesh_collision()). Exact, but slower to generate and heavier to simulate than a simplified shape - off by default, turn on only if you actually need physics/raycast collision against these buildings."
	collision_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	collision_hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(collision_hint)

	root.add_child(HSeparator.new())

	origin_display_label = Label.new()
	origin_display_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	root.add_child(origin_display_label)

	var origin_hint := Label.new()
	origin_hint.text = "Buildings are placed using the shared project origin (see Project Setup at the top of this dock). Set it there once - reuse the same value for the Ortho tab so everything lines up instead of each import re-centering independently."
	origin_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	origin_hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(origin_hint)

	root.add_child(HSeparator.new())

	import_button = Button.new()
	import_button.text = "Import into scene"
	import_button.pressed.connect(_on_import_pressed)
	root.add_child(import_button)

	import_status_label = Label.new()
	import_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	root.add_child(import_status_label)

	import_result_label = RichTextLabel.new()
	import_result_label.bbcode_enabled = true
	import_result_label.fit_content = true
	import_result_label.custom_minimum_size.y = 90
	root.add_child(import_result_label)

	_update_origin_display()

## =========================================================================
## A. Catalog
## =========================================================================

func _on_load_pressed() -> void:
	load_button.disabled = true
	status_label.text = "Loading catalog..."
	catalog_client.fetch_datasets()

func _on_catalog_failed(message: String) -> void:
	load_button.disabled = false
	status_label.text = "Failed: " + message

func _on_datasets_loaded(citygml_entries: Array, latest_entries: Array) -> void:
	load_button.disabled = false
	_citygml_entries = citygml_entries
	_latest_entries = latest_entries
	status_label.text = "Catalog loaded: %d entries (latest version), %d entries (all years)." % [latest_entries.size(), citygml_entries.size()]
	_rebuild_pref_list()

func _on_all_years_toggled(_pressed: bool) -> void:
	_rebuild_pref_list()

func _current_source_entries() -> Array:
	return _citygml_entries if all_years_check.button_pressed else _latest_entries

func _rebuild_pref_list() -> void:
	_by_pref.clear()
	for entry in _current_source_entries():
		if typeof(entry) != TYPE_DICTIONARY:
			continue
		var pref_name: String = str(entry.get("pref", entry.get("pref_code", "?")))
		if not _by_pref.has(pref_name):
			_by_pref[pref_name] = []
		_by_pref[pref_name].append(entry)

	pref_option.clear()
	var pref_names := _by_pref.keys()
	pref_names.sort()
	for p in pref_names:
		pref_option.add_item(p)
	pref_option.disabled = pref_names.is_empty()
	city_option.clear()
	city_option.disabled = true
	_set_link_buttons_enabled(false)
	info_label.text = "[i]Pick a municipality to see its dataset details.[/i]"

	if pref_names.is_empty():
		status_label.text += " No usable entries: the response schema may have changed (see README.md, Troubleshooting)."
	else:
		_on_pref_selected(0)

func _on_pref_selected(index: int) -> void:
	if index < 0 or index >= pref_option.item_count:
		return
	var pref_name := pref_option.get_item_text(index)
	var entries: Array = _by_pref.get(pref_name, [])

	city_option.clear()
	for entry in entries:
		var city_name: String = str(entry.get("city", entry.get("city_code", "?")))
		var year_suffix := "" if not all_years_check.button_pressed else " (%s)" % str(entry.get("year", "?"))
		city_option.add_item(city_name + year_suffix)
	city_option.disabled = entries.is_empty()

	if not entries.is_empty():
		_on_city_selected(0)

func _on_city_selected(index: int) -> void:
	var pref_name := pref_option.get_item_text(pref_option.selected)
	var entries: Array = _by_pref.get(pref_name, [])
	if index < 0 or index >= entries.size():
		return
	_current_city_entry = entries[index]
	_update_info_panel()
	_set_link_buttons_enabled(true)
	download_button.disabled = false

	var city_code := str(_current_city_entry.get("city_code", "unknown"))
	var city_name := str(_current_city_entry.get("city", "unknown")).validate_filename()
	output_dir_edit.text = "res://plateau_data/%s_%s/" % [city_code, city_name]

func _set_link_buttons_enabled(enabled: bool) -> void:
	open_browser_button.disabled = not enabled
	copy_url_button.disabled = not enabled

func _current_entry_url() -> String:
	return str(_current_city_entry.get("composite_url", _current_city_entry.get("url", "")))

func _on_open_browser_pressed() -> void:
	var url := _current_entry_url()
	if url != "":
		OS.shell_open(url)

func _on_copy_url_pressed() -> void:
	DisplayServer.clipboard_set(_current_entry_url())
	status_label.text = "URL copied to clipboard."

func _update_info_panel() -> void:
	var e := _current_city_entry
	var feature_types: Array = e.get("feature_types", [])
	var size_bytes = e.get("file_size", null)
	var size_str := _human_size(size_bytes) if size_bytes != null else "unknown"
	info_label.text = "[b]%s[/b] (%s)\nYear: %s   Registered: %s\nSpec: %s\nFeature types: %s\nZip size: %s\nURL: %s" % [
		str(e.get("city", "?")),
		str(e.get("pref", "?")),
		str(e.get("year", "?")),
		str(e.get("registration_year", "?")),
		str(e.get("spec", "?")),
		", ".join(feature_types.map(func(f): return str(f))) if feature_types is Array else str(feature_types),
		size_str,
		_current_entry_url(),
	]

func _human_size(bytes) -> String:
	var b := float(bytes)
	for unit in ["B", "KB", "MB", "GB"]:
		if b < 1024.0 or unit == "GB":
			return "%.1f %s" % [b, unit]
		b /= 1024.0
	return "%.1f GB" % b

## --- Advanced: full direct download ----------------------

func _on_advanced_toggled(pressed: bool) -> void:
	advanced_download_box.visible = pressed

func _on_download_pressed() -> void:
	var url := _current_entry_url()
	var id: String = str(_current_city_entry.get("id", _current_city_entry.get("city_code", "download")))
	var target_dir := output_dir_edit.text.strip_edges()
	if target_dir == "" or not target_dir.begins_with("res://"):
		status_label.text = "The target folder must start with res://."
		return

	download_button.disabled = true
	progress_bar.visible = true
	progress_bar.value = 0
	progress_label.text = "Downloading..."
	downloader.start(url, id, target_dir)

func _on_download_progress(downloaded_bytes: int, total_bytes: int) -> void:
	if total_bytes > 0:
		progress_bar.value = 100.0 * float(downloaded_bytes) / float(total_bytes)
		progress_label.text = "Downloading: %s / %s" % [_human_size(downloaded_bytes), _human_size(total_bytes)]
	else:
		progress_label.text = "Downloading: %s (total size unknown)" % _human_size(downloaded_bytes)

func _on_extraction_progress(done: int, total: int) -> void:
	if total > 0:
		progress_bar.value = 100.0 * float(done) / float(total)
	progress_label.text = "Extracting: %d / %d files" % [done, total]

func _on_download_finished(dataset_root_res_path: String) -> void:
	download_button.disabled = false
	progress_bar.visible = false
	progress_label.text = ""
	status_label.text = "Done. Section C below has been pre-filled with this folder: %s" % dataset_root_res_path
	import_path_edit.text = dataset_root_res_path
	_maybe_auto_detect_origin(dataset_root_res_path)
	extraction_finished.emit(dataset_root_res_path)

func _on_download_failed(message: String) -> void:
	download_button.disabled = false
	progress_bar.visible = false
	status_label.text = "Download/extraction failed: " + message

## =========================================================================
## B. Local zip
## =========================================================================

func _on_browse_pressed() -> void:
	zip_file_dialog.popup_centered_ratio(0.7)

func _on_zip_file_selected(path: String) -> void:
	zip_path_edit.text = path

func _on_analyze_pressed() -> void:
	var path := zip_path_edit.text.strip_edges()
	if path == "":
		zip_status_label.text = "Enter a .zip file path first."
		return
	if not FileAccess.file_exists(path):
		zip_status_label.text = "File not found: %s" % path
		return

	zip_status_label.text = "Reading the zip's central directory..."
	var error_out: Array = [""]
	var entries = ZipCentralDirectory.read_entries(path, error_out)
	if entries == null:
		zip_status_label.text = "Failed: " + str(error_out[0])
		return

	_current_zip_abs_path = path
	_zip_index = FileIndex.build_index(entries)
	var by_category: Dictionary = _zip_index.get("by_category", {})

	if by_category.is_empty():
		zip_status_label.text = "Zip read (%d entries total) but nothing under udx/: unexpected structure, check that this is a standard PLATEAU CityGML zip." % entries.size()
		return

	var total_size := 0
	var total_files := 0
	for cat in by_category.values():
		total_size += cat["total_size"]
		total_files += cat["file_count"]

	zip_status_label.text = "%d files under udx/ (%s) across %d categories. Choose your selection below." % [total_files, _human_size(total_size), by_category.size()]

	_rebuild_category_list()
	_rebuild_mesh_grid()
	_update_selection_estimate()
	extract_button.disabled = false

	var default_city := path.get_file().get_basename()
	zip_output_dir_edit.text = "res://plateau_data/%s/" % default_city.validate_filename()

func _rebuild_category_list() -> void:
	for c in category_list_box.get_children():
		c.queue_free()
	_category_checks.clear()

	var by_category: Dictionary = _zip_index.get("by_category", {})
	var codes := by_category.keys()
	codes.sort()
	for code in codes:
		var cat: Dictionary = by_category[code]
		var row := CheckBox.new()
		row.button_pressed = (code == "bldg") # only buildings checked by default; other categories (roads, terrain, hazard data, ...) opt-in
		row.text = "%s (%s) - %d file(s) - %s" % [
			FileIndex.label_for(code), code, cat["file_count"], _human_size(cat["total_size"])
		]
		row.toggled.connect(func(_p): _update_selection_estimate())
		category_list_box.add_child(row)
		_category_checks[code] = row

func _rebuild_mesh_grid() -> void:
	var all_codes := FileIndex.all_mesh_codes(_zip_index)
	var locatable: Array = []
	_unresolved_mesh_count = 0
	for code in all_codes:
		if MeshCodeMath.bounds_8digit(str(code)) != null:
			locatable.append(code)
		else:
			_unresolved_mesh_count += 1

	mesh_grid.set_mesh_codes(locatable)
	meshes_analyzed.emit(mesh_grid.mesh_bounds.duplicate())

	var has_unresolved := _unresolved_mesh_count > 0
	unresolved_mesh_check.visible = has_unresolved
	unresolved_mesh_check.text = "Include files with no identifiable mesh code (%d)" % _unresolved_mesh_count
	var warning_label: Label = unresolved_mesh_check.get_meta("warning_label")
	warning_label.visible = has_unresolved

func _selected_categories() -> Array:
	var result: Array = []
	for code in _category_checks:
		if (_category_checks[code] as CheckBox).button_pressed:
			result.append(code)
	return result

func _selected_meshes() -> Array:
	var result := mesh_grid.get_selected_codes()
	if unresolved_mesh_check.visible and unresolved_mesh_check.button_pressed:
		result.append("?")
	return result

func _update_selection_estimate() -> void:
	if _zip_index.is_empty():
		return
	var est := FileIndex.selected_size(_zip_index, _selected_categories(), _selected_meshes(), false)
	selection_estimate_label.text = "Current selection: %d file(s), %s (uncompressed, before extraction)." % [est["files"], _human_size(est["size"])]

func _on_extract_pressed() -> void:
	if _current_zip_abs_path == "":
		return
	var target_dir := zip_output_dir_edit.text.strip_edges()
	if target_dir == "" or not target_dir.begins_with("res://"):
		extract_result_label.text = "[color=orange]The target folder must start with res://.[/color]"
		return

	var paths := FileIndex.selected_paths(_zip_index, _selected_categories(), _selected_meshes(), false)
	if paths.is_empty():
		extract_result_label.text = "[color=orange]No files selected (check the categories/meshes ticked above).[/color]"
		return

	extract_button.disabled = true
	extract_result_label.text = "Extracting %d file(s)..." % paths.size()

	if clear_before_extract_check.button_pressed:
		SelectiveExtractor.clear_directory_contents(target_dir)

	var result := SelectiveExtractor.extract(_current_zip_abs_path, paths, target_dir)

	extract_button.disabled = false
	if result["success"]:
		extract_result_label.text = "[b]%s[/b]\nSection C below has been pre-filled with this folder." % result["message"]
		import_path_edit.text = target_dir
		_maybe_auto_detect_origin(target_dir)
		extraction_finished.emit(target_dir)
	else:
		extract_result_label.text = "[color=orange]%s[/color]" % result["message"]

## =========================================================================
## C. Import
## =========================================================================

func _on_import_browse_pressed() -> void:
	import_file_dialog.popup_centered_ratio(0.7)

func _on_import_path_selected(path: String) -> void:
	import_path_edit.text = path

func _on_project_origin_changed() -> void:
	_update_origin_display()

func _update_origin_display() -> void:
	if _project_origin == null or origin_display_label == null:
		return
	if _project_origin.is_default():
		origin_display_label.text = "Project origin not set yet (see Project Setup above)."
	else:
		origin_display_label.text = "Project origin: zone %d, %.6f, %.6f" % [_project_origin.zone, _project_origin.lat, _project_origin.lon]

## If no project origin has been set yet, detects one from the given path
## automatically - so a first-time "catalog -> extract -> import" run
## doesn't require a separate manual step. Never overwrites an origin the
## person already set on purpose.
func _maybe_auto_detect_origin(path: String) -> void:
	if _project_origin == null or not _project_origin.is_default():
		return
	var abs_path := ProjectSettings.globalize_path(path) if path.begins_with("res://") else path
	var suggestion = OriginFinder.suggest(abs_path)
	if suggestion != null:
		_project_origin.set_origin(int(suggestion["zone"]), suggestion["lat"], suggestion["lon"])

func _on_import_pressed() -> void:
	var path := import_path_edit.text.strip_edges()
	if path == "":
		import_status_label.text = "Enter a file or folder first."
		return
	if _project_origin == null:
		import_status_label.text = "No project origin available."
		return

	var scene_root := EditorInterface.get_edited_scene_root()
	if scene_root == null or not (scene_root is Node3D):
		import_status_label.text = "Open a 3D scene (with a 3D node as its root) in the editor before importing."
		return

	var abs_path := ProjectSettings.globalize_path(path) if path.begins_with("res://") else path
	var target_lod: int = lod_option.get_item_id(lod_option.selected)

	import_button.disabled = true
	import_status_label.text = "Importing (this can take a few seconds to a few dozen seconds depending on the building count, the editor may appear frozen meanwhile)..."
	import_result_label.text = ""

	var result := CityGmlImporter.import_to_scene(abs_path, target_lod, _project_origin.zone, _project_origin.lat, _project_origin.lon, scene_root as Node3D, load_textures_check.button_pressed, generate_collision_check.button_pressed)

	import_button.disabled = false
	import_status_label.text = ""
	if result["success"]:
		import_result_label.text = "[b]%s[/b]" % result["message"]
	else:
		import_result_label.text = "[color=orange]%s[/color]" % result["message"]
	if not (result["failed_files"] as Array).is_empty():
		import_result_label.text += "\n[color=orange]Failed files:[/color]\n" + "\n".join(result["failed_files"])
	var missing_textures: Array = result.get("missing_textures", [])
	if not missing_textures.is_empty():
		var preview: Array = missing_textures.slice(0, 10)
		import_result_label.text += "\n[color=orange]Texture images not found (%d, flat color used instead):[/color]\n" % missing_textures.size()
		import_result_label.text += "\n".join(preview)
		if missing_textures.size() > preview.size():
			import_result_label.text += "\n... and %d more." % (missing_textures.size() - preview.size())
