## file_index.gd
## Interprets the entry paths of a PLATEAU CityGML zip (as returned by
## PlateauZipCentralDirectory.read_entries()) to extract, per entry, the
## feature category ("udx/<prefix>/...") and mesh code (the 8-digit number
## in the file name).
##
## Naming convention confirmed by multiple independent sources:
## (mesh code)_(category prefix)_(EPSG)_(option)_op.gml, e.g.
## "53394601_bldg_6697_op.gml" - see
## https://qiita.com/saoyagi2/items/d0f17d1e9ce8fe0487cf and
## https://www.mlit.go.jp/plateau/learning/tpc03-2/
##
## Known special case: the fld folder (flood risk areas) nests an extra
## folder level (river basin, national or prefectural) before the files
## themselves - udx/fld/natl/<basin>/<meshcode>_fld_..._op.gml - see
## https://note.com/sakamo1112/n/n012a72def22c for a full example tree.
## Mesh code detection therefore looks at the FILE NAME alone, not the full
## path, to stay robust to this kind of variation. If no 8-digit code is
## found in the file name, the entry is filed under the key "?" rather than
## silently dropped.
##
## Category labels: only the ones confirmed by at least one independent
## source (see README.md for details). A code missing from
## FEATURE_TYPE_LABELS is shown as-is rather than replaced with a guessed label.
@tool
extends RefCounted
class_name PlateauFileIndex

const FEATURE_TYPE_LABELS := {
	"bldg": "Buildings",
	"tran": "Transportation (roads)",
	"luse": "Land use",
	"urf": "Urban planning designations",
	"dem": "Terrain",
	"fld": "Flood risk areas",
	"tnm": "Tsunami inundation areas",
	"htd": "High tide inundation areas",
	"lsld": "Landslide hazard areas",
	"brid": "Bridges",
	"frn": "City furniture / utilities",
	"veg": "Vegetation",
	"ubld": "Underground malls",
	"gen": "Generic attributes",
}

static func label_for(category_code: String) -> String:
	return FEATURE_TYPE_LABELS.get(category_code, category_code)

## entries: Array[Dictionary] from PlateauZipCentralDirectory.read_entries().
## Returns { by_category: { code: { total_size:int, file_count:int,
##           meshes: { mesh_code: { size:int, files:Array[String] } } } } }
## (this shape directly answers the UI's needs: total size per category,
## per-mesh detail on demand).
static func build_index(entries: Array) -> Dictionary:
	var by_category := {}
	var mesh_regex := RegEx.new()
	mesh_regex.compile("(\\d{8})")

	for entry in entries:
		var path: String = entry.get("path", "")
		if path.ends_with("/") or not path.begins_with("udx/"):
			continue # skip directories and anything outside udx/ (metadata, codelists, schemas, specification, *_indexmap_op.pdf...)

		var parts := path.split("/")
		if parts.size() < 2:
			continue
		var category: String = parts[1]

		var file_name := path.get_file()
		var mesh_code := "?"
		var m := mesh_regex.search(file_name)
		if m:
			mesh_code = m.get_string(1)
		else:
			# Texture/appearance images don't carry the mesh code in their
			# OWN filename (PLATEAU names them arbitrarily, e.g.
			# "yk100939.jpg") - they live in a folder named after their
			# parent .gml instead, e.g.
			# "udx/bldg/53391532_bldg_6697_appearance/yk100939.jpg".
			# Without this fallback, every texture image fell into the "?"
			# (unresolved) bucket and got silently excluded from
			# extraction once that bucket became unchecked by default -
			# scan the enclosing path segments for the same 8-digit
			# pattern so these files are correctly grouped with the rest
			# of their mesh instead.
			for part in parts:
				var pm := mesh_regex.search(part)
				if pm:
					mesh_code = pm.get_string(1)
					break

		var size: int = entry.get("uncompressed_size", 0)

		if not by_category.has(category):
			by_category[category] = {"total_size": 0, "file_count": 0, "meshes": {}}
		var cat_entry: Dictionary = by_category[category]
		cat_entry["total_size"] += size
		cat_entry["file_count"] += 1

		var meshes: Dictionary = cat_entry["meshes"]
		if not meshes.has(mesh_code):
			meshes[mesh_code] = {"size": 0, "files": []}
		meshes[mesh_code]["size"] += size
		(meshes[mesh_code]["files"] as Array).append(path)

	return {"by_category": by_category}

## Union of entry paths matching the selected categories and mesh codes.
## all_meshes=true ignores the mesh filter (takes every mesh of the
## selected categories).
static func selected_paths(index: Dictionary, selected_categories: Array, selected_meshes: Array, all_meshes: bool) -> Array:
	var mesh_set := {}
	for mc in selected_meshes:
		mesh_set[mc] = true

	var paths: Array = []
	var by_category: Dictionary = index.get("by_category", {})
	for category in selected_categories:
		if not by_category.has(category):
			continue
		var meshes: Dictionary = by_category[category]["meshes"]
		for mesh_code in meshes.keys():
			if all_meshes or mesh_set.has(mesh_code):
				paths.append_array(meshes[mesh_code]["files"])
	return paths

## Same filter as selected_paths(), but only returns the total size (for
## instant feedback while the person checks/unchecks boxes, without
## rebuilding the full path list on every click).
static func selected_size(index: Dictionary, selected_categories: Array, selected_meshes: Array, all_meshes: bool) -> Dictionary:
	var mesh_set := {}
	for mc in selected_meshes:
		mesh_set[mc] = true

	var total_size := 0
	var total_files := 0
	var by_category: Dictionary = index.get("by_category", {})
	for category in selected_categories:
		if not by_category.has(category):
			continue
		var meshes: Dictionary = by_category[category]["meshes"]
		for mesh_code in meshes.keys():
			if all_meshes or mesh_set.has(mesh_code):
				total_size += meshes[mesh_code]["size"]
				total_files += (meshes[mesh_code]["files"] as Array).size()
	return {"size": total_size, "files": total_files}

## Sorted list of every mesh code present, across all categories.
static func all_mesh_codes(index: Dictionary) -> Array:
	var set := {}
	var by_category: Dictionary = index.get("by_category", {})
	for category in by_category.keys():
		for mesh_code in (by_category[category]["meshes"] as Dictionary).keys():
			set[mesh_code] = true
	var result := set.keys()
	result.sort()
	return result
