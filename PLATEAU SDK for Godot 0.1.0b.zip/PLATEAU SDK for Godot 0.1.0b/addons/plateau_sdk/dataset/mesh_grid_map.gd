## mesh_grid_map.gd
## Interactive map widget: displays every mesh code from an analyzed
## PLATEAU zip as a rectangle over a GSI tile basemap ("pale" style tiles -
## a light background suited to overlaying data, see
## https://maps.gsi.go.jp/development/ichiran.html). Transparent blue =
## unselected, transparent orange = selected.
##
## Interactions, in the spirit of PLATEAU GIS Converter
## (https://github.com/Project-PLATEAU/PLATEAU-GIS-Converter):
## - Click a mesh: toggles its selection.
## - Drag (no Shift): pans the map (like the Ortho tab's minimap).
## - Shift + drag: draws a rectangle, selects (adds to the selection) every
##   mesh it touches.
## - Wheel: zoom.
##
## GSI tile attribution is required ("国土地理院" / GSI) - shown in the
## panel, not in this widget itself.
@tool
extends Control
class_name PlateauMeshGridMap

const TileMath = preload("res://addons/plateau_sdk/core/tile_math.gd")
const MeshCodeMath = preload("res://addons/plateau_sdk/core/mesh_code_math.gd")

signal selection_changed()

const TILE_SIZE := 256
const MIN_ZOOM := 5
const MAX_ZOOM := 18
const POOL_SIZE := 6
const CLICK_MOVE_THRESHOLD_PX := 4.0
const TILE_URL_TEMPLATE := "https://cyberjapandata.gsi.go.jp/xyz/pale/{z}/{x}/{y}.png"
const USER_AGENT_HEADER := "User-Agent: Mozilla/5.0 (compatible; PlateauSDK/1.0; Godot)"

var center_lon: float = 139.767
var center_lat: float = 35.681
var zoom: int = 10

# mesh_code -> { min_lat, min_lon, max_lat, max_lon }
var mesh_bounds: Dictionary = {}
# mesh_code -> true (only selected meshes are present)
var _selected: Dictionary = {}

var _tile_cache: Dictionary = {}
var _pending: Dictionary = {}
var _queue: Array = []
var _pool: Array[HTTPRequest] = []
var _pool_busy: Array[bool] = []
var _pool_tile_key: Array[String] = []

var _dragging_pan := false
var _rect_selecting := false
var _press_start_px := Vector2.ZERO
var _press_last_px := Vector2.ZERO
var _press_moved := false

func _ready() -> void:
	clip_contents = true
	if custom_minimum_size == Vector2.ZERO:
		custom_minimum_size = Vector2(360, 360)
	mouse_filter = Control.MOUSE_FILTER_STOP
	for i in range(POOL_SIZE):
		var req := HTTPRequest.new()
		add_child(req)
		var idx := i
		req.request_completed.connect(func(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray):
			_on_tile_request_completed(idx, result, response_code, body))
		_pool.append(req)
		_pool_busy.append(false)
		_pool_tile_key.append("")
	resized.connect(queue_redraw)

## =========================================================================
## Public API
## =========================================================================

## Replaces the list of displayed meshes. Codes that aren't exactly 8
## digits (unresolvable meshes, e.g. "?") are skipped here - handle them
## separately in the panel (see dataset_panel.gd) since they can't be
## placed on the map.
func set_mesh_codes(codes: Array) -> void:
	mesh_bounds.clear()
	_selected.clear()
	for code in codes:
		var b = MeshCodeMath.bounds_8digit(str(code))
		if b != null:
			mesh_bounds[code] = b
			# Unselected by default: importing whatever the map happens to
			# be showing, without the person actively picking anything, is
			# an easy way to accidentally extract far more than intended.
	# Deferred rather than called immediately: right after set_mesh_codes()
	# is called (typically right after the widget was just added to the
	# tree, e.g. after analyzing a zip), get_rect().size may not reflect
	# the final laid-out size yet, which made auto-framing pick a much too
	# zoomed-out view. Waiting a frame lets layout settle first.
	call_deferred("_fit_to_meshes")
	queue_redraw()
	selection_changed.emit()

func select_all() -> void:
	for code in mesh_bounds:
		_selected[code] = true
	queue_redraw()
	selection_changed.emit()

func deselect_all() -> void:
	_selected.clear()
	queue_redraw()
	selection_changed.emit()

func get_selected_codes() -> Array:
	return _selected.keys()

## Zoom buttons (see dataset_panel.gd): a mouse-wheel zoom is also handled
## in _gui_input(), but scrolling over this widget can fight with an
## enclosing ScrollContainer's own scroll - explicit +/- buttons are a
## reliable alternative that doesn't depend on that event ever being
## consumed correctly.
func zoom_in() -> void:
	_set_zoom(zoom + 1)

func zoom_out() -> void:
	_set_zoom(zoom - 1)

## =========================================================================
## Auto-framing
## =========================================================================

func _fit_to_meshes() -> void:
	if mesh_bounds.is_empty():
		return
	var min_lat := INF
	var max_lat := -INF
	var min_lon := INF
	var max_lon := -INF
	for code in mesh_bounds:
		var b: Dictionary = mesh_bounds[code]
		min_lat = minf(min_lat, b["min_lat"])
		max_lat = maxf(max_lat, b["max_lat"])
		min_lon = minf(min_lon, b["min_lon"])
		max_lon = maxf(max_lon, b["max_lon"])

	center_lat = (min_lat + max_lat) / 2.0
	center_lon = (min_lon + max_lon) / 2.0

	# custom_minimum_size.x is deliberately 0 (the widget expands to fill
	# whatever width its container gives it), so it's not a usable
	# fallback width - fall back to a reasonably typical dock width instead
	# of 0, which would otherwise make every zoom level fail the fit check
	# below and silently default to the most zoomed-out view every time.
	var view_size := get_rect().size
	if view_size.x < 1.0 or view_size.y < 1.0:
		view_size = Vector2(maxf(custom_minimum_size.x, 320.0), maxf(custom_minimum_size.y, 320.0))

	for z in range(MAX_ZOOM, MIN_ZOOM - 1, -1):
		var sw := TileMath.lonlat_to_tile_f(min_lon, min_lat, z) * TILE_SIZE
		var ne := TileMath.lonlat_to_tile_f(max_lon, max_lat, z) * TILE_SIZE
		var span := (sw - ne).abs()
		if span.x <= view_size.x * 0.9 and span.y <= view_size.y * 0.9:
			zoom = z
			queue_redraw()
			return
	zoom = MIN_ZOOM
	queue_redraw()

## =========================================================================
## Mouse input
## =========================================================================

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_press_start_px = mb.position
				_press_last_px = mb.position
				_press_moved = false
				_rect_selecting = mb.shift_pressed
				_dragging_pan = not mb.shift_pressed
			else:
				if _rect_selecting:
					_commit_rect_selection(mb.position)
				elif not _press_moved:
					_toggle_mesh_at(mb.position)
				_rect_selecting = false
				_dragging_pan = false
			queue_redraw()
		elif mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
			_set_zoom(zoom + 1)
			accept_event() # stop this from also scrolling an enclosing ScrollContainer
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
			_set_zoom(zoom - 1)
			accept_event()
	elif event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		if _dragging_pan or _rect_selecting:
			if mm.position.distance_to(_press_start_px) > CLICK_MOVE_THRESHOLD_PX:
				_press_moved = true
			if _dragging_pan:
				var delta := mm.position - _press_last_px
				_press_last_px = mm.position
				_pan_by_pixels(-delta)
			else:
				_press_last_px = mm.position
				queue_redraw()

func _set_zoom(new_zoom: int) -> void:
	zoom = clampi(new_zoom, MIN_ZOOM, MAX_ZOOM)
	queue_redraw()

func _pan_by_pixels(delta_px: Vector2) -> void:
	var center_tile := TileMath.lonlat_to_tile_f(center_lon, center_lat, zoom)
	var new_center_tile := center_tile + delta_px / TILE_SIZE
	var lonlat := TileMath.tile_to_lonlat_f(new_center_tile.x, new_center_tile.y, zoom)
	center_lon = lonlat.x
	center_lat = lonlat.y
	queue_redraw()

func _top_left_px() -> Vector2:
	var view_size := get_rect().size
	var center_tile := TileMath.lonlat_to_tile_f(center_lon, center_lat, zoom)
	return center_tile * TILE_SIZE - view_size / 2.0

## Screen rect (widget-local pixels) of a mesh.
func _mesh_screen_rect(bounds: Dictionary, top_left_px: Vector2) -> Rect2:
	var p1 := TileMath.lonlat_to_tile_f(bounds["min_lon"], bounds["min_lat"], zoom) * TILE_SIZE - top_left_px
	var p2 := TileMath.lonlat_to_tile_f(bounds["max_lon"], bounds["max_lat"], zoom) * TILE_SIZE - top_left_px
	return Rect2(Vector2(minf(p1.x, p2.x), minf(p1.y, p2.y)), (p1 - p2).abs())

func _toggle_mesh_at(pixel_pos: Vector2) -> void:
	var top_left_px := _top_left_px()
	for code in mesh_bounds:
		var rect := _mesh_screen_rect(mesh_bounds[code], top_left_px)
		if rect.has_point(pixel_pos):
			if _selected.has(code):
				_selected.erase(code)
			else:
				_selected[code] = true
			queue_redraw()
			selection_changed.emit()
			return

func _commit_rect_selection(end_pos: Vector2) -> void:
	var sel_rect := Rect2(_press_start_px, end_pos - _press_start_px).abs()
	var top_left_px := _top_left_px()
	var changed := false
	for code in mesh_bounds:
		var rect := _mesh_screen_rect(mesh_bounds[code], top_left_px)
		if sel_rect.intersects(rect):
			if not _selected.has(code):
				changed = true
			_selected[code] = true
	queue_redraw()
	if changed:
		selection_changed.emit()

## =========================================================================
## Drawing
## =========================================================================

func _draw() -> void:
	var view_size := get_rect().size
	var top_left_px := _top_left_px()

	var first_tx := int(floor(top_left_px.x / TILE_SIZE))
	var first_ty := int(floor(top_left_px.y / TILE_SIZE))
	var tiles_x := int(ceil(view_size.x / TILE_SIZE)) + 2
	var tiles_y := int(ceil(view_size.y / TILE_SIZE)) + 2

	for ty in range(first_ty, first_ty + tiles_y):
		for tx in range(first_tx, first_tx + tiles_x):
			var draw_pos := Vector2(tx * TILE_SIZE, ty * TILE_SIZE) - top_left_px
			var tex := _get_tile_texture(tx, ty)
			if tex != null:
				draw_texture_rect(tex, Rect2(draw_pos, Vector2(TILE_SIZE, TILE_SIZE)), false)
			else:
				draw_rect(Rect2(draw_pos, Vector2(TILE_SIZE, TILE_SIZE)), Color(0.85, 0.85, 0.85), true)

	var font := get_theme_default_font()
	for code in mesh_bounds:
		var rect := _mesh_screen_rect(mesh_bounds[code], top_left_px)
		var is_selected: bool = _selected.has(code)
		var fill := Color(1.0, 0.6, 0.1, 0.45) if is_selected else Color(0.2, 0.55, 1.0, 0.30)
		var border := Color(1.0, 0.6, 0.1, 0.9) if is_selected else Color(0.2, 0.55, 1.0, 0.7)
		draw_rect(rect, fill, true)
		draw_rect(rect, border, false, 1.5)
		if rect.size.x > 46 and rect.size.y > 20 and font != null:
			draw_string(font, rect.position + Vector2(3, 14), str(code), HORIZONTAL_ALIGNMENT_LEFT, rect.size.x - 6, 10)

	if _rect_selecting:
		var sel_rect := Rect2(_press_start_px, _press_last_px - _press_start_px).abs()
		draw_rect(sel_rect, Color(1, 1, 1, 0.15), true)
		draw_rect(sel_rect, Color(1, 1, 1, 0.8), false, 1.5)

## =========================================================================
## Tile loading (mirrors ortho/ortho_minimap.gd in spirit)
## =========================================================================

func _get_tile_texture(tx: int, ty: int) -> Texture2D:
	var n := int(pow(2.0, zoom))
	if n <= 0:
		return null
	var wrapped_tx := ((tx % n) + n) % n
	if ty < 0 or ty >= n:
		return null
	var key := "%d_%d_%d" % [zoom, wrapped_tx, ty]
	if _tile_cache.has(key):
		return _tile_cache[key]
	if not _pending.has(key):
		_pending[key] = true
		_queue.append(key)
		_pump_queue()
	return null

func _pump_queue() -> void:
	for i in range(POOL_SIZE):
		if _queue.is_empty():
			return
		if not _pool_busy[i]:
			var key: String = _queue.pop_front()
			var parts := key.split("_")
			var z := int(parts[0])
			var tx := int(parts[1])
			var ty := int(parts[2])
			var url := TILE_URL_TEMPLATE.replace("{z}", str(z)).replace("{x}", str(tx)).replace("{y}", str(ty))
			_pool_busy[i] = true
			_pool_tile_key[i] = key
			var err := _pool[i].request(url, [USER_AGENT_HEADER])
			if err != OK:
				_pool_busy[i] = false
				_pending.erase(key)

func _on_tile_request_completed(pool_index: int, result: int, response_code: int, body: PackedByteArray) -> void:
	var key := _pool_tile_key[pool_index]
	_pool_busy[pool_index] = false
	_pending.erase(key)
	if result == HTTPRequest.RESULT_SUCCESS and response_code == 200:
		var img := Image.new()
		if img.load_png_from_buffer(body) == OK:
			_tile_cache[key] = ImageTexture.create_from_image(img)
			queue_redraw()
	_pump_queue()
