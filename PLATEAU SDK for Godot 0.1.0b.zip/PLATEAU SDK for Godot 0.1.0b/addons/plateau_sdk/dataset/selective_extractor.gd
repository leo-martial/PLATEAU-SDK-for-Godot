## selective_extractor.gd
## Extracts only the requested paths from a local zip (not the whole zip)
## into a res:// folder in the project. Unlike PlateauZipCentralDirectory
## (metadata-only reading), this script uses Godot's native ZIPReader class
## for the actual decompression, which is exactly its job.
##
## Runs in a single (blocking) pass. For a selection of a few dozen to a few
## hundred .gml files (the normal case: one or a handful of meshes, one or a
## few categories), this is fast. For a selection of several thousand files
## (e.g. "every mesh, every category" on a large city, which is roughly a
## full extraction anyway), expect this to take a while and block the
## editor: no progress reporting during the extraction itself in this
## version (only before/after) - worth spreading over multiple frames if
## this turns out to be a problem in practice.
@tool
extends RefCounted
class_name PlateauSelectiveExtractor

## Returns { success: bool, extracted: int, failed: Array[String], message: String }
static func extract(absolute_zip_path: String, paths: Array, target_res_dir: String) -> Dictionary:
	var reader := ZIPReader.new()
	var open_err := reader.open(absolute_zip_path)
	if open_err != OK:
		return {"success": false, "extracted": 0, "failed": [], "message": "Could not open the zip (error %d)." % open_err}

	if not DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(target_res_dir)):
		DirAccess.make_dir_recursive_absolute(target_res_dir)

	var extracted := 0
	var failed: Array = []

	for path in paths:
		if not reader.file_exists(path):
			failed.append(path)
			continue

		var content := reader.read_file(path)
		var dest_path: String = target_res_dir.path_join(path)
		DirAccess.make_dir_recursive_absolute(dest_path.get_base_dir())

		var f := FileAccess.open(dest_path, FileAccess.WRITE)
		if f == null:
			failed.append(path)
			continue
		f.store_buffer(content)
		f.close()
		extracted += 1

	reader.close()

	if Engine.is_editor_hint():
		EditorInterface.get_resource_filesystem().scan()

	var message := "%d file(s) extracted to %s." % [extracted, target_res_dir]
	if not failed.is_empty():
		message += " %d file(s) failed (see list)." % failed.size()

	return {"success": extracted > 0, "extracted": extracted, "failed": failed, "message": message}

## Recursively deletes everything INSIDE target_res_dir (the folder itself
## is kept). Meant to be called right before extract() targeting the same
## folder, when the person wants "just this selection" rather than
## accumulating files from every extraction they've ever run into that
## folder - the target folder name only depends on the zip's filename (set
## once, at "Analyze zip" time), not on which categories/meshes are
## currently checked, so two DIFFERENT selections extracted one after the
## other without re-analyzing land in the SAME folder by default, and
## extract() only ever writes files, never removes ones from a previous,
## different selection.
static func clear_directory_contents(target_res_dir: String) -> void:
	var abs_dir := ProjectSettings.globalize_path(target_res_dir)
	if not DirAccess.dir_exists_absolute(abs_dir):
		return
	_remove_dir_contents_recursive(abs_dir)
	if Engine.is_editor_hint():
		EditorInterface.get_resource_filesystem().scan()

static func _remove_dir_contents_recursive(abs_dir: String) -> void:
	var dir := DirAccess.open(abs_dir)
	if dir == null:
		return
	dir.list_dir_begin()
	var entry := dir.get_next()
	while entry != "":
		if entry != "." and entry != "..":
			var full_path := abs_dir.path_join(entry)
			if dir.current_is_dir():
				_remove_dir_contents_recursive(full_path)
				DirAccess.remove_absolute(full_path)
			else:
				DirAccess.remove_absolute(full_path)
		entry = dir.get_next()
	dir.list_dir_end()
