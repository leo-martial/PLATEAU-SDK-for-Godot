# Third-party assets: Exploration tab characters

The `exploration/characters/` folder contains code and assets adapted
from two of Kenney's official Godot starter kits:

- **Starter Kit 3D Platformer** - https://github.com/Kenney-NL/Starter-Kit-3D-Platformer
  Copyright (c) 2023 Kenney. Source for `characters/third_person/`
  (character model, animations, movement script, orbit camera script,
  particle trail, shadow decal, jump/land/walk sounds).
- **Starter Kit FPS** - https://github.com/Kenney-NL/Starter-Kit-FPS
  Copyright (c) 2025 Kenney. Source for `characters/first_person/`
  (movement/look script, shadow decal, jump/land/walk sounds) and for
  `characters/shared/audio.gd`.

Both are distributed under the MIT License (full text below, identical
for both kits at the time these files were adapted). This SDK's own
license (see the repository root, if one is declared) applies to the
*integration* code (`exploration_panel.gd`, `scene_top_view.gd`,
`core/scene_geometry_utils.gd`, `plugin.gd`'s autoload/input registration)
- not to the Kenney-authored assets themselves, which remain under the
license below regardless of where this SDK's own license permits or
restricts things.

## What was changed from the originals

- **First-person character**: the entire weapon system was removed -
  no `weapons` export, no view-model container/muzzle sprite/raycast/
  cooldown timer, no shoot or weapon-switch actions, no damage/health.
  Only movement, mouse-look/gamepad-look, jump, and footstep/landing
  sound remain, functionally unchanged from the original.
- **Third-person character**: functionally unchanged (movement, jump,
  double-jump, animation, particle trail, camera orbit/zoom) - only
  `Audio.play()` calls were adjusted to match this addon's shared
  `Audio` autoload path convention (see `shared/audio.gd`).
- Both: coin collection, platforms, falling/respawn-on-death, and every
  other piece of the original starter kits' own demo *gameplay* (not the
  character itself) were left out entirely - this SDK only reuses the
  character controllers, not the sample levels built around them.
- File paths were changed to fit inside this addon (`res://addons/
  plateau_sdk/exploration/characters/...` instead of the original kits'
  `res://...` layout), and the shared `Audio` autoload's `play()` method
  now prepends that base path automatically.

## MIT License

```
MIT License

Copyright (c) 2023-2025 Kenney

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
