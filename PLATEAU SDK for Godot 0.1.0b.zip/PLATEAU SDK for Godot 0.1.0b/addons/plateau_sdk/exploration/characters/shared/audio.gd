## audio.gd
## Simple pooled sound player, registered as an "Audio" autoload singleton
## by plugin.gd when the PLATEAU SDK plugin is enabled (see
## EditorPlugin.add_autoload_singleton() in plugin.gd). Used by both
## exploration characters for jump/land/footstep sounds.
##
## Adapted from Kenney's Starter Kit FPS (scripts/audio.gd), itself
## "adapted from KidsCanCode" per its own comment. Kept as a separate
## runtime script (NOT @tool) since it needs to run during Play, not in
## the editor.
##
## Usage: Audio.play("some.ogg") or Audio.play("a.ogg, b.ogg, c.ogg") to
## pick one at random - paths are relative to this addon's characters/
## folder root and get "res://addons/plateau_sdk/exploration/characters/"
## prepended automatically, so callers don't need to spell out the full path.
extends Node

const BASE_PATH := "res://addons/plateau_sdk/exploration/characters/"

var num_players = 12
var bus = "master"

var available = []  # available AudioStreamPlayer nodes
var queue = []       # queued resource paths waiting for a free player

func _ready():
	for i in num_players:
		var p = AudioStreamPlayer.new()
		add_child(p)

		available.append(p)

		p.volume_db = -10
		p.finished.connect(_on_stream_finished.bind(p))
		p.bus = bus

func _on_stream_finished(stream):
	available.append(stream)

func play(sound_path):  # one path, or several separated by commas (one picked at random)
	var sounds = sound_path.split(",")
	queue.append(BASE_PATH + sounds[randi() % sounds.size()].strip_edges())

func _process(_delta):
	if not queue.is_empty() and not available.is_empty():
		available[0].stream = load(queue.pop_front())
		available[0].play()
		available[0].pitch_scale = randf_range(0.9, 1.1)

		available.pop_front()
