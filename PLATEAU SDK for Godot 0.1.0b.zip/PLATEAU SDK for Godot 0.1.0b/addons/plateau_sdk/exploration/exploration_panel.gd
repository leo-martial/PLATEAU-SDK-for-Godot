## exploration_panel.gd
## "Exploration" tab: pick a character (third-person or first-person, both
## adapted from Kenney's official Godot starter kits, MIT-licensed - see
## README.md), click a spot on the top-down schematic of the current
## scene to place it, optionally snapped to the ground/lowest building
## height, and drop it into the open scene with one button.
##
## Placing a character only positions it - it doesn't move by itself until
## the scene is actually run (Play / F6), since movement is driven by
## Input actions processed during _process()/_physics_process(), which
## don't run while just editing.
@tool
extends Control
class_name PlateauExplorationPanel

const SceneGeometryUtils = preload("res://addons/plateau_sdk/core/scene_geometry_utils.gd")
const TopView = preload("res://addons/plateau_sdk/exploration/scene_top_view.gd")

const THIRD_PERSON_SCENE_PATH := "res://addons/plateau_sdk/exploration/characters/third_person/explorer_third_person.tscn"
const FIRST_PERSON_SCENE_PATH := "res://addons/plateau_sdk/exploration/characters/first_person/explorer_first_person.tscn"
const THIRD_PERSON_ROOT_NAME := "ThirdPersonExplorer"
const FIRST_PERSON_ROOT_NAME := "FirstPersonExplorer"

var character_type_option: OptionButton
var top_view: PlateauSceneTopView
var refresh_button: Button
var picked_label: Label
var snap_to_floor_check: CheckBox
var manual_y_edit: LineEdit
var place_button: Button
var status_label: Label
var remove_button: Button

func _ready() -> void:
	if not Engine.is_editor_hint():
		return
	_build_ui()

func _build_ui() -> void:
	var scroll := ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(scroll)

	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_theme_constant_override("separation", 6)
	scroll.add_child(root)

	var title := Label.new()
	title.text = "Exploration"
	title.add_theme_font_size_override("font_size", 16)
	root.add_child(title)

	var hint := Label.new()
	hint.text = "Places a playable character into the open scene so you can walk or fly around the imported PLATEAU data. Adapted from Kenney's official Godot starter kits (MIT license, see README.md) - the first-person one has had its weapon/shooting entirely removed."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(hint)

	root.add_child(HSeparator.new())

	var type_row := HBoxContainer.new()
	root.add_child(type_row)
	var type_label := Label.new()
	type_label.text = "Character:"
	type_label.custom_minimum_size.x = 90
	type_row.add_child(type_label)
	character_type_option = OptionButton.new()
	character_type_option.add_item("Third-person (orbit camera, jump, run)", 0)
	character_type_option.add_item("First-person (mouse look, jump, no weapon)", 1)
	character_type_option.selected = 0
	type_row.add_child(character_type_option)

	root.add_child(HSeparator.new())

	var map_title := Label.new()
	map_title.text = "Click a spot to place the character"
	root.add_child(map_title)

	refresh_button = Button.new()
	refresh_button.text = "Refresh from scene"
	refresh_button.pressed.connect(_on_refresh_pressed)
	root.add_child(refresh_button)

	var refresh_hint := Label.new()
	refresh_hint.text = "Rescans the open scene for imported buildings (3D tab) and the ground plane (2D tab) - press this again after importing more, the map doesn't update on its own."
	refresh_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	refresh_hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(refresh_hint)

	top_view = TopView.new()
	top_view.custom_minimum_size = Vector2(0, 340)
	top_view.position_picked.connect(_on_position_picked)
	root.add_child(top_view)

	var zoom_row := HBoxContainer.new()
	root.add_child(zoom_row)
	var zoom_out_button := Button.new()
	zoom_out_button.text = "- Zoom out"
	zoom_out_button.pressed.connect(func(): top_view.zoom_out())
	zoom_row.add_child(zoom_out_button)
	var zoom_in_button := Button.new()
	zoom_in_button.text = "+ Zoom in"
	zoom_in_button.pressed.connect(func(): top_view.zoom_in())
	zoom_row.add_child(zoom_in_button)

	picked_label = Label.new()
	picked_label.text = "No spot picked yet."
	picked_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	root.add_child(picked_label)

	root.add_child(HSeparator.new())

	snap_to_floor_check = CheckBox.new()
	snap_to_floor_check.text = "Snap to floor height"
	snap_to_floor_check.button_pressed = true
	snap_to_floor_check.toggled.connect(_on_snap_toggled)
	root.add_child(snap_to_floor_check)

	var snap_hint := Label.new()
	snap_hint.text = "Uses the Ortho ground plane's height if one exists in the scene, otherwise the lowest point among imported buildings, otherwise 0. This is a flat height, not per-spot terrain following - it won't account for a slope or a building you happen to click on top of."
	snap_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	snap_hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(snap_hint)

	var manual_y_row := HBoxContainer.new()
	root.add_child(manual_y_row)
	var manual_y_label := Label.new()
	manual_y_label.text = "Manual Y:"
	manual_y_label.custom_minimum_size.x = 90
	manual_y_row.add_child(manual_y_label)
	manual_y_edit = LineEdit.new()
	manual_y_edit.text = "0.0"
	manual_y_edit.editable = false
	manual_y_row.add_child(manual_y_edit)

	root.add_child(HSeparator.new())

	place_button = Button.new()
	place_button.text = "Place character in scene"
	place_button.pressed.connect(_on_place_pressed)
	root.add_child(place_button)

	remove_button = Button.new()
	remove_button.text = "Remove placed character"
	remove_button.pressed.connect(_on_remove_pressed)
	root.add_child(remove_button)

	status_label = Label.new()
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	root.add_child(status_label)

	var play_hint := Label.new()
	play_hint.text = "Placing only sets the character's position - it won't move in the editor viewport. Press Play (F6, \"run current scene\") to actually walk/look around."
	play_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	play_hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(play_hint)

	var credit := Label.new()
	credit.text = "Characters and their sounds/models: Kenney, MIT license (Starter Kit 3D Platformer, Starter Kit FPS). https://github.com/Kenney-NL"
	credit.autowrap_mode = TextServer.AUTOWRAP_WORD
	credit.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	root.add_child(credit)

func _on_refresh_pressed() -> void:
	var scene_root := EditorInterface.get_edited_scene_root()
	top_view.refresh(scene_root)
	if scene_root == null:
		status_label.text = "Open a scene in the editor first."
	elif not top_view.has_content():
		status_label.text = "No imported buildings or ground plane found in this scene yet - import something in the 3D or 2D tab first, or place the character manually anyway."
	else:
		status_label.text = ""

func _on_snap_toggled(pressed: bool) -> void:
	manual_y_edit.editable = not pressed

func _on_position_picked(x: float, z: float) -> void:
	picked_label.text = "Picked: X=%.2f, Z=%.2f" % [x, z]

func _on_place_pressed() -> void:
	if not top_view.has_picked_position():
		status_label.text = "Click a spot on the map above first."
		return

	var scene_root := EditorInterface.get_edited_scene_root()
	if scene_root == null or not (scene_root is Node3D):
		status_label.text = "Open a 3D scene (with a 3D node as its root) in the editor before placing."
		return

	var pos := top_view.get_picked_position()
	var y := _compute_floor_y(scene_root)

	var scene_path: String
	var root_name: String
	if character_type_option.selected == 0:
		scene_path = THIRD_PERSON_SCENE_PATH
		root_name = THIRD_PERSON_ROOT_NAME
	else:
		scene_path = FIRST_PERSON_SCENE_PATH
		root_name = FIRST_PERSON_ROOT_NAME

	var packed: PackedScene = load(scene_path)
	if packed == null:
		status_label.text = "Could not load %s." % scene_path
		return

	_remove_existing_characters(scene_root as Node3D)

	var instance := packed.instantiate()
	instance.name = root_name
	(scene_root as Node3D).add_child(instance)
	instance.owner = scene_root
	_set_owner_recursive(instance, scene_root)
	instance.position = Vector3(pos.x, y, pos.y)

	status_label.text = "Placed at (%.2f, %.2f, %.2f). Press Play (F6) to move around - nothing moves in the editor viewport itself." % [pos.x, y, pos.y]

func _on_remove_pressed() -> void:
	var scene_root := EditorInterface.get_edited_scene_root()
	if scene_root == null:
		status_label.text = "Open a scene in the editor first."
		return
	var removed := _remove_existing_characters(scene_root as Node3D)
	status_label.text = "Removed." if removed else "No placed character found in this scene."

func _remove_existing_characters(scene_root: Node3D) -> bool:
	var removed := false
	for existing_name in [THIRD_PERSON_ROOT_NAME, FIRST_PERSON_ROOT_NAME]:
		var existing := scene_root.get_node_or_null(existing_name)
		if existing != null:
			scene_root.remove_child(existing)
			existing.queue_free()
			removed = true
	return removed

## If "Snap to floor height" is off, uses the manual Y field (kept in sync
## with the last successful snap so switching the checkbox off starts from
## a sensible value rather than 0). Preference order when snapping: the
## Ortho ground plane's height, then the lowest point among imported
## buildings, then 0.0 as a last resort.
func _compute_floor_y(scene_root: Node) -> float:
	if not snap_to_floor_check.button_pressed:
		return manual_y_edit.text.to_float()

	var ground = SceneGeometryUtils.find_ground_plane(scene_root)
	var y := 0.0
	if ground != null:
		y = ground["y"]
	else:
		var lowest = SceneGeometryUtils.find_lowest_building_y(scene_root)
		if lowest != null:
			y = lowest
	manual_y_edit.text = "%.3f" % y
	return y

static func _set_owner_recursive(node: Node, owner: Node) -> void:
	for child in node.get_children():
		child.owner = owner
		_set_owner_recursive(child, owner)
