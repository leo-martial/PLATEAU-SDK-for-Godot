## scene_top_view.gd
## Top-down schematic of the currently edited scene's PLATEAU content:
## imported building footprints (from their mesh AABB, see
## core/scene_geometry_utils.gd) and the Ortho ground plane's extent, if
## present. NOT a true rendered top-down view (no camera/viewport
## involved) - a simple 2D schematic drawn from geometry data already
## available, in the same spirit as the other two map widgets in this SDK
## (dataset/mesh_grid_map.gd, ortho/ortho_minimap.gd), just with local
## scene data instead of network tiles.
##
## Click to pick a placement position (world X/Z); exploration_panel.gd
## reads it via get_picked_position() and computes a Y (floor height)
## separately.
@tool
extends Control
class_name PlateauSceneTopView

const SceneGeometryUtils = preload("res://addons/plateau_sdk/core/scene_geometry_utils.gd")

signal position_picked(x: float, z: float)

const MIN_ZOOM_METERS_PER_PIXEL := 0.02
const MAX_ZOOM_METERS_PER_PIXEL := 50.0
const CLICK_MOVE_THRESHOLD_PX := 4.0

var _buildings: Array = []       # see PlateauSceneGeometryUtils.collect_building_footprints()
var _ground_plane = null         # see PlateauSceneGeometryUtils.find_ground_plane(), or null

var _center_x := 0.0
var _center_z := 0.0
var _meters_per_pixel := 1.0

var _has_picked := false
var _picked_x := 0.0
var _picked_z := 0.0

var _dragging := false
var _drag_last_px := Vector2.ZERO
var _press_start_px := Vector2.ZERO
var _press_moved := false

func _ready() -> void:
	clip_contents = true
	if custom_minimum_size == Vector2.ZERO:
		custom_minimum_size = Vector2(340, 340)
	mouse_filter = Control.MOUSE_FILTER_STOP
	resized.connect(queue_redraw)

## Rescans the given scene for buildings/ground plane and re-fits the view.
## Called by exploration_panel.gd whenever the tab becomes relevant to
## refresh (there's no automatic change notification - the person may
## have imported more buildings since the tab was last shown).
func refresh(scene_root: Node) -> void:
	if scene_root == null:
		_buildings = []
		_ground_plane = null
		queue_redraw()
		return
	_buildings = SceneGeometryUtils.collect_building_footprints(scene_root)
	_ground_plane = SceneGeometryUtils.find_ground_plane(scene_root)
	_fit_view()
	queue_redraw()

func has_content() -> bool:
	return not _buildings.is_empty() or _ground_plane != null

func has_picked_position() -> bool:
	return _has_picked

## World X/Z of the last click, or {0,0} if nothing picked yet - check
## has_picked_position() first.
func get_picked_position() -> Vector2:
	return Vector2(_picked_x, _picked_z)

func zoom_in() -> void:
	_meters_per_pixel = clampf(_meters_per_pixel * 0.8, MIN_ZOOM_METERS_PER_PIXEL, MAX_ZOOM_METERS_PER_PIXEL)
	queue_redraw()

func zoom_out() -> void:
	_meters_per_pixel = clampf(_meters_per_pixel * 1.25, MIN_ZOOM_METERS_PER_PIXEL, MAX_ZOOM_METERS_PER_PIXEL)
	queue_redraw()

func _fit_view() -> void:
	var min_x := INF
	var max_x := -INF
	var min_z := INF
	var max_z := -INF
	var any := false

	if _ground_plane != null:
		var g: Dictionary = _ground_plane
		min_x = minf(min_x, g["min_x"]); max_x = maxf(max_x, g["max_x"])
		min_z = minf(min_z, g["min_z"]); max_z = maxf(max_z, g["max_z"])
		any = true
	for b in _buildings:
		var bd: Dictionary = b
		min_x = minf(min_x, bd["min_x"]); max_x = maxf(max_x, bd["max_x"])
		min_z = minf(min_z, bd["min_z"]); max_z = maxf(max_z, bd["max_z"])
		any = true

	if not any:
		_center_x = 0.0
		_center_z = 0.0
		_meters_per_pixel = 1.0
		return

	_center_x = (min_x + max_x) / 2.0
	_center_z = (min_z + max_z) / 2.0

	var view_size := get_rect().size
	if view_size.x < 1.0 or view_size.y < 1.0:
		view_size = custom_minimum_size

	var span_x := maxf(max_x - min_x, 1.0)
	var span_z := maxf(max_z - min_z, 1.0)
	var mpp_x := span_x / (view_size.x * 0.85)
	var mpp_z := span_z / (view_size.y * 0.85)
	_meters_per_pixel = clampf(maxf(mpp_x, mpp_z), MIN_ZOOM_METERS_PER_PIXEL, MAX_ZOOM_METERS_PER_PIXEL)

## World (x,z) -> widget-local pixel position. Screen +Y (down) maps to
## world +Z, matching how the scene's -Z-is-north convention (see
## citygml_importer.gd) reads naturally as "up on the map = north".
func _world_to_px(x: float, z: float) -> Vector2:
	var view_size := get_rect().size
	var dx := (x - _center_x) / _meters_per_pixel
	var dz := (z - _center_z) / _meters_per_pixel
	return Vector2(view_size.x / 2.0 + dx, view_size.y / 2.0 - dz)

func _px_to_world(px: Vector2) -> Vector2:
	var view_size := get_rect().size
	var dx := (px.x - view_size.x / 2.0) * _meters_per_pixel
	var dz := (view_size.y / 2.0 - px.y) * _meters_per_pixel
	return Vector2(_center_x + dx, _center_z + dz)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_press_start_px = mb.position
				_press_moved = false
				_dragging = true
				_drag_last_px = mb.position
			else:
				_dragging = false
				if not _press_moved:
					var world := _px_to_world(mb.position)
					_has_picked = true
					_picked_x = world.x
					_picked_z = world.y
					position_picked.emit(_picked_x, _picked_z)
					queue_redraw()
		elif mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
			zoom_in()
			accept_event()
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
			zoom_out()
			accept_event()
	elif event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		if mm.position.distance_to(_press_start_px) > CLICK_MOVE_THRESHOLD_PX:
			_press_moved = true
		if _dragging:
			var delta_px := mm.position - _drag_last_px
			_drag_last_px = mm.position
			_center_x -= delta_px.x * _meters_per_pixel
			_center_z += delta_px.y * _meters_per_pixel
			queue_redraw()

func _draw() -> void:
	var view_size := get_rect().size
	draw_rect(Rect2(Vector2.ZERO, view_size), Color(0.12, 0.12, 0.14), true)

	if _ground_plane != null:
		var g: Dictionary = _ground_plane
		var p1 := _world_to_px(g["min_x"], g["min_z"])
		var p2 := _world_to_px(g["max_x"], g["max_z"])
		var rect := Rect2(Vector2(minf(p1.x, p2.x), minf(p1.y, p2.y)), (p1 - p2).abs())
		draw_rect(rect, Color(0.45, 0.42, 0.30), true)
		draw_rect(rect, Color(0.65, 0.6, 0.4), false, 1.5)

	for b in _buildings:
		var bd: Dictionary = b
		var p1 := _world_to_px(bd["min_x"], bd["min_z"])
		var p2 := _world_to_px(bd["max_x"], bd["max_z"])
		var rect := Rect2(Vector2(minf(p1.x, p2.x), minf(p1.y, p2.y)), (p1 - p2).abs())
		draw_rect(rect, Color(0.75, 0.75, 0.78, 0.9), true)
		draw_rect(rect, Color(0.9, 0.9, 0.95), false, 1.0)

	if not has_content():
		var font := get_theme_default_font()
		if font != null:
			draw_string(font, Vector2(10, view_size.y / 2.0), "No PLATEAU buildings or ground plane found in this scene yet.", HORIZONTAL_ALIGNMENT_LEFT, view_size.x - 20, 13)

	if _has_picked:
		var p := _world_to_px(_picked_x, _picked_z)
		draw_line(p + Vector2(-10, 0), p + Vector2(10, 0), Color(1.0, 0.6, 0.1), 2.0)
		draw_line(p + Vector2(0, -10), p + Vector2(0, 10), Color(1.0, 0.6, 0.1), 2.0)
		draw_arc(p, 12.0, 0, TAU, 24, Color(1.0, 0.6, 0.1), 2.0)
