## main_panel.gd
## Root panel shown in the editor dock. Two parts:
##
## 1. Project Setup (always visible, not inside a tab): the single shared
##    zone/origin used by both tabs below, so it only has to be entered
##    once instead of duplicated everywhere. Can be typed manually or
##    detected automatically from a .gml file. Also updates itself if the
##    origin gets auto-detected from inside the "3D (PLATEAU)" tab (see
##    below), so the two stay in sync either way.
##
## 2. A TabContainer with two tabs:
##    - "3D (PLATEAU)": catalog browsing, local zip selection/extraction,
##      and CityGML import - the whole path from "find a dataset" to
##      "buildings in the scene" in one place (these used to be two
##      separate tabs; merged since it's really one continuous task).
##      Finishing an extraction auto-fills the import step below it, and -
##      if no project origin has been set yet - auto-detects one from the
##      extracted data.
##    - "2D (PLATEAU Ortho)": aerial imagery import, with an optional
##      textured ground plane aligned to the same shared project origin.
@tool
extends Control
class_name PlateauSdkPanel

const OriginFinder = preload("res://addons/plateau_sdk/core/origin_finder.gd")
const ProjectOrigin = preload("res://addons/plateau_sdk/core/project_origin.gd")
const DatasetPanel = preload("res://addons/plateau_sdk/dataset/dataset_panel.gd")
const OrthoPanel = preload("res://addons/plateau_sdk/ortho/ortho_panel.gd")
const ExplorationPanel = preload("res://addons/plateau_sdk/exploration/exploration_panel.gd")

var project_origin: PlateauProjectOrigin
var _updating_fields_from_origin := false

var zone_spin: SpinBox
var lat_edit: LineEdit
var lon_edit: LineEdit
var detect_button: Button
var detect_file_dialog: EditorFileDialog
var setup_status_label: Label

var dataset_panel: PlateauDatasetPanel
var ortho_panel: PlateauOrthoPanel
var exploration_panel: PlateauExplorationPanel

func _ready() -> void:
	if not Engine.is_editor_hint():
		return

	project_origin = ProjectOrigin.new()
	project_origin.changed.connect(_on_project_origin_changed_externally)

	var root := VBoxContainer.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("separation", 6)
	add_child(root)

	var title := Label.new()
	title.text = "PLATEAU SDK"
	title.add_theme_font_size_override("font_size", 18)
	root.add_child(title)

	_build_project_setup(root)
	root.add_child(HSeparator.new())
	_build_tabs(root)

## =========================================================================
## Shared Project Setup
## =========================================================================

func _build_project_setup(root: VBoxContainer) -> void:
	var setup_title := Label.new()
	setup_title.text = "Project Setup"
	setup_title.add_theme_font_size_override("font_size", 14)
	root.add_child(setup_title)

	var setup_hint := Label.new()
	setup_hint.text = "This origin (zone + lat/lon) is shared by both tabs below, so imported buildings and an Ortho ground plane line up automatically instead of each import re-centering on its own. Set it once here - it also updates itself automatically if detected from inside the 3D (PLATEAU) tab."
	setup_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	setup_hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(setup_hint)

	var zone_row := HBoxContainer.new()
	root.add_child(zone_row)
	var zone_label := Label.new()
	zone_label.text = "Zone (1-19):"
	zone_label.custom_minimum_size.x = 90
	zone_row.add_child(zone_label)
	zone_spin = SpinBox.new()
	zone_spin.min_value = 1
	zone_spin.max_value = 19
	zone_spin.value = 9 # Kanto/Tokyo by default
	zone_spin.value_changed.connect(_on_fields_edited)
	zone_row.add_child(zone_spin)

	var origin_grid := GridContainer.new()
	origin_grid.columns = 2
	root.add_child(origin_grid)
	lat_edit = _add_field(origin_grid, "Origin lat (0,0,0 in scene)")
	lon_edit = _add_field(origin_grid, "Origin lon (0,0,0 in scene)")

	var detect_row := HBoxContainer.new()
	root.add_child(detect_row)
	detect_button = Button.new()
	detect_button.text = "Detect from file..."
	detect_button.pressed.connect(_on_detect_pressed)
	detect_row.add_child(detect_button)

	detect_file_dialog = EditorFileDialog.new()
	detect_file_dialog.access = EditorFileDialog.ACCESS_RESOURCES
	detect_file_dialog.file_mode = EditorFileDialog.FILE_MODE_OPEN_ANY
	detect_file_dialog.add_filter("*.gml", "CityGML")
	detect_file_dialog.file_selected.connect(_on_detect_path_chosen)
	detect_file_dialog.dir_selected.connect(_on_detect_path_chosen)
	add_child(detect_file_dialog)

	setup_status_label = Label.new()
	setup_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	setup_status_label.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(setup_status_label)

func _add_field(grid: GridContainer, label_text: String) -> LineEdit:
	var label := Label.new()
	label.text = label_text
	grid.add_child(label)
	var edit := LineEdit.new()
	edit.text = "0.0"
	edit.text_changed.connect(func(_t: String): _on_fields_edited(0.0))
	grid.add_child(edit)
	return edit

func _on_fields_edited(_v: float) -> void:
	if _updating_fields_from_origin:
		return # this edit came from _on_project_origin_changed_externally() below, not the person - don't feed it back
	project_origin.set_origin(int(zone_spin.value), lat_edit.text.to_float(), lon_edit.text.to_float())

## Keeps the Project Setup fields in sync whenever project_origin changes
## for ANY reason, including from inside the "3D (PLATEAU)" tab's own
## auto-detection after an extraction - not just from this panel's own
## fields or "Detect from file..." button.
func _on_project_origin_changed_externally() -> void:
	_updating_fields_from_origin = true
	zone_spin.value = project_origin.zone
	lat_edit.text = "%.6f" % project_origin.lat
	lon_edit.text = "%.6f" % project_origin.lon
	_updating_fields_from_origin = false

func _on_detect_pressed() -> void:
	detect_file_dialog.popup_centered_ratio(0.7)

func _on_detect_path_chosen(path: String) -> void:
	var abs_path := ProjectSettings.globalize_path(path) if path.begins_with("res://") else path
	var suggestion = OriginFinder.suggest(abs_path)
	if suggestion == null:
		setup_status_label.text = "No coordinates found there (check it contains at least one readable .gml file)."
		return
	project_origin.set_origin(int(suggestion["zone"]), suggestion["lat"], suggestion["lon"])
	setup_status_label.text = "Origin detected from %s. Double-check the suggested zone (%d) if you're near a boundary between two zones." % [path, int(suggestion["zone"])]

## =========================================================================
## Tabs
## =========================================================================

func _build_tabs(root: VBoxContainer) -> void:
	var tabs := TabContainer.new()
	tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	tabs.custom_minimum_size = Vector2(340, 500)
	root.add_child(tabs)

	dataset_panel = DatasetPanel.new()
	dataset_panel.name = "3D (PLATEAU)"
	tabs.add_child(dataset_panel)
	dataset_panel.setup(project_origin)

	ortho_panel = OrthoPanel.new()
	ortho_panel.name = "2D (PLATEAU Ortho)"
	tabs.add_child(ortho_panel)
	ortho_panel.setup(project_origin)

	dataset_panel.meshes_analyzed.connect(ortho_panel.set_mesh_overlay)

	exploration_panel = ExplorationPanel.new()
	exploration_panel.name = "Exploration"
	tabs.add_child(exploration_panel)
