## ortho_downloader.gd
## Downloads a rectangular area of PLATEAU-Ortho tiles (XYZ scheme) and
## stitches them into a single Image.
##
## Tile source: Project PLATEAU / MLIT (Japan's Ministry of Land,
## Infrastructure, Transport and Tourism).
## License: CC BY 4.0, commercial use allowed, attribution required.
## https://www.mlit.go.jp/plateau/site-policy/
##
## MLIT describes this service as an experimental deployment, with no
## uptime or service-level guarantee. If TILE_URL_TEMPLATE stops
## responding, check the current URL at
## https://docs.plateauview.mlit.go.jp (PLATEAU-Ortho section, "delivery
## URL"). URL observed in 2026, template found in the official tutorial:
## https://github.com/Project-PLATEAU/plateau-streaming-tutorial/blob/main/ortho/plateau-ortho-streaming.md
##
## Deliberately sequential (one request at a time) rather than a concurrent
## pool: simpler to read/debug, plenty fast enough for an on-demand editor
## import.
@tool
extends Node
class_name PlateauOrthoDownloader

const TileMath = preload("res://addons/plateau_sdk/core/tile_math.gd")

signal progress_updated(done: int, total: int)
signal finished(image: Image, meta: Dictionary)
signal failed(message: String)

const TILE_URL_TEMPLATE := "https://api.plateauview.mlit.go.jp/tiles/plateau-ortho-2023/{z}/{x}/{y}.png"
const TILE_SIZE := 256
## Safety net: above this many tiles, download_area() refuses to start
## unless `force` is true (avoids accidentally triggering a download of
## several thousand tiles).
const MAX_TILES_WITHOUT_CONFIRM := 400
const MAX_REDIRECT_HOPS := 5
const USER_AGENT_HEADER := "User-Agent: Mozilla/5.0 (compatible; PlateauSDK/1.0; Godot)"
## A 404 means "no tile here": no point retrying. Other failures (often
## transient, more common at high zoom given the request count) are
## retried up to MAX_ATTEMPTS times.
const MAX_ATTEMPTS := 3
const RETRY_DELAY_SECONDS := 0.4

static func _is_redirect_code(code: int) -> bool:
	return code == 301 or code == 302 or code == 303 or code == 307 or code == 308

static func _extract_location(headers: PackedStringArray) -> String:
	for h in headers:
		if h.to_lower().begins_with("location:"):
			return h.substr(h.find(":") + 1).strip_edges()
	return ""

var _http: HTTPRequest

func _ready() -> void:
	_http = HTTPRequest.new()
	add_child(_http)

## Computes the tile count and final image size without downloading
## anything. Useful to show an estimate before starting the import.
func estimate(min_lon: float, min_lat: float, max_lon: float, max_lat: float, zoom: int) -> Dictionary:
	var tl := TileMath.lonlat_to_tile_f(min_lon, max_lat, zoom)
	var br := TileMath.lonlat_to_tile_f(max_lon, min_lat, zoom)
	var tx0 := int(floor(tl.x))
	var ty0 := int(floor(tl.y))
	var tx1 := int(floor(br.x))
	var ty1 := int(floor(br.y))
	var w := max(tx1 - tx0 + 1, 1)
	var h := max(ty1 - ty0 + 1, 1)
	return {
		"tx0": tx0, "ty0": ty0, "tx1": tx1, "ty1": ty1,
		"tile_count": w * h,
		"pixel_width": w * TILE_SIZE,
		"pixel_height": h * TILE_SIZE,
	}

## Downloads and stitches the area. Emits progress_updated while
## downloading, then finished(image, meta) or failed(message).
func download_area(min_lon: float, min_lat: float, max_lon: float, max_lat: float, zoom: int, force: bool = false) -> void:
	var info := estimate(min_lon, min_lat, max_lon, max_lat, zoom)
	var tile_count: int = info["tile_count"]
	if tile_count > MAX_TILES_WITHOUT_CONFIRM and not force:
		failed.emit("This area requires %d tiles (recommended cap: %d). Shrink the area or lower the import zoom." % [tile_count, MAX_TILES_WITHOUT_CONFIRM])
		return

	var tx0: int = info["tx0"]
	var ty0: int = info["ty0"]
	var tx1: int = info["tx1"]
	var ty1: int = info["ty1"]
	var w: int = info["pixel_width"]
	var h: int = info["pixel_height"]

	var canvas := Image.create(w, h, false, Image.FORMAT_RGBA8)
	canvas.fill(Color(0, 0, 0, 0))

	var total := tile_count
	var done := 0
	var missing := 0

	for ty in range(ty0, ty1 + 1):
		for tx in range(tx0, tx1 + 1):
			var fetch_result := await _fetch_tile_with_retries(zoom, tx, ty)
			if fetch_result["ok"]:
				var img := Image.new()
				if img.load_png_from_buffer(fetch_result["body"]) == OK:
					canvas.blit_rect(img, Rect2i(0, 0, TILE_SIZE, TILE_SIZE),
						Vector2i((tx - tx0) * TILE_SIZE, (ty - ty0) * TILE_SIZE))
				else:
					missing += 1
					push_warning("PLATEAU-Ortho: response received but invalid PNG for tile %d/%d/%d" % [zoom, tx, ty])
			else:
				missing += 1
				# A 404 (out of coverage) isn't logged as an error: it's a
				# normal server response, not a failure.
				if fetch_result["response_code"] != 404:
					push_warning("PLATEAU-Ortho: tile %d/%d/%d failed after %d attempt(s) (result=%d, http=%d)" % [zoom, tx, ty, MAX_ATTEMPTS, fetch_result["result"], fetch_result["response_code"]])
			done += 1
			progress_updated.emit(done, total)

	# The extent actually covered by the downloaded image: rounded to tile
	# boundaries, so usually a bit larger than the requested area
	# (min_lon/max_lon/... below, which stay the original selection). This
	# "actual_*" extent is what must be used to position/size a textured
	# 3D plane with this image, or it will end up misaligned or stretched.
	var actual_nw := TileMath.tile_to_lonlat_f(tx0, ty0, zoom)
	var actual_se := TileMath.tile_to_lonlat_f(tx1 + 1, ty1 + 1, zoom)

	var meta := {
		"min_lon": min_lon, "min_lat": min_lat, "max_lon": max_lon, "max_lat": max_lat,
		"actual_min_lon": actual_nw.x, "actual_max_lat": actual_nw.y,
		"actual_max_lon": actual_se.x, "actual_min_lat": actual_se.y,
		"zoom": zoom, "tile_count": total, "missing_tiles": missing,
		"pixel_width": w, "pixel_height": h,
	}
	finished.emit(canvas, meta)

## Downloads a tile (following redirects) with a few retries on transient
## network failure. Returns {"ok": true, "body": ...} or
## {"ok": false, "result": ..., "response_code": ...}.
func _fetch_tile_with_retries(zoom: int, tx: int, ty: int) -> Dictionary:
	var base_url := TILE_URL_TEMPLATE.replace("{z}", str(zoom)).replace("{x}", str(tx)).replace("{y}", str(ty))
	var last_result := -1
	var last_code := -1
	for attempt in range(MAX_ATTEMPTS):
		var url := base_url
		var hops := 0
		while hops <= MAX_REDIRECT_HOPS:
			var request_err := _http.request(url, [USER_AGENT_HEADER])
			if request_err != OK:
				last_result = -1
				last_code = -1
				break
			var result: Array = await _http.request_completed
			last_result = result[0]
			last_code = result[1]
			var resp_headers: PackedStringArray = result[2]
			var body: PackedByteArray = result[3]
			if last_result == HTTPRequest.RESULT_SUCCESS and _is_redirect_code(last_code):
				var location := _extract_location(resp_headers)
				if location == "":
					break
				url = location
				hops += 1
				continue
			if last_result == HTTPRequest.RESULT_SUCCESS and last_code == 200:
				return {"ok": true, "body": body}
			break
		if last_code == 404:
			break  # no data here, retrying won't help
		if attempt < MAX_ATTEMPTS - 1:
			await get_tree().create_timer(RETRY_DELAY_SECONDS).timeout
	return {"ok": false, "result": last_result, "response_code": last_code}
