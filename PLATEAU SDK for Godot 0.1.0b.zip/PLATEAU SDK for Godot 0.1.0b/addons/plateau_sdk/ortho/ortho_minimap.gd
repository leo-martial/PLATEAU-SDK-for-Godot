## ortho_minimap.gd
## Interactive editor minimap: shows PLATEAU-Ortho tiles, pans/zooms with
## the mouse, and supports three interaction modes (see interaction_mode):
## pan, drag-a-rectangle, and click-select-3D-meshes (once mesh data has
## been supplied via set_overlay_meshes() - typically forwarded from the
## "3D (PLATEAU)" tab after it analyzes a zip).
##
## The map uses PLATEAU-Ortho tiles directly as its background (no separate
## basemap provider): simple, but it means areas outside PLATEAU-Ortho
## coverage show up blank even when zoomed out. Zoom is limited to 10-19
## (the range this service advertises).
@tool
extends Control
class_name PlateauOrthoMinimap

const TileMath = preload("res://addons/plateau_sdk/core/tile_math.gd")

signal selection_changed(min_lon: float, min_lat: float, max_lon: float, max_lat: float)
signal view_changed(zoom: int, center_lon: float, center_lat: float)
signal tile_failed(response_code: int)
signal tile_loaded()

const TILE_SIZE := 256
const MIN_ZOOM := 10
const MAX_ZOOM := 19
const POOL_SIZE := 6
const MAX_REDIRECT_HOPS := 5
const USER_AGENT_HEADER := "User-Agent: Mozilla/5.0 (compatible; PlateauSDK/1.0; Godot)"
const TILE_URL_TEMPLATE := "https://api.plateauview.mlit.go.jp/tiles/plateau-ortho-2023/{z}/{x}/{y}.png"
const CLICK_MOVE_THRESHOLD_PX := 4.0

## Interaction modes (see ortho_panel.gd's mode selector). Plain integers
## rather than an exported enum so ortho_panel.gd can reference them
## without needing to preload this script just for that.
const MODE_PAN := 0
const MODE_RECT_SELECT := 1
const MODE_MESH_SELECT := 2

var center_lon: float = 139.767
var center_lat: float = 35.681
var zoom: int = 14
var interaction_mode: int = MODE_PAN

var _tile_cache: Dictionary = {}   # "z_x_y" -> Texture2D
var _pending: Dictionary = {}      # "z_x_y" -> true
var _queue: Array = []
var _pool: Array[HTTPRequest] = []
var _pool_busy: Array[bool] = []
var _pool_tile_key: Array[String] = []
var _pool_hops: Array[int] = []

var _dragging_pan := false
var _drag_last_mouse := Vector2.ZERO
var _selecting := false           # MODE_RECT_SELECT: dragging a plain rectangle
var _mesh_rect_selecting := false # MODE_MESH_SELECT: shift-dragging a rectangle over meshes
var _select_start_px := Vector2.ZERO
var _select_end_px := Vector2.ZERO
var _has_selection := false
var _press_start_px := Vector2.ZERO
var _press_moved := false

# mesh_code -> { min_lat, min_lon, max_lat, max_lon }, supplied by
# set_overlay_meshes() - typically from the "3D (PLATEAU)" tab's analyzed
# zip (see dataset_panel.gd's meshes_analyzed signal).
var _overlay_mesh_bounds: Dictionary = {}
# mesh_code -> true (only meshes currently selected via MODE_MESH_SELECT)
var _overlay_selected: Dictionary = {}

func _ready() -> void:
	clip_contents = true
	if custom_minimum_size == Vector2.ZERO:
		custom_minimum_size = Vector2(320, 320)
	mouse_filter = Control.MOUSE_FILTER_STOP
	for i in range(POOL_SIZE):
		var req := HTTPRequest.new()
		add_child(req)
		var idx := i
		req.request_completed.connect(func(result: int, response_code: int, headers: PackedStringArray, body: PackedByteArray):
			_on_tile_request_completed(idx, result, response_code, headers, body))
		_pool.append(req)
		_pool_busy.append(false)
		_pool_tile_key.append("")
		_pool_hops.append(0)
	resized.connect(queue_redraw)

func center_on(lon: float, lat: float) -> void:
	center_lon = lon
	center_lat = lat
	queue_redraw()
	view_changed.emit(zoom, center_lon, center_lat)

## Explicit zoom buttons (see ortho_panel.gd), for the same reason as
## PlateauMeshGridMap: wheel-over-map zoom can fight with an enclosing
## ScrollContainer's own scroll.
func zoom_in() -> void:
	_set_zoom(zoom + 1)

func zoom_out() -> void:
	_set_zoom(zoom - 1)

## =========================================================================
## Mesh overlay (see dataset_panel.gd's meshes_analyzed signal)
## =========================================================================

## codes that don't resolve to a valid 8-digit mesh code bounding box are
## silently skipped, same as PlateauMeshGridMap - they simply can't be
## drawn/selected on a map.
func set_overlay_meshes(mesh_bounds: Dictionary) -> void:
	_overlay_mesh_bounds = mesh_bounds
	_overlay_selected.clear()
	queue_redraw()

func has_overlay_meshes() -> bool:
	return not _overlay_mesh_bounds.is_empty()

## =========================================================================
## Mouse input
## =========================================================================

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_press_start_px = mb.position
				_press_moved = false
				match interaction_mode:
					MODE_RECT_SELECT:
						_selecting = true
						_select_start_px = mb.position
						_select_end_px = mb.position
					MODE_MESH_SELECT:
						if mb.shift_pressed:
							_mesh_rect_selecting = true
							_select_start_px = mb.position
							_select_end_px = mb.position
						else:
							_dragging_pan = true
							_drag_last_mouse = mb.position
					_:
						_dragging_pan = true
						_drag_last_mouse = mb.position
			else:
				match interaction_mode:
					MODE_RECT_SELECT:
						if _selecting:
							_selecting = false
							_select_end_px = mb.position
							_commit_selection()
					MODE_MESH_SELECT:
						if _mesh_rect_selecting:
							_mesh_rect_selecting = false
							_select_end_px = mb.position
							_commit_mesh_rect_selection()
						elif not _press_moved:
							_toggle_overlay_mesh_at(mb.position)
					_:
						pass
				_dragging_pan = false
			queue_redraw()
		elif mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
			_set_zoom(zoom + 1)
			accept_event() # stop this from also scrolling an enclosing ScrollContainer
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
			_set_zoom(zoom - 1)
			accept_event()
	elif event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		if mm.position.distance_to(_press_start_px) > CLICK_MOVE_THRESHOLD_PX:
			_press_moved = true
		if _dragging_pan:
			var delta := mm.position - _drag_last_mouse
			_drag_last_mouse = mm.position
			_pan_by_pixels(-delta)
		elif _selecting or _mesh_rect_selecting:
			_select_end_px = mm.position
			queue_redraw()

func _set_zoom(new_zoom: int) -> void:
	zoom = clampi(new_zoom, MIN_ZOOM, MAX_ZOOM)
	queue_redraw()
	view_changed.emit(zoom, center_lon, center_lat)

func _pan_by_pixels(delta_px: Vector2) -> void:
	var center_tile := TileMath.lonlat_to_tile_f(center_lon, center_lat, zoom)
	var new_center_tile := center_tile + delta_px / TILE_SIZE
	var lonlat := TileMath.tile_to_lonlat_f(new_center_tile.x, new_center_tile.y, zoom)
	center_lon = lonlat.x
	center_lat = lonlat.y
	queue_redraw()
	view_changed.emit(zoom, center_lon, center_lat)

func _top_left_px() -> Vector2:
	var view_size := get_rect().size
	var center_tile := TileMath.lonlat_to_tile_f(center_lon, center_lat, zoom)
	return center_tile * TILE_SIZE - view_size / 2.0

## =========================================================================
## Mesh overlay selection
## =========================================================================

func _overlay_mesh_screen_rect(bounds: Dictionary, top_left_px: Vector2) -> Rect2:
	var p1 := TileMath.lonlat_to_tile_f(bounds["min_lon"], bounds["min_lat"], zoom) * TILE_SIZE - top_left_px
	var p2 := TileMath.lonlat_to_tile_f(bounds["max_lon"], bounds["max_lat"], zoom) * TILE_SIZE - top_left_px
	return Rect2(Vector2(minf(p1.x, p2.x), minf(p1.y, p2.y)), (p1 - p2).abs())

func _toggle_overlay_mesh_at(pixel_pos: Vector2) -> void:
	var top_left_px := _top_left_px()
	for code in _overlay_mesh_bounds:
		var rect := _overlay_mesh_screen_rect(_overlay_mesh_bounds[code], top_left_px)
		if rect.has_point(pixel_pos):
			if _overlay_selected.has(code):
				_overlay_selected.erase(code)
			else:
				_overlay_selected[code] = true
			_emit_union_selection()
			return

func _commit_mesh_rect_selection() -> void:
	var sel_rect := Rect2(_select_start_px, _select_end_px - _select_start_px).abs()
	var top_left_px := _top_left_px()
	for code in _overlay_mesh_bounds:
		var rect := _overlay_mesh_screen_rect(_overlay_mesh_bounds[code], top_left_px)
		if sel_rect.intersects(rect):
			_overlay_selected[code] = true
	_emit_union_selection()

## Recomputes the bounding box of every currently-selected overlay mesh and
## emits it via the SAME selection_changed signal the drag-a-rectangle mode
## uses, so ortho_panel.gd needs no separate handling for "selected via
## meshes" vs "selected via a dragged rectangle".
func _emit_union_selection() -> void:
	queue_redraw()
	if _overlay_selected.is_empty():
		return
	var min_lat := INF
	var max_lat := -INF
	var min_lon := INF
	var max_lon := -INF
	for code in _overlay_selected:
		var b: Dictionary = _overlay_mesh_bounds[code]
		min_lat = minf(min_lat, b["min_lat"])
		max_lat = maxf(max_lat, b["max_lat"])
		min_lon = minf(min_lon, b["min_lon"])
		max_lon = maxf(max_lon, b["max_lon"])
	_has_selection = true
	selection_changed.emit(min_lon, min_lat, max_lon, max_lat)

## =========================================================================
## Drawing
## =========================================================================

func _draw() -> void:
	var view_size := get_rect().size
	var top_left_px := _top_left_px()

	var first_tx := int(floor(top_left_px.x / TILE_SIZE))
	var first_ty := int(floor(top_left_px.y / TILE_SIZE))
	var tiles_x := int(ceil(view_size.x / TILE_SIZE)) + 2
	var tiles_y := int(ceil(view_size.y / TILE_SIZE)) + 2

	for ty in range(first_ty, first_ty + tiles_y):
		for tx in range(first_tx, first_tx + tiles_x):
			var draw_pos := Vector2(tx * TILE_SIZE, ty * TILE_SIZE) - top_left_px
			var tex := _get_tile_texture(tx, ty)
			if tex != null:
				draw_texture_rect(tex, Rect2(draw_pos, Vector2(TILE_SIZE, TILE_SIZE)), false)
			else:
				draw_rect(Rect2(draw_pos, Vector2(TILE_SIZE, TILE_SIZE)), Color(0.15, 0.15, 0.15), true)
				draw_rect(Rect2(draw_pos, Vector2(TILE_SIZE, TILE_SIZE)), Color(0.3, 0.3, 0.3), false)

	# Mesh overlay: drawn whenever mesh data is available, regardless of
	# the current interaction mode, so it's visible as a reference layer
	# even while just panning or drawing a plain rectangle.
	if not _overlay_mesh_bounds.is_empty():
		var font := get_theme_default_font()
		for code in _overlay_mesh_bounds:
			var rect := _overlay_mesh_screen_rect(_overlay_mesh_bounds[code], top_left_px)
			var is_selected: bool = _overlay_selected.has(code)
			var fill := Color(1.0, 0.6, 0.1, 0.35) if is_selected else Color(0.2, 0.55, 1.0, 0.20)
			var border := Color(1.0, 0.6, 0.1, 0.9) if is_selected else Color(0.2, 0.55, 1.0, 0.6)
			draw_rect(rect, fill, true)
			draw_rect(rect, border, false, 1.5)
			if rect.size.x > 46 and rect.size.y > 20 and font != null:
				draw_string(font, rect.position + Vector2(3, 14), str(code), HORIZONTAL_ALIGNMENT_LEFT, rect.size.x - 6, 10)

	if _selecting or (interaction_mode == MODE_RECT_SELECT and _has_selection) or _mesh_rect_selecting:
		var a := _select_start_px
		var b := _select_end_px
		var rect := Rect2(a, b - a).abs()
		draw_rect(rect, Color(0.2, 0.6, 1.0, 0.25), true)
		draw_rect(rect, Color(0.2, 0.6, 1.0, 0.9), false, 2.0)

func _get_tile_texture(tx: int, ty: int) -> Texture2D:
	var n := int(pow(2.0, zoom))
	var wrapped_tx := ((tx % n) + n) % n
	if ty < 0 or ty >= n:
		return null
	var key := "%d_%d_%d" % [zoom, wrapped_tx, ty]
	if _tile_cache.has(key):
		return _tile_cache[key]
	if not _pending.has(key):
		_pending[key] = true
		_queue.append(key)
		_pump_queue()
	return null

func _pump_queue() -> void:
	for i in range(POOL_SIZE):
		if _queue.is_empty():
			return
		if not _pool_busy[i]:
			var key: String = _queue.pop_front()
			var parts := key.split("_")
			var z := int(parts[0])
			var tx := int(parts[1])
			var ty := int(parts[2])
			var url := TILE_URL_TEMPLATE.replace("{z}", str(z)).replace("{x}", str(tx)).replace("{y}", str(ty))
			_pool_busy[i] = true
			_pool_tile_key[i] = key
			_pool_hops[i] = 0
			var err := _pool[i].request(url, [USER_AGENT_HEADER])
			if err != OK:
				_pool_busy[i] = false
				_pending.erase(key)

func _on_tile_request_completed(pool_index: int, result: int, response_code: int, headers: PackedStringArray, body: PackedByteArray) -> void:
	if result == HTTPRequest.RESULT_SUCCESS and _is_redirect_code(response_code) and _pool_hops[pool_index] < MAX_REDIRECT_HOPS:
		var location := _extract_location(headers)
		if location != "":
			_pool_hops[pool_index] += 1
			var err := _pool[pool_index].request(location, [USER_AGENT_HEADER])
			if err == OK:
				return  # wait for the response of the new request on this same slot

	var key := _pool_tile_key[pool_index]
	_pool_busy[pool_index] = false
	_pending.erase(key)
	if result == HTTPRequest.RESULT_SUCCESS and response_code == 200:
		var img := Image.new()
		if img.load_png_from_buffer(body) == OK:
			var tex := ImageTexture.create_from_image(img)
			_tile_cache[key] = tex
			queue_redraw()
			tile_loaded.emit()
		else:
			push_warning("PLATEAU-Ortho minimap: invalid PNG for tile %s" % key)
			tile_failed.emit(response_code)
	else:
		# A 404 just means "no tile here" (common at the edge of the
		# covered area while navigating): not logged as an error, unlike a
		# real network failure.
		if response_code != 404:
			push_warning("PLATEAU-Ortho minimap: tile %s failed (result=%d, http=%d)" % [key, result, response_code])
		tile_failed.emit(response_code)
	_pump_queue()

static func _is_redirect_code(code: int) -> bool:
	return code == 301 or code == 302 or code == 303 or code == 307 or code == 308

static func _extract_location(headers: PackedStringArray) -> String:
	for h in headers:
		if h.to_lower().begins_with("location:"):
			return h.substr(h.find(":") + 1).strip_edges()
	return ""

func _commit_selection() -> void:
	var top_left_px := _top_left_px()

	var a := _select_start_px + top_left_px
	var b := _select_end_px + top_left_px
	var min_tile := Vector2(min(a.x, b.x), min(a.y, b.y)) / TILE_SIZE
	var max_tile := Vector2(max(a.x, b.x), max(a.y, b.y)) / TILE_SIZE

	# tile_y grows southward: the southwest corner is therefore
	# (min_tile.x, max_tile.y) and the northeast corner is (max_tile.x, min_tile.y).
	var sw := TileMath.tile_to_lonlat_f(min_tile.x, max_tile.y, zoom)
	var ne := TileMath.tile_to_lonlat_f(max_tile.x, min_tile.y, zoom)

	_has_selection = true
	selection_changed.emit(sw.x, sw.y, ne.x, ne.y)
