## ortho_panel.gd
## Ortho tab: assembles the minimap, area/zoom/file fields, and drives
## PlateauOrthoDownloader. Ground-plane alignment now always uses this
## SDK's own JGD2011 projection (core/jgd2011_projection.gd) against the
## shared project origin set in the Project Setup section at the top of
## the dock - no more optional dependency on a third-party GDExtension.
##
## Uses the EditorInterface global singleton (Godot 4.2+). For Godot
## 4.0/4.1, replace EditorInterface.xxx() with get_editor_interface().xxx()
## and pass the EditorPlugin in through a setup() method.
@tool
extends Control
class_name PlateauOrthoPanel

const JGD2011Projection = preload("res://addons/plateau_sdk/core/jgd2011_projection.gd")
const SceneGeometryUtils = preload("res://addons/plateau_sdk/core/scene_geometry_utils.gd")

# Rough landmarks for navigation (well-known city centers), NOT a guarantee
# of PLATEAU-Ortho coverage there: the official list of covered
# municipalities changes over time and isn't reproduced here. Check
# coverage by zooming in on the spot (gray tiles = no data, or "missing
# tile(s)" shown after an import).
const QUICK_JUMPS := {
	"Tokyo (23 special wards)": Vector2(139.767, 35.681),
	"Yokohama": Vector2(139.638, 35.444),
	"Osaka": Vector2(135.502, 34.693),
	"Nagoya": Vector2(136.906, 35.181),
	"Sapporo": Vector2(141.354, 43.062),
	"Fukuoka": Vector2(130.402, 33.590),
	"Naha": Vector2(127.679, 26.212),
}

var minimap: PlateauOrthoMinimap
var downloader: PlateauOrthoDownloader
var _project_origin: PlateauProjectOrigin

var min_lon_edit: LineEdit
var min_lat_edit: LineEdit
var max_lon_edit: LineEdit
var max_lat_edit: LineEdit
var import_zoom_spin: SpinBox
var estimate_label: Label
var filename_edit: LineEdit
var interaction_mode_option: OptionButton
var mesh_select_hint_label: Label
var progress_bar: ProgressBar
var status_label: Label
var make_ground_check: CheckBox
var origin_display_label: Label
var use_map_center_as_origin_button: Button
var ground_height_edit: LineEdit
var match_height_button: Button
var height_status_label: Label
var ground_collision_check: CheckBox
var regenerate_ground_button: Button
var map_status_label: Label
var _map_tiles_ok := 0
var _map_tiles_failed := 0
var _map_last_failed_code := 0
var _last_ortho_image: Image = null
var _last_ortho_meta: Dictionary = {}

## Called by main_panel.gd right after instantiation, before _ready() UI is
## used, to share the single project-wide origin/zone setting.
func setup(project_origin: PlateauProjectOrigin) -> void:
	_project_origin = project_origin
	_project_origin.changed.connect(_on_project_origin_changed)
	_update_origin_display() # in case _ready() already ran (add_child() calls it synchronously) before setup() was called

## Called by main_panel.gd whenever the "3D (PLATEAU)" tab (re)analyzes a
## zip (see dataset_panel.gd's meshes_analyzed signal), so this map can
## show the same meshes and let the person pick an Ortho download area by
## clicking one instead of only dragging a rectangle.
func set_mesh_overlay(mesh_bounds: Dictionary) -> void:
	if minimap == null:
		return
	minimap.set_overlay_meshes(mesh_bounds)
	var has_meshes := minimap.has_overlay_meshes()
	if interaction_mode_option != null:
		interaction_mode_option.set_item_disabled(2, not has_meshes)
	if mesh_select_hint_label != null:
		mesh_select_hint_label.visible = not has_meshes

func _ready() -> void:
	if not Engine.is_editor_hint():
		return

	var scroll := ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(scroll)

	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_theme_constant_override("separation", 6)
	scroll.add_child(root)

	var title := Label.new()
	title.text = "PLATEAU-Ortho Importer"
	title.add_theme_font_size_override("font_size", 16)
	root.add_child(title)

	var jump_row := HBoxContainer.new()
	root.add_child(jump_row)
	var jump_label := Label.new()
	jump_label.text = "Jump to:"
	jump_row.add_child(jump_label)
	var jump_option := OptionButton.new()
	for city_name in QUICK_JUMPS.keys():
		jump_option.add_item(city_name)
	jump_option.item_selected.connect(_on_jump_selected)
	jump_row.add_child(jump_option)

	minimap = PlateauOrthoMinimap.new()
	minimap.custom_minimum_size = Vector2(320, 320)
	minimap.selection_changed.connect(_on_selection_changed)
	minimap.view_changed.connect(_on_map_view_changed)
	minimap.tile_loaded.connect(_on_map_tile_loaded)
	minimap.tile_failed.connect(_on_map_tile_failed)
	root.add_child(minimap)

	var zoom_buttons_row := HBoxContainer.new()
	root.add_child(zoom_buttons_row)
	var zoom_out_button := Button.new()
	zoom_out_button.text = "- Zoom out"
	zoom_out_button.pressed.connect(func(): minimap.zoom_out())
	zoom_buttons_row.add_child(zoom_out_button)
	var zoom_in_button := Button.new()
	zoom_in_button.text = "+ Zoom in"
	zoom_in_button.pressed.connect(func(): minimap.zoom_in())
	zoom_buttons_row.add_child(zoom_in_button)

	map_status_label = Label.new()
	map_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	map_status_label.add_theme_font_size_override("font_size", 11)
	map_status_label.add_theme_color_override("font_color", Color(0.65, 0.65, 0.65))
	root.add_child(map_status_label)

	interaction_mode_option = OptionButton.new()
	interaction_mode_option.add_item("Pan (drag moves the map)", 0)       # 0 = PlateauOrthoMinimap.MODE_PAN
	interaction_mode_option.add_item("Draw rectangle (drag selects an area)", 1) # 1 = MODE_RECT_SELECT
	interaction_mode_option.add_item("Select 3D (PLATEAU) meshes", 2)     # 2 = MODE_MESH_SELECT
	interaction_mode_option.set_item_disabled(2, true)
	interaction_mode_option.item_selected.connect(_on_interaction_mode_selected)
	root.add_child(interaction_mode_option)

	mesh_select_hint_label = Label.new()
	mesh_select_hint_label.text = "\"Select 3D (PLATEAU) meshes\" is disabled until you analyze a zip in the 3D (PLATEAU) tab (section B there) - it needs to know which meshes exist and where they are before it can show them here."
	mesh_select_hint_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	mesh_select_hint_label.add_theme_color_override("font_color", Color(0.85, 0.6, 0.3))
	root.add_child(mesh_select_hint_label)

	var hint := Label.new()
	hint.text = "Wheel = zoom (10 to 19). \"Draw rectangle\": drag to pick any area. \"Select 3D (PLATEAU) meshes\": click a mesh to use its exact bounds, Shift+drag to select several at once, plain drag still pans."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	root.add_child(hint)

	root.add_child(HSeparator.new())

	var bbox_grid := GridContainer.new()
	bbox_grid.columns = 2
	root.add_child(bbox_grid)
	min_lon_edit = _add_field(bbox_grid, "Min lon")
	min_lat_edit = _add_field(bbox_grid, "Min lat")
	max_lon_edit = _add_field(bbox_grid, "Max lon")
	max_lat_edit = _add_field(bbox_grid, "Max lat")

	var zoom_row := HBoxContainer.new()
	root.add_child(zoom_row)
	var zoom_label := Label.new()
	zoom_label.text = "Import zoom (10-19):"
	zoom_row.add_child(zoom_label)
	import_zoom_spin = SpinBox.new()
	import_zoom_spin.min_value = 10
	import_zoom_spin.max_value = 19
	import_zoom_spin.value = 17
	import_zoom_spin.value_changed.connect(func(_v: float): _update_estimate())
	zoom_row.add_child(import_zoom_spin)

	var zoom_warning := Label.new()
	zoom_warning.text = "Warning: zoom 19 (the highest level) has been unreliable in practice - zoom 18 is noticeably more reliable and still very high resolution. Try 18 first if 19 gives odd results or a lot of missing tiles."
	zoom_warning.autowrap_mode = TextServer.AUTOWRAP_WORD
	zoom_warning.add_theme_color_override("font_color", Color(0.85, 0.6, 0.3))
	root.add_child(zoom_warning)

	estimate_label = Label.new()
	estimate_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	root.add_child(estimate_label)

	root.add_child(HSeparator.new())

	var filename_row := HBoxContainer.new()
	root.add_child(filename_row)
	var filename_label := Label.new()
	filename_label.text = "Output file:"
	filename_row.add_child(filename_label)
	filename_edit = LineEdit.new()
	filename_edit.text = "res://imported_ortho/ortho_import.png"
	filename_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	filename_row.add_child(filename_edit)

	make_ground_check = CheckBox.new()
	make_ground_check.text = "Also generate a textured 3D ground plane in the open scene"
	make_ground_check.toggled.connect(_on_make_ground_toggled)
	root.add_child(make_ground_check)

	var origin_box := VBoxContainer.new()
	origin_box.visible = false
	root.add_child(origin_box)

	origin_display_label = Label.new()
	origin_display_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	origin_box.add_child(origin_display_label)

	use_map_center_as_origin_button = Button.new()
	use_map_center_as_origin_button.text = "Use map center as project origin"
	use_map_center_as_origin_button.pressed.connect(_on_use_map_center_as_origin_pressed)
	origin_box.add_child(use_map_center_as_origin_button)

	var origin_hint := Label.new()
	origin_hint.text = "The ground plane is placed using the shared project origin (see Project Setup at the top of this dock). Set it there once - reuse the same value for the Buildings tab so everything lines up. Axis mapping (which axis is north) hasn't been verified in a live editor: if the plane ends up facing the wrong way relative to imported buildings, that's the first thing to check in _generate_ground_plane()."
	origin_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	origin_hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	origin_box.add_child(origin_hint)

	var height_row := HBoxContainer.new()
	origin_box.add_child(height_row)
	var height_label := Label.new()
	height_label.text = "Ground height (Y):"
	height_row.add_child(height_label)
	ground_height_edit = LineEdit.new()
	ground_height_edit.text = "0.0"
	height_row.add_child(ground_height_edit)

	var height_hint := Label.new()
	height_hint.text = "The plane has no elevation data of its own (it's a flat photo), so it's placed at this fixed height - it won't necessarily land exactly at your buildings' ground level. Nudge this value, or use the button below to match it automatically to whatever's already imported in the 3D (PLATEAU) tab."
	height_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	height_hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	origin_box.add_child(height_hint)

	match_height_button = Button.new()
	match_height_button.text = "Match height to imported buildings"
	match_height_button.pressed.connect(_on_match_height_pressed)
	origin_box.add_child(match_height_button)

	height_status_label = Label.new()
	height_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	height_status_label.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	origin_box.add_child(height_status_label)

	ground_collision_check = CheckBox.new()
	ground_collision_check.text = "Generate collision for the ground plane (StaticBody3D + trimesh)"
	ground_collision_check.button_pressed = false
	origin_box.add_child(ground_collision_check)

	regenerate_ground_button = Button.new()
	regenerate_ground_button.text = "(Re)generate ground plane from the last downloaded image"
	regenerate_ground_button.disabled = true
	regenerate_ground_button.pressed.connect(_on_regenerate_ground_pressed)
	origin_box.add_child(regenerate_ground_button)

	var regenerate_hint := Label.new()
	regenerate_hint.text = "Lets you retry the height/collision settings above without re-downloading (no network call) - disabled until at least one image has been downloaded this session."
	regenerate_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	regenerate_hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	origin_box.add_child(regenerate_hint)

	make_ground_check.set_meta("origin_box", origin_box)

	root.add_child(HSeparator.new())

	var download_button := Button.new()
	download_button.text = "Download and import"
	download_button.pressed.connect(_on_download_pressed)
	root.add_child(download_button)

	progress_bar = ProgressBar.new()
	progress_bar.visible = false
	root.add_child(progress_bar)

	status_label = Label.new()
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	root.add_child(status_label)

	root.add_child(HSeparator.new())

	var attribution := Label.new()
	attribution.text = "Source: MLIT Project PLATEAU (PLATEAU-Ortho, CC BY 4.0). MLIT describes this service as experimental: no uptime guarantee. https://www.mlit.go.jp/plateau/site-policy/"
	attribution.autowrap_mode = TextServer.AUTOWRAP_WORD
	attribution.add_theme_font_size_override("font_size", 11)
	attribution.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	root.add_child(attribution)

	downloader = PlateauOrthoDownloader.new()
	add_child(downloader)
	downloader.progress_updated.connect(_on_progress_updated)
	downloader.finished.connect(_on_download_finished)
	downloader.failed.connect(_on_download_failed)

	minimap.center_on(139.767, 35.681)
	_sync_fields_from_minimap_center()
	_update_estimate()
	_update_map_status_label()
	_update_origin_display()

func _add_field(grid: GridContainer, label_text: String) -> LineEdit:
	var label := Label.new()
	label.text = label_text
	grid.add_child(label)
	var edit := LineEdit.new()
	edit.text = "0.0"
	edit.text_changed.connect(func(_t: String): _update_estimate())
	grid.add_child(edit)
	return edit

func _on_jump_selected(index: int) -> void:
	var city_name: String = QUICK_JUMPS.keys()[index]
	var pos: Vector2 = QUICK_JUMPS[city_name]
	minimap.center_on(pos.x, pos.y)

func _on_map_view_changed(_zoom: int, _center_lon: float, _center_lat: float) -> void:
	_update_map_status_label()

func _on_map_tile_loaded() -> void:
	_map_tiles_ok += 1
	_update_map_status_label()

func _on_map_tile_failed(response_code: int) -> void:
	_map_tiles_failed += 1
	_map_last_failed_code = response_code
	_update_map_status_label()

func _update_map_status_label() -> void:
	var text := "Map: zoom %d, center %.4f, %.4f | tiles OK: %d, failed: %d" % [
		minimap.zoom, minimap.center_lon, minimap.center_lat, _map_tiles_ok, _map_tiles_failed
	]
	if _map_tiles_failed > 0:
		text += " (last code: %d)" % _map_last_failed_code
	map_status_label.text = text

func _on_interaction_mode_selected(index: int) -> void:
	minimap.interaction_mode = interaction_mode_option.get_item_id(index)

func _on_selection_changed(min_lon: float, min_lat: float, max_lon: float, max_lat: float) -> void:
	min_lon_edit.text = "%.6f" % min_lon
	min_lat_edit.text = "%.6f" % min_lat
	max_lon_edit.text = "%.6f" % max_lon
	max_lat_edit.text = "%.6f" % max_lat
	_update_estimate()

func _sync_fields_from_minimap_center() -> void:
	# A small default rectangle around the current center, so the fields
	# are coherent before any mouse selection.
	var d := 0.01
	min_lon_edit.text = "%.6f" % (minimap.center_lon - d)
	min_lat_edit.text = "%.6f" % (minimap.center_lat - d)
	max_lon_edit.text = "%.6f" % (minimap.center_lon + d)
	max_lat_edit.text = "%.6f" % (minimap.center_lat + d)

func _on_make_ground_toggled(pressed: bool) -> void:
	var origin_box: VBoxContainer = make_ground_check.get_meta("origin_box")
	origin_box.visible = pressed

func _on_project_origin_changed() -> void:
	_update_origin_display()

func _update_origin_display() -> void:
	if _project_origin == null or origin_display_label == null:
		return
	if _project_origin.is_default():
		origin_display_label.text = "Project origin not set yet (see Project Setup above, or use the button below)."
	else:
		origin_display_label.text = "Project origin: zone %d, %.6f, %.6f" % [_project_origin.zone, _project_origin.lat, _project_origin.lon]

func _on_use_map_center_as_origin_pressed() -> void:
	if _project_origin == null:
		return
	var zone := JGD2011Projection.suggest_zone(minimap.center_lat, minimap.center_lon)
	_project_origin.set_origin(zone, minimap.center_lat, minimap.center_lon)

func _current_bbox() -> Dictionary:
	return {
		"min_lon": min_lon_edit.text.to_float(),
		"min_lat": min_lat_edit.text.to_float(),
		"max_lon": max_lon_edit.text.to_float(),
		"max_lat": max_lat_edit.text.to_float(),
	}

func _update_estimate() -> void:
	if downloader == null:
		return
	var bbox := _current_bbox()
	var zoom := int(import_zoom_spin.value)
	var info := downloader.estimate(bbox["min_lon"], bbox["min_lat"], bbox["max_lon"], bbox["max_lat"], zoom)
	var tile_count: int = info["tile_count"]
	estimate_label.text = "%d tile(s) -> %dx%d px image" % [tile_count, info["pixel_width"], info["pixel_height"]]
	if tile_count > PlateauOrthoDownloader.MAX_TILES_WITHOUT_CONFIRM:
		estimate_label.add_theme_color_override("font_color", Color(1.0, 0.5, 0.3))
	else:
		estimate_label.add_theme_color_override("font_color", Color(0.8, 0.8, 0.8))

func _on_download_pressed() -> void:
	var bbox := _current_bbox()
	if bbox["min_lon"] >= bbox["max_lon"] or bbox["min_lat"] >= bbox["max_lat"]:
		status_label.text = "Invalid area: draw or type a valid rectangle before importing."
		return
	progress_bar.visible = true
	progress_bar.value = 0
	status_label.text = "Downloading..."
	downloader.download_area(bbox["min_lon"], bbox["min_lat"], bbox["max_lon"], bbox["max_lat"], int(import_zoom_spin.value), true)

func _on_progress_updated(done: int, total: int) -> void:
	progress_bar.max_value = total
	progress_bar.value = done
	status_label.text = "Downloading: %d / %d tiles" % [done, total]

func _on_download_failed(message: String) -> void:
	progress_bar.visible = false
	status_label.text = "Failed: " + message

func _on_download_finished(image: Image, meta: Dictionary) -> void:
	progress_bar.visible = false
	var path: String = _resolve_non_colliding_path(filename_edit.text)
	var dir_path := path.get_base_dir()
	if dir_path != "" and not DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(dir_path)):
		DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(dir_path))
	var save_err := image.save_png(path)
	if save_err != OK:
		status_label.text = "Image downloaded but failed to save (%s, code %d)." % [path, save_err]
		return

	EditorInterface.get_resource_filesystem().scan()

	var missing: int = meta.get("missing_tiles", 0)
	var msg := "Done: %s (%dx%d px)." % [path, meta["pixel_width"], meta["pixel_height"]]
	if missing > 0:
		msg += " %d missing tile(s) (this area is likely outside PLATEAU-Ortho coverage, or at this zoom)." % missing
	status_label.text = msg

	_last_ortho_image = image
	_last_ortho_meta = meta
	regenerate_ground_button.disabled = false

	if make_ground_check.button_pressed:
		_generate_ground_plane(image, meta)

## If the requested file already exists, adds a numeric suffix instead of
## silently overwriting a previous import (base_path itself stays
## unchanged in the field, so the next import starts from the same name).
func _resolve_non_colliding_path(base_path: String) -> String:
	if not FileAccess.file_exists(base_path):
		return base_path
	var dir_path := base_path.get_base_dir()
	var file_name := base_path.get_file()
	var extension := file_name.get_extension()
	var stem := file_name.get_basename()
	var i := 2
	while true:
		var candidate := "%s/%s_%d.%s" % [dir_path, stem, i, extension]
		if not FileAccess.file_exists(candidate):
			return candidate
		i += 1
	return base_path # unreachable in practice, kept to satisfy the type checker

func _generate_ground_plane(image: Image, meta: Dictionary) -> void:
	var scene_root := EditorInterface.get_edited_scene_root()
	if scene_root == null:
		status_label.text += " Open a 3D scene in the editor to generate the plane automatically."
		return
	if _project_origin == null:
		status_label.text += " No project origin available."
		return

	# Extent ACTUALLY covered by the image (rounded to tile boundaries), not
	# the rectangle dragged with the mouse: the two differ (especially at
	# low zoom or for a narrow selection), and using the drawn selection
	# here produced a stretched / mis-proportioned plane.
	var img_min_lon: float = meta["actual_min_lon"]
	var img_max_lon: float = meta["actual_max_lon"]
	var img_min_lat: float = meta["actual_min_lat"]
	var img_max_lat: float = meta["actual_max_lat"]
	var img_center_lon := (img_min_lon + img_max_lon) / 2.0
	var img_center_lat := (img_min_lat + img_max_lat) / 2.0

	var zone := _project_origin.zone
	var origin_xy := JGD2011Projection.get_xy(_project_origin.lat, _project_origin.lon, zone)
	var center_xy := JGD2011Projection.get_xy(img_center_lat, img_center_lon, zone)
	var min_xy := JGD2011Projection.get_xy(img_min_lat, img_min_lon, zone)
	var max_xy := JGD2011Projection.get_xy(img_max_lat, img_max_lon, zone)

	# Convention (shared with the Buildings tab): X = east, Y = height,
	# Z = -north. X of get_xy() is north, Y is east.
	var offset_x := center_xy.y - origin_xy.y
	var offset_z := -(center_xy.x - origin_xy.x)
	var width_m := absf(max_xy.y - min_xy.y)
	var depth_m := absf(max_xy.x - min_xy.x)
	var height_y := ground_height_edit.text.to_float()

	# Remove any previously generated ground plane rather than stacking a
	# new one on top of it every time this runs (download, or the
	# standalone regenerate button). remove_child() first (synchronous)
	# rather than only queue_free() (deferred): otherwise the old node
	# would still occupy the "PlateauOrthoGround" name slot when the new
	# one is added a few lines below, and Godot would silently rename the
	# new one to avoid the collision.
	var existing := scene_root.get_node_or_null("PlateauOrthoGround")
	if existing != null:
		scene_root.remove_child(existing)
		existing.queue_free()

	var mesh_instance := MeshInstance3D.new()
	mesh_instance.name = "PlateauOrthoGround"
	var plane := PlaneMesh.new()
	plane.size = Vector2(width_m, depth_m)
	mesh_instance.mesh = plane

	var tex := ImageTexture.create_from_image(image)
	var mat := StandardMaterial3D.new()
	mat.albedo_texture = tex
	mat.roughness = 1.0
	mesh_instance.material_override = mat
	mesh_instance.position = Vector3(offset_x, height_y, offset_z)

	scene_root.add_child(mesh_instance)
	mesh_instance.owner = scene_root

	if ground_collision_check.button_pressed:
		mesh_instance.create_trimesh_collision()
		_set_owner_recursive(mesh_instance, scene_root)

	status_label.text += " 3D plane added (%.1f x %.1f m, real tile extent, zone %d projection, Y=%.3f)." % [width_m, depth_m, zone, height_y]

static func _set_owner_recursive(node: Node, owner: Node) -> void:
	for child in node.get_children():
		child.owner = owner
		_set_owner_recursive(child, owner)

func _on_regenerate_ground_pressed() -> void:
	if _last_ortho_image == null:
		status_label.text = "No downloaded image yet this session - download once first."
		return
	_generate_ground_plane(_last_ortho_image, _last_ortho_meta)

## Scans the currently open scene for buildings imported by the
## "3D (PLATEAU)" tab (MeshInstance3D nodes named "bldg_...", see
## citygml_importer.gd) and sets the ground height field to the lowest
## point found among them, so the ground plane can be matched to actual
## imported geometry instead of guessed by eye.
func _on_match_height_pressed() -> void:
	var scene_root := EditorInterface.get_edited_scene_root()
	if scene_root == null:
		height_status_label.text = "Open the scene with your imported buildings first."
		return
	var lowest = SceneGeometryUtils.find_lowest_building_y(scene_root)
	if lowest == null:
		height_status_label.text = "No imported buildings found in this scene (looked for MeshInstance3D nodes named \"bldg_...\", see the 3D (PLATEAU) tab)."
		return
	ground_height_edit.text = "%.3f" % lowest
	height_status_label.text = "Matched to the lowest point found among imported buildings (Y=%.3f). Press \"(Re)generate\" below (or re-download) to apply it." % lowest
