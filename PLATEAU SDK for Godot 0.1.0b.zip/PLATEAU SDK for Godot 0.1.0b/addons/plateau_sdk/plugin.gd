## plugin.gd
## Entry point. Adds the single "PLATEAU SDK" panel to the editor dock,
## hosting three tabs (3D (PLATEAU), 2D (PLATEAU Ortho), Exploration) plus
## the shared Project Setup section. Also registers the runtime pieces the
## Exploration tab's characters need to actually work when the scene is
## played: an "Audio" autoload singleton and a handful of Input actions
## (movement, jump, camera look, zoom, mouse capture - deliberately NOT
## "shoot" or "weapon_toggle", since the Exploration tab's first-person
## character has no weapon).
##
## Targets Godot 4.2+ (uses the global EditorInterface singleton). For
## Godot 4.0/4.1, replace EditorInterface.xxx() calls throughout this addon
## with get_editor_interface().xxx() and pass the EditorPlugin instance in
## through a setup() method.
@tool
extends EditorPlugin

const SdkPanel = preload("res://addons/plateau_sdk/main_panel.gd")

const AUDIO_AUTOLOAD_NAME := "Audio"
const AUDIO_AUTOLOAD_PATH := "res://addons/plateau_sdk/exploration/characters/shared/audio.gd"

## action name -> single key event to bind it to, only used the FIRST time
## each action is created (see _ensure_key_action() - never overwrites an
## existing binding, whether from a previous run of this or from the
## person's own project). Keys chosen to match Kenney's original starter
## kits (WASD movement, arrow-key camera, Space jump).
const KEY_ACTIONS := {
	"move_left": KEY_A,
	"move_right": KEY_D,
	"move_forward": KEY_W,
	"move_back": KEY_S,
	"jump": KEY_SPACE,
	"camera_left": KEY_LEFT,
	"camera_right": KEY_RIGHT,
	"camera_up": KEY_UP,
	"camera_down": KEY_DOWN,
	"zoom_in": KEY_EQUAL,
	"zoom_out": KEY_MINUS,
	"mouse_capture_exit": KEY_ESCAPE,
}

var panel_instance: Control

func _enter_tree() -> void:
	panel_instance = SdkPanel.new()
	panel_instance.name = "PLATEAU SDK"
	add_control_to_dock(EditorPlugin.DOCK_SLOT_RIGHT_UL, panel_instance)

	_ensure_audio_autoload()
	_ensure_input_actions()

func _exit_tree() -> void:
	if panel_instance:
		remove_control_from_docks(panel_instance)
		panel_instance.queue_free()
	# Deliberately NOT removing the Audio autoload or input actions here:
	# by the time someone disables this plugin they may already have
	# scenes/characters depending on them, and silently breaking those on
	# uninstall would be worse than leaving a few unused project settings
	# behind. Remove them by hand (Project Settings > Autoload / Input Map)
	# if you want them gone.

func _ensure_audio_autoload() -> void:
	if not ProjectSettings.has_setting("autoload/" + AUDIO_AUTOLOAD_NAME):
		add_autoload_singleton(AUDIO_AUTOLOAD_NAME, AUDIO_AUTOLOAD_PATH)

func _ensure_input_actions() -> void:
	var changed := false
	for action_name in KEY_ACTIONS:
		if _ensure_key_action(action_name, KEY_ACTIONS[action_name]):
			changed = true
	# Re-capturing the mouse after it's been released (mouse_capture_exit,
	# above) is conventionally done by clicking back into the view.
	if _ensure_mouse_action("mouse_capture", MOUSE_BUTTON_LEFT):
		changed = true
	if changed:
		ProjectSettings.save()

func _ensure_key_action(action_name: String, keycode: int) -> bool:
	if InputMap.has_action(action_name):
		return false
	var event := InputEventKey.new()
	event.keycode = keycode
	InputMap.add_action(action_name)
	InputMap.action_add_event(action_name, event)
	_save_action_to_project_settings(action_name, [event])
	return true

func _ensure_mouse_action(action_name: String, button_index: int) -> bool:
	if InputMap.has_action(action_name):
		return false
	var event := InputEventMouseButton.new()
	event.button_index = button_index
	InputMap.add_action(action_name)
	InputMap.action_add_event(action_name, event)
	_save_action_to_project_settings(action_name, [event])
	return true

## Mirrors the live InputMap registration above into ProjectSettings, so
## the action shows up correctly in Project Settings > Input Map and
## persists across editor restarts (the InputMap.add_action() calls above
## only affect the CURRENT session on their own).
func _save_action_to_project_settings(action_name: String, events: Array) -> void:
	var setting_name := "input/" + action_name
	var action_data := {"deadzone": 0.5, "events": events}
	ProjectSettings.set_setting(setting_name, action_data)
	ProjectSettings.set_initial_value(setting_name, action_data)
